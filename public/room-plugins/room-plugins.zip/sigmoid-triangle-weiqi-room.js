window.RoomPlugins = window.RoomPlugins || {};
window.RoomPlugins["sigmoid-triangle-weiqi"] = {
    shell: {
        "title": "Sigmoid三角围棋",
        "rulesHtml": "基本规则同围棋。<br /><br />采用Sigmoid三角棋盘。<br />",
        "defaultKomiText": "黑贴白3.25点",
        "boardSizeMin": 5,
        "boardSizeMax": 21,
        "defaultBoardSize": 13,
        "minLib": 1,
        "recordDownloadPrefix": "Sigmoid三角围棋",
        "standardWeiqiMatchTime": true,
        "features": {
            "editBoard": true,
            "zoomScroll": true,
            "transparentCanvas": true
        },
        "editTools": [
            {
                "value": "empty",
                "label": "空"
            },
            {
                "value": "black",
                "label": "黑子"
            },
            {
                "value": "white",
                "label": "白子"
            }
        ]
    },
    mount: function (ctx) {
        var gameType = ctx.gameType;
        var roomId = ctx.roomId;
        var roomPassword = ctx.roomPassword || null;
        var config = ctx.config || {};
        var recordDownloadPrefix = config.recordDownloadPrefix != null ? config.recordDownloadPrefix : "Sigmoid三角围棋";
        var minLib = config.minLib != null ? config.minLib : 1;
        var standardWeiqiMatchTime = config.standardWeiqiMatchTime != null ? config.standardWeiqiMatchTime : true;


        (function () {
// ======================== 配置 ========================
        const ps = {
            BOARD_SIZE: 19,
            KOMI: 3.25,
            PADDING: 0,
            CELL_SIZE: 0,
            numberOfHands: 1,
            currentPlayer: 1,
            mySlot: null,
            gameOver: false,
            winner: null,
            lastMoveMarkers: [],
            showEstimateActive: false,
            cachedLiveBoard: null,
            cachedTerritory: null,
            waitingScoreConfirm: false,
            iRejected: false,
            ws: null,
            isMyTurn: false,
            slots: { black: false, white: false },
            reconnectTimer: null,
            replayMode: false,
            replayBoards: [],
            replayMarkers: [],
            replayStepPlayers: [],
            replayStep: 0,
            replayTotalSteps: 0,
            showMoveNumbers: false,
            moveLog: [],
            tryPlayMode: false,
            tryPlayBaseStep: 0,
            tryPlayBoards: [],
            tryPlayMarkers: [],
            tryPlayCurrentPlayer: 1,
            tryPlayStep: 0,
            tryPlayTotalSteps: 0,
            liveReplayBoards: [],
            liveReplayMarkers: [],
            liveReplayStepPlayers: [],
            liveViewStep: 0,
            liveFollowLatest: true,
            userBoardMarks: Object.create(null),
            hoverRow: -1,
            hoverCol: -1,
            isHoverValid: false,
            liveOpeningBoard: null,
            gameStarted: false,
            editModeEnabled: false,
            editTool: 'empty',
            /** 棋盘局部缩放（与 qi.js QiWeiqiSquarePageRuntime 视口变换配合） */
            viewZoom: 1,
            viewCenterX: 300,
            viewCenterY: 300
        };
        const SIGMOID_Y_SCALE = Math.sqrt(3) / 2;
        /** 棋盘整体逆时针 30°（canvas 坐标系 y 向下，取负角） */
        const BOARD_ROT_CCW_RAD = -Math.PI / 6;
        const SIGMOID_CANVAS_SIZE = 600;
        const SIGMOID_FRAME_CORNER_RADIUS = 4;

        const SigmoidBoardGeom = {
            _centerCacheKey: '',
            _centerCache: { cx: 0, cy: 0 },
            _fitCacheKey: '',
            displayScale: 1,
            displayOffsetX: 0,
            displayOffsetY: 0,
            _frameOutsetDisplay: 24,
            outerFrameBounds: { minX: 0, maxX: 600, minY: 0, maxY: 600 },

            /** 自最底行起第 n 行（n=1 为底行）向左平移的单位数（格长） */
            rowShiftUnits(nFromBottom) {
                return 0.5 * (nFromBottom - 1);
            },
            nFromBottom(row, boardSize) {
                return boardSize - row;
            },
            shiftUnitsForRow(row, boardSize) {
                return this.rowShiftUnits(this.nFromBottom(row, boardSize));
            },
            bottomY(padding, cellSize, boardSize) {
                return padding + (boardSize - 1) * cellSize;
            },
            initGeometry() {
                const g = QiSquareWeiqiCanvas.computePaddingAndCell(ps.BOARD_SIZE);
                ps.PADDING = g.padding;
                ps.CELL_SIZE = g.cellSize;
                this._centerCacheKey = '';
                this._fitCacheKey = '';
                this.recomputeDisplayFit(ps.PADDING, ps.CELL_SIZE, ps.BOARD_SIZE);
            },
            effectiveCellSize(cellSize) {
                return cellSize * this.displayScale;
            },
            /**
             * 三角格边长（逻辑坐标）：与标准围棋格长 cellSize 相同，随路数按 475/n 缩格。
             * 显示时间距 = cellSize * displayScale。
             */
            triangleEdgeLengthRaw(padding, cellSize, boardSize) {
                return cellSize;
            },
            /** 木框与棋盘外缘间距（显示坐标）≈ 一格三角边长 */
            frameOutsetDisplay(padding, cellSize, boardSize) {
                return this.triangleEdgeLengthRaw(padding, cellSize, boardSize) * this.displayScale;
            },
            boardCornerVertsRotated(padding, cellSize, boardSize) {
                const n = boardSize;
                return [
                    this.xyRotated(0, 0, padding, cellSize, n),
                    this.xyRotated(0, n - 1, padding, cellSize, n),
                    this.xyRotated(n - 1, n - 1, padding, cellSize, n),
                    this.xyRotated(n - 1, 0, padding, cellSize, n)
                ];
            },
            recomputeDisplayFit(padding, cellSize, boardSize) {
                const key = `${padding}|${cellSize}|${boardSize}`;
                if (this._fitCacheKey === key) return;
                const n = boardSize;
                const frameOutRaw = this.triangleEdgeLengthRaw(padding, cellSize, n);
                const corners = this.boardCornerVertsRotated(padding, cellSize, n);
                const frameRaw = this.parallelOffsetQuad(corners, frameOutRaw);
                let minX = Infinity;
                let minY = Infinity;
                let maxX = -Infinity;
                let maxY = -Infinity;
                const include = (p) => {
                    minX = Math.min(minX, p.x);
                    minY = Math.min(minY, p.y);
                    maxX = Math.max(maxX, p.x);
                    maxY = Math.max(maxY, p.y);
                };
                for (let r = 0; r < n; r++) {
                    for (let c = 0; c < n; c++) {
                        include(this.xyRotated(r, c, padding, cellSize, n));
                    }
                }
                for (const p of frameRaw) include(p);
                const canvasMargin = 16;
                const avail = SIGMOID_CANVAS_SIZE - 2 * canvasMargin;
                const w = Math.max(1e-6, maxX - minX);
                const h = Math.max(1e-6, maxY - minY);
                const scale = Math.min(avail / w, avail / h);
                const cx = (minX + maxX) / 2;
                const cy = (minY + maxY) / 2;
                this.displayScale = scale;
                this.displayOffsetX = SIGMOID_CANVAS_SIZE / 2 - scale * cx;
                this.displayOffsetY = SIGMOID_CANVAS_SIZE / 2 - scale * cy;
                this._frameOutsetDisplay = frameOutRaw * scale;
                this._fitCacheKey = key;
                this.updateOuterFrameBounds(padding, cellSize, n);
            },
            applyDisplayTransform(x, y) {
                return {
                    x: this.displayOffsetX + x * this.displayScale,
                    y: this.displayOffsetY + y * this.displayScale
                };
            },
            invertDisplayTransform(x, y) {
                const s = this.displayScale || 1;
                return {
                    x: (x - this.displayOffsetX) / s,
                    y: (y - this.displayOffsetY) / s
                };
            },
            /** 纵向压缩 + 行错位，尚未旋转 */
            xyBase(row, col, padding, cellSize, boardSize) {
                const bottomY = this.bottomY(padding, cellSize, boardSize);
                const y = bottomY - (boardSize - 1 - row) * cellSize * SIGMOID_Y_SCALE;
                const shiftU = this.shiftUnitsForRow(row, boardSize);
                const x = padding + col * cellSize - shiftU * cellSize;
                return { x, y };
            },
            rotationCenter(padding, cellSize, boardSize) {
                const key = `${padding}|${cellSize}|${boardSize}`;
                if (this._centerCacheKey === key) return this._centerCache;
                const n = boardSize;
                const corners = [[0, 0], [0, n - 1], [n - 1, 0], [n - 1, n - 1]];
                let sx = 0;
                let sy = 0;
                for (const [r, c] of corners) {
                    const p = this.xyBase(r, c, padding, cellSize, n);
                    sx += p.x;
                    sy += p.y;
                }
                this._centerCache = { cx: sx / 4, cy: sy / 4 };
                this._centerCacheKey = key;
                return this._centerCache;
            },
            /** 绕 center 逆时针旋转（屏幕视角） */
            rotatePointCCW(x, y, cx, cy) {
                const rad = BOARD_ROT_CCW_RAD;
                const dx = x - cx;
                const dy = y - cy;
                const c = Math.cos(rad);
                const s = Math.sin(rad);
                return {
                    x: cx + dx * c - dy * s,
                    y: cy + dx * s + dy * c
                };
            },
            /** 逆变换：顺时针 30°，用于点击拾取 */
            unrotatePoint(x, y, cx, cy) {
                const rad = -BOARD_ROT_CCW_RAD;
                const dx = x - cx;
                const dy = y - cy;
                const c = Math.cos(rad);
                const s = Math.sin(rad);
                return {
                    x: cx + dx * c - dy * s,
                    y: cy + dx * s + dy * c
                };
            },
            xyRotated(row, col, padding, cellSize, boardSize) {
                const base = this.xyBase(row, col, padding, cellSize, boardSize);
                const { cx, cy } = this.rotationCenter(padding, cellSize, boardSize);
                return this.rotatePointCCW(base.x, base.y, cx, cy);
            },
            xy(row, col, padding, cellSize, boardSize) {
                const p = this.xyRotated(row, col, padding, cellSize, boardSize);
                return this.applyDisplayTransform(p.x, p.y);
            },
            boardCornerVerts(padding, cellSize, boardSize) {
                const n = boardSize;
                return [
                    this.xy(0, 0, padding, cellSize, n),
                    this.xy(0, n - 1, padding, cellSize, n),
                    this.xy(n - 1, n - 1, padding, cellSize, n),
                    this.xy(n - 1, 0, padding, cellSize, n)
                ];
            },
            /** 保持顶点环方向为逆时针（屏幕坐标） */
            ensureCcW(verts) {
                let area = 0;
                for (let i = 0; i < verts.length; i++) {
                    const j = (i + 1) % verts.length;
                    area += verts[i].x * verts[j].y - verts[j].x * verts[i].y;
                }
                if (area < 0) return verts.slice().reverse();
                return verts.slice();
            },
            lineIntersect(p1, p2, p3, p4) {
                const dax = p2.x - p1.x;
                const day = p2.y - p1.y;
                const dbx = p4.x - p3.x;
                const dby = p4.y - p3.y;
                const denom = dax * dby - day * dbx;
                if (Math.abs(denom) < 1e-9) return { x: p1.x, y: p1.y };
                const t = ((p3.x - p1.x) * dby - (p3.y - p1.y) * dbx) / denom;
                return { x: p1.x + t * dax, y: p1.y + t * day };
            },
            /** 平行四边形沿边外扩，各边与内框平行（保持 60°/120° 倾角） */
            parallelOffsetQuad(verts, dist) {
                const n = verts.length;
                if (n !== 4) return verts.slice();
                const v = this.ensureCcW(verts);
                let area = 0;
                for (let i = 0; i < n; i++) {
                    const j = (i + 1) % n;
                    area += v[i].x * v[j].y - v[j].x * v[i].y;
                }
                const sign = area >= 0 ? 1 : -1;
                const offsetLines = [];
                for (let i = 0; i < n; i++) {
                    const a = v[i];
                    const b = v[(i + 1) % n];
                    const dx = b.x - a.x;
                    const dy = b.y - a.y;
                    const len = Math.hypot(dx, dy) || 1;
                    const nx = sign * (dy / len) * dist;
                    const ny = sign * (-dx / len) * dist;
                    offsetLines.push({
                        p1: { x: a.x + nx, y: a.y + ny },
                        p2: { x: b.x + nx, y: b.y + ny }
                    });
                }
                const out = [];
                for (let i = 0; i < n; i++) {
                    const L0 = offsetLines[(i - 1 + n) % n];
                    const L1 = offsetLines[i];
                    out.push(this.lineIntersect(L0.p1, L0.p2, L1.p1, L1.p2));
                }
                return out;
            },
            frameOuterVerts(padding, cellSize, boardSize) {
                const corners = this.boardCornerVerts(padding, cellSize, boardSize);
                const outset = this._frameOutsetDisplay > 0
                    ? this._frameOutsetDisplay
                    : this.frameOutsetDisplay(padding, cellSize, boardSize);
                return this.parallelOffsetQuad(corners, outset);
            },
            updateOuterFrameBounds(padding, cellSize, boardSize) {
                const outer = this.frameOuterVerts(padding, cellSize, boardSize);
                let minX = Infinity;
                let maxX = -Infinity;
                let minY = Infinity;
                let maxY = -Infinity;
                for (const v of outer) {
                    minX = Math.min(minX, v.x);
                    maxX = Math.max(maxX, v.x);
                    minY = Math.min(minY, v.y);
                    maxY = Math.max(maxY, v.y);
                }
                this.outerFrameBounds = { minX, maxX, minY, maxY };
            },
            drawRoundedPolygon(ctx, vertices, radius) {
                const n = vertices.length;
                if (n < 3) return;
                const startPoints = [];
                const endPoints = [];
                for (let i = 0; i < n; i++) {
                    const curr = vertices[i];
                    const prev = vertices[(i - 1 + n) % n];
                    const next = vertices[(i + 1) % n];
                    const v1 = { x: prev.x - curr.x, y: prev.y - curr.y };
                    const v2 = { x: next.x - curr.x, y: next.y - curr.y };
                    const len1 = Math.hypot(v1.x, v1.y);
                    const len2 = Math.hypot(v2.x, v2.y);
                    const dx1 = v1.x / len1;
                    const dy1 = v1.y / len1;
                    const dx2 = v2.x / len2;
                    const dy2 = v2.y / len2;
                    startPoints.push({ x: curr.x + dx1 * radius, y: curr.y + dy1 * radius });
                    endPoints.push({ x: curr.x + dx2 * radius, y: curr.y + dy2 * radius });
                }
                ctx.beginPath();
                ctx.moveTo(endPoints[n - 1].x, endPoints[n - 1].y);
                for (let i = 0; i < n; i++) {
                    ctx.arcTo(vertices[i].x, vertices[i].y, endPoints[i].x, endPoints[i].y, radius);
                }
                ctx.closePath();
                ctx.fill();
                ctx.stroke();
            },
            drawWoodenFrame(ctx, boardSize, padding, cellSize) {
                const outer = this.frameOuterVerts(padding, cellSize, boardSize);
                ctx.save();
                ctx.shadowBlur = 20;
                ctx.shadowColor = 'rgba(0,0,0,0.8)';
                ctx.shadowOffsetY = 8;
                ctx.fillStyle = '#edbc80';
                ctx.strokeStyle = '#6b4a2e';
                ctx.lineWidth = 1;
                this.drawRoundedPolygon(ctx, outer, SIGMOID_FRAME_CORNER_RADIUS);
                ctx.restore();
            },
            pickIntersection(canvasX, canvasY, padding, cellSize, boardSize) {
                const n = boardSize;
                const { cx, cy } = this.rotationCenter(padding, cellSize, n);
                const pre = this.invertDisplayTransform(canvasX, canvasY);
                const local = this.unrotatePoint(pre.x, pre.y, cx, cy);
                let bestR = -1;
                let bestC = -1;
                let bestD = Infinity;
                const hitR = this.effectiveCellSize(cellSize) * 0.48;
                const hitR2 = hitR * hitR;
                for (let r = 0; r < n; r++) {
                    for (let c = 0; c < n; c++) {
                        const p = this.xyBase(r, c, padding, cellSize, n);
                        const d = (p.x - local.x) ** 2 + (p.y - local.y) ** 2;
                        if (d < bestD) {
                            bestD = d;
                            bestR = r;
                            bestC = c;
                        }
                    }
                }
                if (bestD > hitR2) return { row: -1, col: -1 };
                return { row: bestR, col: bestC };
            },
            gridLineWidth(boardSize, strokeInvScale) {
                let lw = 1.5;
                if (strokeInvScale != null && strokeInvScale > 0 && strokeInvScale < 1)
                    lw = Math.max(0.5, 28 / boardSize * strokeInvScale);
                return lw;
            },
            drawGrid(ctx, boardSize, padding, cellSize, strokeInvScale) {
                const G = this;
                const n = boardSize;
                ctx.strokeStyle = '#3a281c';
                ctx.lineWidth = this.gridLineWidth(n, strokeInvScale);
                ctx.beginPath();
                for (let r = 0; r < n; r++) {
                    const a = G.xy(r, 0, padding, cellSize, n);
                    const b = G.xy(r, n - 1, padding, cellSize, n);
                    ctx.moveTo(a.x, a.y);
                    ctx.lineTo(b.x, b.y);
                }
                for (let c = 0; c < n; c++) {
                    const a = G.xy(0, c, padding, cellSize, n);
                    const b = G.xy(n - 1, c, padding, cellSize, n);
                    ctx.moveTo(a.x, a.y);
                    ctx.lineTo(b.x, b.y);
                }
                ctx.stroke();
            },
            drawAntiDiagonalLines(ctx, boardSize, padding, cellSize, strokeInvScale) {
                const G = this;
                const n = boardSize;
                let lw = 1.2;
                if (strokeInvScale != null && strokeInvScale > 0 && strokeInvScale < 1)
                    lw = Math.max(0.5, 22 / n * strokeInvScale);
                ctx.strokeStyle = '#3a281c';
                ctx.lineWidth = lw;
                ctx.beginPath();
                for (let k = 0; k <= 2 * (n - 1); k++) {
                    const c0 = Math.max(0, k - (n - 1));
                    const c1 = Math.min(k, n - 1);
                    const r0 = k - c0;
                    const r1 = k - c1;
                    const p0 = G.xy(r0, c0, padding, cellSize, n);
                    const p1 = G.xy(r1, c1, padding, cellSize, n);
                    ctx.moveTo(p0.x, p0.y);
                    ctx.lineTo(p1.x, p1.y);
                }
                ctx.stroke();
            },
            drawStarPoints(ctx, boardSize, padding, cellSize) {
                const pts = QiSquareWeiqiCanvas.getStarPoints(boardSize);
                const starR = this.effectiveCellSize(cellSize) * 0.12;
                ctx.fillStyle = '#3a281c';
                for (const [r, c] of pts) {
                    const p = this.xy(r, c, padding, cellSize, boardSize);
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, starR, 0, 2 * Math.PI);
                    ctx.fill();
                }
            },
            /** 沿棋盘外缘指向木框一侧的单位法向（p0→p1 为自上而下） */
            outwardNormalForEdge(p0, p1, interiorRef) {
                const tx = p1.x - p0.x;
                const ty = p1.y - p0.y;
                const len = Math.hypot(tx, ty) || 1;
                let nx = -ty / len;
                let ny = tx / len;
                const mx = (p0.x + p1.x) / 2;
                const my = (p0.y + p1.y) / 2;
                if ((interiorRef.x - mx) * nx + (interiorRef.y - my) * ny > 0) {
                    nx = -nx;
                    ny = -ny;
                }
                return { x: nx, y: ny };
            },
            drawCoordLabels(ctx, boardSize, padding, cellSize) {
                const G = this;
                const n = boardSize;
                const mid = Math.floor((n - 1) / 2);
                const interior = G.xy(mid, mid, padding, cellSize, n);
                const topLeft = G.xy(0, 0, padding, cellSize, n);
                const topRight = G.xy(0, n - 1, padding, cellSize, n);
                const rightTop = topRight;
                const rightBot = G.xy(n - 1, n - 1, padding, cellSize, n);
                const insideTop = G.xy(1, 0, padding, cellSize, n);
                const topN = G.outwardNormalForEdge(topLeft, topRight, insideTop);
                const rightN = G.outwardNormalForEdge(rightTop, rightBot, interior);
                const gapHalf = (G._frameOutsetDisplay > 0
                    ? G._frameOutsetDisplay
                    : G.frameOutsetDisplay(padding, cellSize, n)) * 0.5;
                const cellDisp = G.effectiveCellSize(cellSize);
                /** 在法向偏移基础上再平移（格长倍数）：数字←↓，字母→↓ */
                const numExtraX = -0.2 * cellDisp;
                const numExtraY = 0.115 * cellDisp;
                const letExtraX = 0.2 * cellDisp;
                const letExtraY = 0.115 * cellDisp;
                ctx.font = `bold ${Math.max(9, 250 / n * G.displayScale)}px Arial`;
                ctx.fillStyle = '#3a281c';
                ctx.textBaseline = 'middle';
                ctx.textAlign = 'center';
                for (let c = 0; c < n; c++) {
                    const p = G.xy(0, c, padding, cellSize, n);
                    ctx.fillText(
                        String(n - c),
                        p.x + topN.x * gapHalf + numExtraX,
                        p.y + topN.y * gapHalf + numExtraY
                    );
                }
                for (let r = 0; r < n; r++) {
                    let letter = String.fromCharCode(65 + r);
                    if (r >= 26) {
                        letter = String.fromCharCode(64 + Math.floor(r / 26))
                            + String.fromCharCode(65 + r % 26);
                    }
                    const p = G.xy(r, n - 1, padding, cellSize, n);
                    ctx.fillText(
                        letter,
                        p.x + rightN.x * gapHalf + letExtraX,
                        p.y + rightN.y * gapHalf + letExtraY
                    );
                }
            },
            drawStones(ctx, board, boardSize, padding, cellSize, stoneRadius, showMoveNumbers, shadowInvScale) {
                const G = this;
                const shInv = shadowInvScale != null && shadowInvScale > 0 ? shadowInvScale : 1;
                const glossOffset = 3 * shInv;
                for (let r = 0; r < boardSize; r++) {
                    for (let c = 0; c < boardSize; c++) {
                        const val = board[r][c];
                        if (val !== 1 && val !== 2) continue;
                        const { x, y } = G.xy(r, c, padding, cellSize, boardSize);
                        const radius = stoneRadius;
                        ctx.save();
                        ctx.shadowBlur = 6 * shInv;
                        ctx.shadowColor = 'rgba(0,0,0,0.5)';
                        ctx.shadowOffsetY = 2 * shInv;
                        const grad = ctx.createRadialGradient(
                            x - glossOffset, y - glossOffset, radius * 0.2, x, y, radius * 1.2
                        );
                        if (val === 1) {
                            grad.addColorStop(0, '#444');
                            grad.addColorStop(0.6, '#222');
                            grad.addColorStop(1, '#111');
                        } else {
                            grad.addColorStop(0, '#fff');
                            grad.addColorStop(0.5, '#eee');
                            grad.addColorStop(1, '#aaa');
                        }
                        ctx.beginPath();
                        ctx.arc(x, y, radius, 0, 2 * Math.PI);
                        ctx.fillStyle = grad;
                        ctx.fill();
                        ctx.restore();
                        if (!showMoveNumbers) {
                            ctx.beginPath();
                            ctx.arc(x - glossOffset, y - glossOffset, radius * 0.15, 0, 2 * Math.PI);
                            ctx.fillStyle = val === 1 ? '#444' : '#fff';
                            ctx.fill();
                        }
                    }
                }
            },
            drawLastMoveMarkersLower(ctx, markers, padding, cellSize, boardSize, stoneRadius) {
                const G = this;
                for (const { row, col, color } of markers) {
                    const { x, y } = G.xy(row, col, padding, cellSize, boardSize);
                    ctx.beginPath();
                    ctx.moveTo(x + stoneRadius, y + stoneRadius);
                    ctx.lineTo(x, y + stoneRadius);
                    ctx.lineTo(x + stoneRadius, y);
                    ctx.closePath();
                    ctx.fillStyle = color === 2 ? '#222' : '#fff';
                    ctx.fill();
                }
            },
            drawLastMoveMarkersUpper(ctx, markers, padding, cellSize, boardSize, markLen) {
                const G = this;
                for (const { row, col, color } of markers) {
                    const { x, y } = G.xy(row, col, padding, cellSize, boardSize);
                    ctx.beginPath();
                    ctx.moveTo(x, y);
                    ctx.lineTo(x + markLen, y);
                    ctx.lineTo(x, y + markLen);
                    ctx.closePath();
                    ctx.fillStyle = color === 2 ? '#222' : '#fff';
                    ctx.fill();
                }
            },
            drawUserBoardMarks(ctx, marksMap, boardSize, padding, cellSize, isVisibleAt) {
                const G = this;
                for (const key of Object.keys(marksMap)) {
                    const [r, c] = key.split(',').map(Number);
                    if (r < 0 || r >= boardSize || c < 0 || c >= boardSize) continue;
                    if (isVisibleAt && !isVisibleAt(r, c)) continue;
                    const ch = marksMap[key];
                    const { x, y } = G.xy(r, c, padding, cellSize, boardSize);
                    const markBgR = this.effectiveCellSize(cellSize) * 0.3;
                    ctx.beginPath();
                    ctx.arc(x, y, markBgR, 0, 2 * Math.PI);
                    ctx.fillStyle = '#edbc80';
                    ctx.fill();
                    const fontPx = this.effectiveCellSize(cellSize) * (ch === '🚩' ? 0.6 : 0.66);
                    ctx.font = `bold ${fontPx}px "Segoe UI", "Apple Color Emoji", "Segoe UI Emoji", sans-serif`;
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillStyle = '#3a281c';
                    ctx.fillText(ch, x, y + 1);
                }
            },
            drawMoveNumbers(ctx, nums, board, boardSize, padding, cellSize) {
                const G = this;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                for (let r = 0; r < boardSize; r++) {
                    for (let c = 0; c < boardSize; c++) {
                        if (nums[r][c] > 0 && board[r][c] !== 0) {
                            const { x, y } = G.xy(r, c, padding, cellSize, boardSize);
                            const numStr = nums[r][c].toString();
                            const fontSize = Math.max(9, Math.floor(
                                this.effectiveCellSize(cellSize) * (numStr.length >= 3 ? 0.34 : 0.44)
                            ));
                            ctx.font = `bold ${fontSize}px Arial`;
                            ctx.fillStyle = board[r][c] === 1 ? '#fff' : '#000';
                            ctx.fillText(numStr, x, y + 1);
                        }
                    }
                }
            },
            drawHoverPreview(ctx, hoverRow, hoverCol, board, padding, cellSize, boardSize, stoneRadius, options) {
                const { tryPlayMode, tryPlayCurrentPlayer, gameOver, isMyTurn, mySlot, isHoverValid, hoverCapture } = options;
                const editing = !!options.editModeEnabled;
                const canHover = editing || tryPlayMode || (!gameOver && isMyTurn);
                if (!canHover || hoverRow < 0 || hoverCol < 0) return;
                if (!editing && board[hoverRow][hoverCol] !== 0) return;
                if (!isHoverValid || (!editing && hoverCapture)) return;
                let hoverColor = null;
                if (editing) {
                    const t = options.editTool || 'empty';
                    if (t === 'white') hoverColor = '#fff';
                    else if (t === 'black') hoverColor = '#222';
                    else if (t !== 'empty') hoverColor = '#666';
                    else return;
                } else {
                    hoverColor = tryPlayMode
                        ? (tryPlayCurrentPlayer === 1 ? '#222' : '#ddd')
                        : (mySlot === 'black' ? '#222' : '#ddd');
                }
                const { x, y } = this.xy(hoverRow, hoverCol, padding, cellSize, boardSize);
                ctx.globalAlpha = 0.45;
                ctx.beginPath();
                ctx.arc(x, y, stoneRadius, 0, 2 * Math.PI);
                ctx.fillStyle = hoverColor;
                ctx.fill();
                ctx.globalAlpha = 1;
            },
            drawHoverCaptureRing(ctx, hoverRow, hoverCol, padding, cellSize, boardSize, stoneRadius, options) {
                const { tryPlayMode, gameOver, isMyTurn, isHoverValid, hoverCapture } = options;
                const strokeInv = options.strokeInvScale != null && options.strokeInvScale > 0
                    ? options.strokeInvScale : 1;
                const canHover = tryPlayMode || (!gameOver && isMyTurn);
                if (!canHover || !hoverCapture || !isHoverValid || hoverRow < 0 || hoverCol < 0) return;
                const { x, y } = this.xy(hoverRow, hoverCol, padding, cellSize, boardSize);
                ctx.save();
                ctx.beginPath();
                ctx.arc(x, y, stoneRadius + 1, 0, 2 * Math.PI);
                ctx.strokeStyle = '#d62828';
                ctx.lineWidth = this.effectiveCellSize(cellSize) * 0.055 * strokeInv;
                ctx.stroke();
                ctx.restore();
            },
            drawEstimateOverlay(ctx, board, boardSize, padding, cellSize, liveBoard, territory) {
                if (!liveBoard || !territory) return;
                const G = this;
                const dotRadius = this.effectiveCellSize(cellSize) * 0.18;
                for (let r = 0; r < boardSize; r++) {
                    for (let c = 0; c < boardSize; c++) {
                        const { x, y } = G.xy(r, c, padding, cellSize, boardSize);
                        if ((board[r][c] === 1 || board[r][c] === 2) && liveBoard[r][c] === 0) {
                            ctx.fillStyle = board[r][c] === 1 ? '#fff' : '#222';
                            ctx.fillRect(x - dotRadius, y - dotRadius, dotRadius * 2, dotRadius * 2);
                        } else if (board[r][c] === 0 && territory[r][c] === 1) {
                            ctx.fillStyle = '#222';
                            ctx.fillRect(x - dotRadius, y - dotRadius, dotRadius * 2, dotRadius * 2);
                        } else if (board[r][c] === 0 && territory[r][c] === 2) {
                            ctx.fillStyle = '#f0f0f0';
                            ctx.fillRect(x - dotRadius, y - dotRadius, dotRadius * 2, dotRadius * 2);
                        }
                    }
                }
            }
        };

        (function initSigmoidGeometry() {
            SigmoidBoardGeom.initGeometry();
            ps.board = Array(ps.BOARD_SIZE).fill().map(() => Array(ps.BOARD_SIZE).fill(0));
        })();

        function pickIntersectionAtCanvas(x, y) {
            return SigmoidBoardGeom.pickIntersection(x, y, ps.PADDING, ps.CELL_SIZE, ps.BOARD_SIZE);
        }

        function updateBoardGeometrySigmoid() {
            SigmoidBoardGeom.initGeometry();
            if (typeof ps.viewZoom === 'number' && ps.viewZoom > 1) {
                const cs = BOARD_VIEW_CS;
                ps.viewZoom = 1;
                ps.viewCenterX = cs / 2;
                ps.viewCenterY = cs / 2;
            }
            drawBoardCore();
            updateBoardMarkOuterPosition();
            try {
                if (_weiqiBindings && typeof _weiqiBindings.updateSeatOverlay === 'function')
                    _weiqiBindings.updateSeatOverlay();
            } catch (e) { /* bindings 尚未初始化 */ }
        }

        function updateBoardMarkOuterPosition() {
            const el = document.getElementById('boardMarkOuter');
            if (!el) return;
            if (window.matchMedia('(max-width: 700px)').matches) {
                el.style.left = '';
                el.style.right = '';
                el.style.bottom = '';
                el.style.top = '';
                el.style.marginLeft = '';
                return;
            }
            const { maxX, maxY } = SigmoidBoardGeom.outerFrameBounds;
            const gap = 6;
            el.style.left = `calc(${(maxX / SIGMOID_CANVAS_SIZE) * 100}% + ${gap}px)`;
            el.style.bottom = `${((SIGMOID_CANVAS_SIZE - maxY) / SIGMOID_CANVAS_SIZE) * 100}%`;
            el.style.right = 'auto';
            el.style.top = 'auto';
        }

const BOARD_MARK_CHAR_LIST = (() => {
            const a = [];
            a.push('?', '!');
            for (let i = 0; i < 26; i++) a.push(String.fromCharCode(65 + i));
            a.push('△', '▽', '♡', '○', '◇', '□', '☆', '×', '🚩');
            return a;
        })();

        // DOM
        const komiInfo = document.getElementById('komiInfo');
        const canvas = document.getElementById('goBoard');
        const ctx = canvas.getContext('2d');
        const turnDisplay = document.getElementById('turnDisplay');
        const colorStatus = document.getElementById('colorStatus');
const scoreTitle = document.getElementById('scoreTitle');
        const scoreBoard = document.getElementById('scoreBoard');
        const leadInfo = document.getElementById('leadInfo');
        const scoreConfirmPanel = document.getElementById('scoreConfirmPanel');
        const scoreConfirmText = document.getElementById('scoreConfirmText');
        const scoreConfirmYes = document.getElementById('scoreConfirmYes');
        const scoreConfirmNo = document.getElementById('scoreConfirmNo');
        const boardMarkSelect = document.getElementById('boardMarkSelect');
        const editModeCheckbox = document.getElementById('editModeCheckbox');
        const editToolSelect = document.getElementById('editToolSelect');
        const clearBoardBtn = document.getElementById('clearBoardBtn');

        QiSquareWeiqiCanvas.initBoardMarkSelectDom(boardMarkSelect, BOARD_MARK_CHAR_LIST);
        QiSquareWeiqiCanvas.initBoardMarkFoldDom(
            document.getElementById('boardMarkPanel'),
            document.getElementById('boardMarkFoldBtn'),
            document.getElementById('boardMarkExpandBtn')
        );

        const isMouseDevice = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
        const R = () => QiWeiqiSquarePageRuntime;

        const SigmoidTriangle = {
            getNeighbors(row, col, boardSize) {
                const out = [];
                const push = (r, c) => {
                    if (r >= 0 && r < boardSize && c >= 0 && c < boardSize) out.push([r, c]);
                };
                push(row - 1, col);
                push(row + 1, col);
                push(row, col - 1);
                push(row, col + 1);
                push(row - 1, col + 1);
                push(row + 1, col - 1);
                return out;
            }
        };

        function sigmoidNb() {
            return (r, c) => SigmoidTriangle.getNeighbors(r, c, ps.BOARD_SIZE);
        }

        function sigmoidCountGroupLiberties(bd, row, col) {
            const color = bd[row][col];
            if (color !== 1 && color !== 2) return 0;
            const visited = new Set();
            const key = (r, c) => r + ',' + c;
            const queue = [[row, col]];
            visited.add(key(row, col));
            const liberties = new Set();
            const nb = sigmoidNb();
            while (queue.length) {
                const [r, c] = queue.shift();
                for (const [nr, nc] of nb(r, c)) {
                    if (bd[nr][nc] === 0) liberties.add(key(nr, nc));
                    else if (bd[nr][nc] === color && !visited.has(key(nr, nc))) {
                        visited.add(key(nr, nc));
                        queue.push([nr, nc]);
                    }
                }
            }
            return liberties.size;
        }

        function sigmoidRemoveGroup(bd, row, col, color) {
            const queue = [[row, col]];
            bd[row][col] = 0;
            const nb = sigmoidNb();
            while (queue.length) {
                const [r, c] = queue.shift();
                for (const [nr, nc] of nb(r, c)) {
                    if (bd[nr][nc] === color) {
                        bd[nr][nc] = 0;
                        queue.push([nr, nc]);
                    }
                }
            }
        }

        function sigmoidTryPlaceStone(boardBefore, row, col, playerVal) {
            if (boardBefore[row][col] !== 0) return null;
            const newBoard = QiSquareWeiqiCanvas.deepCopyBoard(boardBefore);
            newBoard[row][col] = playerVal;
            const enemyColor = 3 - playerVal;
            const checkedEnemy = new Set();
            const nb = sigmoidNb();
            for (const [nr, nc] of nb(row, col)) {
                if (newBoard[nr][nc] === enemyColor) {
                    const k = `${nr},${nc}`;
                    if (!checkedEnemy.has(k)) {
                        checkedEnemy.add(k);
                        if (sigmoidCountGroupLiberties(newBoard, nr, nc) < 1)
                            sigmoidRemoveGroup(newBoard, nr, nc, enemyColor);
                    }
                }
            }
            if (sigmoidCountGroupLiberties(newBoard, row, col) < 1)
                sigmoidRemoveGroup(newBoard, row, col, playerVal);
            return newBoard;
        }

        function sigmoidIsLibertySurrounded(board, libertyRow, libertyCol, opponentColor) {
            for (const [nr, nc] of sigmoidNb()(libertyRow, libertyCol)) {
                if (board[nr][nc] === opponentColor) return true;
            }
            return false;
        }

        function sigmoidRemoveDeadAndDying(srcBoard) {
            let boardCopy = QiSquareWeiqiCanvas.deepCopyBoard(srcBoard);
            let changed = true;
            const n = ps.BOARD_SIZE;
            const nb = sigmoidNb();
            while (changed) {
                changed = false;
                const visited = Array(n).fill().map(() => Array(n).fill(false));
                for (let r = 0; r < n; r++) {
                    for (let c = 0; c < n; c++) {
                        const val = boardCopy[r][c];
                        if ((val === 1 || val === 2) && !visited[r][c]) {
                            const color = val;
                            const queue = [[r, c]];
                            visited[r][c] = true;
                            const stones = [[r, c]];
                            const liberties = new Set();
                            let idx = 0;
                            while (idx < queue.length) {
                                const [rr, cc] = queue[idx++];
                                for (const [nr, nc] of nb(rr, cc)) {
                                    if (boardCopy[nr][nc] === 0) liberties.add(nr + ',' + nc);
                                    else if (boardCopy[nr][nc] === color && !visited[nr][nc]) {
                                        visited[nr][nc] = true;
                                        queue.push([nr, nc]);
                                        stones.push([nr, nc]);
                                    }
                                }
                            }
                            if (liberties.size === 0) {
                                for (const [rr, cc] of stones) boardCopy[rr][cc] = 0;
                                changed = true;
                                continue;
                            }
                            if (liberties.size <= 2) {
                                let allControlled = true;
                                for (const lib of liberties) {
                                    const [lr, lc] = lib.split(',').map(Number);
                                    if (!sigmoidIsLibertySurrounded(boardCopy, lr, lc, 3 - color)) {
                                        allControlled = false;
                                        break;
                                    }
                                }
                                if (allControlled) {
                                    for (const [rr, cc] of stones) boardCopy[rr][cc] = 0;
                                    changed = true;
                                }
                            }
                        }
                    }
                }
            }
            return boardCopy;
        }

        function sigmoidAssignTerritoryWithRange(liveBoard) {
            const n = ps.BOARD_SIZE;
            const territory = Array(n).fill().map(() => Array(n).fill(0));
            const nb = sigmoidNb();
            for (let r = 0; r < n; r++) {
                for (let c = 0; c < n; c++) {
                    if (liveBoard[r][c] !== 0) continue;
                    const maxDist = (r <= 1 || r >= n - 2 || c <= 1 || c >= n - 2) ? 5 : 4;
                    let blackMin = Infinity;
                    let whiteMin = Infinity;
                    const dist = Array(n).fill().map(() => Array(n).fill(Infinity));
                    dist[r][c] = 0;
                    const queue = [[r, c]];
                    let front = 0;
                    while (front < queue.length) {
                        const [cr, cc] = queue[front++];
                        const d = dist[cr][cc];
                        if (d > maxDist) continue;
                        if (liveBoard[cr][cc] === 1 && d < blackMin) blackMin = d;
                        if (liveBoard[cr][cc] === 2 && d < whiteMin) whiteMin = d;
                        for (const [nr, nc] of nb(cr, cc)) {
                            if (dist[nr][nc] !== Infinity) continue;
                            dist[nr][nc] = d + 1;
                            queue.push([nr, nc]);
                        }
                    }
                    if (blackMin <= maxDist && whiteMin <= maxDist) {
                        if (blackMin < whiteMin) territory[r][c] = 1;
                        else if (whiteMin < blackMin) territory[r][c] = 2;
                        else territory[r][c] = 3;
                    } else if (blackMin <= maxDist) territory[r][c] = 1;
                    else if (whiteMin <= maxDist) territory[r][c] = 2;
                    else territory[r][c] = 3;
                }
            }
            return territory;
        }

        function sigmoidComputeScore(liveBoard, territory) {
            const n = ps.BOARD_SIZE;
            let blackStones = 0;
            let whiteStones = 0;
            let blackTerritory = 0;
            let whiteTerritory = 0;
            let publicTerritory = 0;
            for (let r = 0; r < n; r++) {
                for (let c = 0; c < n; c++) {
                    if (liveBoard[r][c] === 1) blackStones++;
                    else if (liveBoard[r][c] === 2) whiteStones++;
                    else if (liveBoard[r][c] === 0) {
                        if (territory[r][c] === 1) blackTerritory++;
                        else if (territory[r][c] === 2) whiteTerritory++;
                        else if (territory[r][c] === 3) publicTerritory++;
                    }
                }
            }
            return {
                blackTotal: blackStones + blackTerritory + publicTerritory / 2,
                whiteTotal: whiteStones + whiteTerritory + publicTerritory / 2
            };
        }

        const BOARD_VIEW_CS = QiSquareWeiqiCanvas.DEFAULT_CANVAS_SIZE;
        let boardScrollbarProgrammatic = false;

        function viewCenterBoundsForScrollbars() {
            const z = Math.max(1, Math.min(10, ps.viewZoom || 1));
            const half = (BOARD_VIEW_CS / 2) / z;
            return {
                minX: half,
                maxX: BOARD_VIEW_CS - half,
                minY: half,
                maxY: BOARD_VIEW_CS - half
            };
        }

        function clampBoardView() {
            let z = ps.viewZoom;
            if (!Number.isFinite(z)) z = 1;
            z = Math.max(1, Math.min(10, z));
            ps.viewZoom = z;
            if (z <= 1) {
                ps.viewCenterX = BOARD_VIEW_CS / 2;
                ps.viewCenterY = BOARD_VIEW_CS / 2;
                return;
            }
            const half = (BOARD_VIEW_CS / 2) / z;
            ps.viewCenterX = Math.min(BOARD_VIEW_CS - half, Math.max(half, ps.viewCenterX));
            ps.viewCenterY = Math.min(BOARD_VIEW_CS - half, Math.max(half, ps.viewCenterY));
        }

        /** 落座蒙版显示时不允许缩放（含对局中途再入座） */
        function boardViewZoomAllowed() {
            const o = document.querySelector('.board-container > .qi-seat-overlay');
            return !(o && !o.hidden);
        }

        function resetBoardViewZoom() {
            ps.viewZoom = 1;
            ps.viewCenterX = BOARD_VIEW_CS / 2;
            ps.viewCenterY = BOARD_VIEW_CS / 2;
            syncScrollbarsFromView();
            boardUpdateGrabCursor();
        }

        function applyZoomKeepingScreenPoint(ssx, ssy, zNew) {
            const z0 = ps.viewZoom;
            const cs = BOARD_VIEW_CS;
            const Lx = (ssx - cs / 2) / z0 + ps.viewCenterX;
            const Ly = (ssy - cs / 2) / z0 + ps.viewCenterY;
            ps.viewZoom = zNew;
            ps.viewCenterX = Lx - (ssx - cs / 2) / zNew;
            ps.viewCenterY = Ly - (ssy - cs / 2) / zNew;
            clampBoardView();
        }

        function syncScrollbarsFromView() {
            const sx = document.getElementById('boardScrollX');
            const sy = document.getElementById('boardScrollY');
            if (!sx || !sy) return;
            if (ps.viewZoom <= 1) {
                sx.style.display = 'none';
                sy.style.display = 'none';
                return;
            }
            sx.style.display = 'block';
            sy.style.display = 'block';
            const b = viewCenterBoundsForScrollbars();
            const spanX = b.maxX - b.minX;
            const spanY = b.maxY - b.minY;
            boardScrollbarProgrammatic = true;
            sx.value = spanX > 1e-6 ? String(Math.round((ps.viewCenterX - b.minX) / spanX * 1000)) : '500';
            sy.value = spanY > 1e-6 ? String(Math.round((b.maxY - ps.viewCenterY) / spanY * 1000)) : '500';
            boardScrollbarProgrammatic = false;
        }

        function getBoardViewTransform() {
            const cs = BOARD_VIEW_CS;
            let z = ps.viewZoom;
            if (!Number.isFinite(z)) z = 1;
            z = Math.max(1, Math.min(10, z));
            const vcx = typeof ps.viewCenterX === 'number' ? ps.viewCenterX : cs / 2;
            const vcy = typeof ps.viewCenterY === 'number' ? ps.viewCenterY : cs / 2;
            return { z, vcx, vcy, cs };
        }

        const domPage = {
            turnDisplay,
            scoreTitle,
            scoreBoard,
            leadInfo,
            scoreConfirmPanel,
            scoreConfirmText,
            komiInfo,
            canvas,
            ctx,
            boardMarkSelect,
            colorStatus
        };
        const pageOpts = {
            recordDownloadPrefix,
            minLib,
            maxWeakLiberties: 2,
            gameType,
            roomId,
            roomPassword,
            isMouseDevice,
            tryPlaceStone: sigmoidTryPlaceStone,
            removeDeadAndDying: sigmoidRemoveDeadAndDying,
            assignTerritoryWithRange: sigmoidAssignTerritoryWithRange,
            rebuildLiveReplayFromMoveCoords(moveCoords) {
                const ob = ps.liveOpeningBoard;
                const o = R().rebuildLiveReplayFromMoveCoords(
                    moveCoords,
                    sigmoidTryPlaceStone,
                    QiSquareWeiqiCanvas.deepCopyBoard,
                    () => ob ? QiSquareWeiqiCanvas.deepCopyBoard(ob) : QiSquareWeiqiCanvas.initBoardArray(ps.BOARD_SIZE)
                );
                ps.liveReplayBoards = o.liveReplayBoards;
                ps.liveReplayMarkers = o.liveReplayMarkers;
                ps.liveReplayStepPlayers = o.liveReplayStepPlayers;
            }
        };
        const page = QiWeiqiSquarePageRuntime.create(ps, domPage, pageOpts);
        const {
            mobileTwoStepPlacing,
            clearMobileMovePreview,
            drawBoard: drawBoardCore,
            computeStoneNumbers,
            isUserBoardMarkVisibleAt,
            updateTurn,
            showEstimate,
            clearEstimate,
            downloadRecord,
            showScoreConfirm,
            hideScoreConfirm,
            enterReplayMode,
            exitReplayMode,
            setReplayStep,
            updateReplayUI,
            enterTryPlay,
            exitTryPlay,
            tryPlayMove,
            setTryPlayStep,
            updateTryPlayDisplay,
            rebuildLiveReplayFromMoveCoords,
            applyLiveViewBoard,
            updateLiveReplayPanelUI,
            setLiveViewStep,
            connectWebSocket,
            initBoardArray,
            syncState: syncStateBase,
            commitMove,
            canvasCoordsFromClient,
            boardScreenPointFromClient,
            applyUserBoardMark
        } = page;

        function syncState(state) {
            ps.liveOpeningBoard = state.initialBoard
                ? QiSquareWeiqiCanvas.deepCopyBoard(state.initialBoard)
                : null;
            ps.gameStarted = (state.numberOfHands || 1) > 1;
            syncStateBase(state);
            updateEditModeUI();
        }

        function updateEditModeUI() {
            const canEdit = !ps.gameStarted && !ps.gameOver && ps.mySlot === null;
            if (editModeCheckbox) editModeCheckbox.disabled = !canEdit;
            if (!canEdit && ps.editModeEnabled) {
                ps.editModeEnabled = false;
                if (editModeCheckbox) editModeCheckbox.checked = false;
                if (editToolSelect) editToolSelect.classList.add('hidden');
                if (clearBoardBtn) clearBoardBtn.classList.add('hidden');
            }
        }

        function sendEditBoard(newBoard) {
            if (!ps.ws || ps.ws.readyState !== WebSocket.OPEN) return;
            ps.ws.send(JSON.stringify({ type: 'editBoard', board: newBoard }));
        }

        function applyEditChange(newBoard) {
            ps.board = QiSquareWeiqiCanvas.deepCopyBoard(newBoard);
            if (!ps.replayMode) {
                const preGame = !ps.gameStarted && (ps.numberOfHands || 1) <= 1;
                if (preGame) {
                    ps.liveOpeningBoard = QiSquareWeiqiCanvas.deepCopyBoard(ps.board);
                    if (ps.liveReplayBoards.length === 0) {
                        ps.liveReplayBoards = [QiSquareWeiqiCanvas.deepCopyBoard(ps.board)];
                        ps.liveReplayMarkers = [[]];
                        ps.liveReplayStepPlayers = [0];
                        ps.liveViewStep = 0;
                    } else {
                        const i = Math.min(ps.liveViewStep, ps.liveReplayBoards.length - 1);
                        ps.liveReplayBoards[i] = QiSquareWeiqiCanvas.deepCopyBoard(ps.board);
                    }
                } else if (ps.liveReplayBoards.length > 0) {
                    const i = Math.min(ps.liveViewStep, ps.liveReplayBoards.length - 1);
                    ps.liveReplayBoards[i] = QiSquareWeiqiCanvas.deepCopyBoard(ps.board);
                }
            }
            drawBoardCore();
            sendEditBoard(ps.board);
        }

        if (editModeCheckbox) {
            editModeCheckbox.addEventListener('change', () => {
                ps.editModeEnabled = editModeCheckbox.checked;
                if (editToolSelect) editToolSelect.classList.toggle('hidden', !ps.editModeEnabled);
                if (clearBoardBtn) clearBoardBtn.classList.toggle('hidden', !ps.editModeEnabled);
            });
        }
        if (editToolSelect) {
            editToolSelect.addEventListener('change', () => {
                ps.editTool = editToolSelect.value;
                drawBoardCore();
            });
        }
        if (clearBoardBtn) {
            clearBoardBtn.addEventListener('click', () => {
                applyEditChange(Array(ps.BOARD_SIZE).fill().map(() => Array(ps.BOARD_SIZE).fill(0)));
            });
        }

        pageOpts.drawBoard = function drawBoardWithSigmoidLinks() {
            const d = QiSquareWeiqiCanvas.draw;
            const G = SigmoidBoardGeom;
            const cs = BOARD_VIEW_CS;
            const pad = ps.PADDING;
            const cellSize = ps.CELL_SIZE;
            const n = ps.BOARD_SIZE;
            G.recomputeDisplayFit(pad, cellSize, n);
            const { z, vcx, vcy } = getBoardViewTransform();
            d.clear(ctx, cs);
            const useView = z > 1;
            const invZ = useView ? 1 / z : 1;
            if (useView) {
                ctx.save();
                ctx.translate(cs / 2, cs / 2);
                ctx.scale(z, z);
                ctx.translate(-vcx, -vcy);
            }
            G.drawWoodenFrame(ctx, n, pad, cellSize);
            G.drawGrid(ctx, n, pad, cellSize, useView ? invZ : undefined);
            G.drawAntiDiagonalLines(ctx, n, pad, cellSize, useView ? invZ : undefined);
            G.drawStarPoints(ctx, n, pad, cellSize);
            G.drawCoordLabels(ctx, n, pad, cellSize);
            const cellDisp = G.effectiveCellSize(cellSize);
            const stoneRadius = cellDisp * 0.44;
            const markLenDefault = cellDisp * 0.352;
            const lowerLastMoveMarker = ps.showMoveNumbers || ps.showEstimateActive;
            if (lowerLastMoveMarker) {
                G.drawLastMoveMarkersLower(ctx, ps.lastMoveMarkers, pad, cellSize, n, stoneRadius);
            }
            G.drawStones(ctx, ps.board, n, pad, cellSize, stoneRadius, ps.showMoveNumbers, invZ);
            if (!lowerLastMoveMarker) {
                G.drawLastMoveMarkersUpper(ctx, ps.lastMoveMarkers, pad, cellSize, n, markLenDefault);
            }
            G.drawUserBoardMarks(ctx, ps.userBoardMarks, n, pad, cellSize, isUserBoardMarkVisibleAt);
            if (ps.showMoveNumbers) {
                const nums = computeStoneNumbers();
                G.drawMoveNumbers(ctx, nums, ps.board, n, pad, cellSize);
            }
            G.drawHoverPreview(ctx, ps.hoverRow, ps.hoverCol, ps.board, pad, cellSize, n, stoneRadius, {
                tryPlayMode: ps.tryPlayMode,
                tryPlayCurrentPlayer: ps.tryPlayCurrentPlayer,
                gameOver: ps.gameOver,
                isMyTurn: ps.isMyTurn,
                mySlot: ps.mySlot,
                isHoverValid: ps.isHoverValid,
                hoverCapture: !!ps.hoverCapture,
                editModeEnabled: !!ps.editModeEnabled,
                editTool: ps.editTool || 'empty'
            });
            if (ps.hoverCapture && !ps.editModeEnabled) {
                G.drawHoverCaptureRing(ctx, ps.hoverRow, ps.hoverCol, pad, cellSize, n, stoneRadius, {
                    tryPlayMode: ps.tryPlayMode,
                    gameOver: ps.gameOver,
                    isMyTurn: ps.isMyTurn,
                    isHoverValid: ps.isHoverValid,
                    hoverCapture: !!ps.hoverCapture,
                    strokeInvScale: invZ
                });
            }
            if (ps.showEstimateActive && ps.cachedLiveBoard && ps.cachedTerritory) {
                G.drawEstimateOverlay(ctx, ps.board, n, pad, cellSize, ps.cachedLiveBoard, ps.cachedTerritory);
            }
            if (useView) ctx.restore();
            syncScrollbarsFromView();
            updateBoardMarkOuterPosition();
        };

        updateBoardMarkOuterPosition();
        window.addEventListener('resize', updateBoardMarkOuterPosition);

        const _weiqiBindings = QiBoardRoomClient.createWeiqiMessageBindings({
            roomId,
            gameType,
            pageState: ps,
            drawBoard: drawBoardCore,
            exitTryPlay,
            enterTryPlay,
            setTryPlayStep,
            setReplayStep,
            setLiveViewStep,
            getWs: () => ps.ws,
            getBoardSize: () => ps.BOARD_SIZE,
            setBoardSize: (n) => { ps.BOARD_SIZE = n; },
            getKomi: () => ps.KOMI,
            setKomi: (n) => { ps.KOMI = n; },
            getBoard: () => ps.board,
            setBoard: (b) => { ps.board = b; },
            getSlots: () => ps.slots,
            setSlots: (s) => { ps.slots = s; },
            getMySlot: () => ps.mySlot,
            setMySlot: (s) => { ps.mySlot = s; },
            getGameOver: () => ps.gameOver,
            setGameOver: (v) => { ps.gameOver = v; },
            getWinner: () => ps.winner,
            setWinner: (w) => { ps.winner = w; },
            getReplayMode: () => ps.replayMode,
            getShowEstimateActive: () => ps.showEstimateActive,
            setShowEstimateActive: (v) => { ps.showEstimateActive = v; },
            getWaitingScoreConfirm: () => ps.waitingScoreConfirm,
            setWaitingScoreConfirm: (v) => { ps.waitingScoreConfirm = v; },
            getIRejected: () => ps.iRejected,
            setIRejected: (v) => { ps.iRejected = v; },
            colorStatus,
            scoreTitle,
            turnDisplay,
syncState,
            updateBoardGeometry: updateBoardGeometrySigmoid,
            initBoardArray,
            exitReplayMode,
            clearEstimate,
            hideScoreConfirm,
            showEstimate,
            clearMobileMovePreview,
            downloadRecord,
            enterReplayMode,
            updateTurn,
            updateReplayUI,
            showScoreConfirm,
            isMouseDevice,
            standardWeiqiMatchTime,
            boardSeatOverlay: true,
            seatOverlayShape: 'rhombus',
            seatOverlayCornerRadius: SIGMOID_FRAME_CORNER_RADIUS,
            seatOverlayViewSize: SIGMOID_CANVAS_SIZE,
            getSeatOverlayVertices: () => {
                if (ps.PADDING == null || ps.CELL_SIZE == null)
                    SigmoidBoardGeom.initGeometry();
                else
                    SigmoidBoardGeom.recomputeDisplayFit(ps.PADDING, ps.CELL_SIZE, ps.BOARD_SIZE);
                return SigmoidBoardGeom.frameOuterVerts(ps.PADDING, ps.CELL_SIZE, ps.BOARD_SIZE);
            },
            onSeatOverlayUpdated({ visible }) {
                if (visible && ps.viewZoom > 1) resetBoardViewZoom();
            },
            onNewGameStarted() {
                ps.editModeEnabled = false;
                if (editModeCheckbox) editModeCheckbox.checked = false;
                if (editToolSelect) editToolSelect.classList.add('hidden');
                if (clearBoardBtn) clearBoardBtn.classList.add('hidden');
            },
            onBoardSizeChanged: (msg) => {
                if (!msg.boardSize) return;
                const bs = msg.boardSize;
                if (bs !== ps.BOARD_SIZE) {
                    ps.BOARD_SIZE = bs;
                    ps.board = initBoardArray(bs);
                    updateBoardGeometrySigmoid();
                } else {
                    const sel = document.getElementById('boardSizeSelect');
                    if (sel) sel.value = String(bs);
                    drawBoardCore();
                }
            }
        });
        const weiqiHandleMessageInner = _weiqiBindings.handleMessage;
        const updateRecordButtons = _weiqiBindings.updateRecordButtons;
        const updateRadioStyles = _weiqiBindings.updateRadioStyles;

        function lastMoveMarkerKey() {
            const m = ps.lastMoveMarkers && ps.lastMoveMarkers[0];
            if (!m || m.row < 0 || m.col < 0) return '';
            return `${m.row},${m.col},${m.color}`;
        }

        function maybeCenterViewOnOpponentMove(msg, keyBefore) {
            if (ps.viewZoom <= 1 || !ps.mySlot || ps.replayMode || ps.tryPlayMode) return;
            if (msg.type !== 'broadcast' && msg.type !== 'gameState') return;
            if (msg.type === 'broadcast' && msg.action !== 'move') return;
            const m = ps.lastMoveMarkers && ps.lastMoveMarkers[0];
            if (!m || m.row < 0 || m.col < 0) return;
            if (lastMoveMarkerKey() === keyBefore) return;
            const oppColor = ps.mySlot === 'black' ? 2 : 1;
            if (m.color !== oppColor) return;
            const p = SigmoidBoardGeom.xy(m.row, m.col, ps.PADDING, ps.CELL_SIZE, ps.BOARD_SIZE);
            ps.viewCenterX = p.x;
            ps.viewCenterY = p.y;
            clampBoardView();
            drawBoardCore();
        }

        function handleMessage(msg) {
            if (msg.type === 'boardSizeChanged') {
                syncState(msg);
                clearEstimate();
                _weiqiBindings.updateRadioStyles();
                return;
            }
            const mkBefore = lastMoveMarkerKey();
            weiqiHandleMessageInner(msg);
            if (msg.type === 'newGameStarted' || msg.type === 'roomReset')
                resetBoardViewZoom();
            maybeCenterViewOnOpponentMove(msg, mkBefore);
        }

        let suppressCanvasClickAfterLongMark = false;
        let suppressCanvasClickAfterPan = false;

        const LONG_MARK_MS = 500;
        const LONG_MARK_MOVE_CANCEL = 14;
        let longMarkTimer = null;
        let longMarkStart = null;

        function clearLongMarkTouch() {
            if (longMarkTimer) {
                clearTimeout(longMarkTimer);
                longMarkTimer = null;
            }
            longMarkStart = null;
        }

        (function initWeiqiBoardScrollbars() {
            const sx = document.getElementById('boardScrollX');
            const sy = document.getElementById('boardScrollY');
            if (!sx || !sy) return;
            function applyFromSliders() {
                if (boardScrollbarProgrammatic) return;
                if (ps.viewZoom <= 1) return;
                const b = viewCenterBoundsForScrollbars();
                const tx = Number(sx.value) / 1000;
                const ty = 1 - Number(sy.value) / 1000;
                ps.viewCenterX = b.minX + tx * (b.maxX - b.minX);
                ps.viewCenterY = b.minY + ty * (b.maxY - b.minY);
                clampBoardView();
                drawBoardCore();
            }
            sx.addEventListener('input', applyFromSliders);
            sy.addEventListener('input', applyFromSliders);
        })();

        canvas.addEventListener('wheel', (e) => {
            if (!boardViewZoomAllowed()) return;
            const z0 = ps.viewZoom;
            const z1 = Math.max(1, Math.min(10, z0 * Math.exp(-e.deltaY * 0.002)));
            if (Math.abs(z1 - z0) < 1e-8) return;
            e.preventDefault();
            const ss = boardScreenPointFromClient(e.clientX, e.clientY);
            applyZoomKeepingScreenPoint(ss.x, ss.y, z1);
            drawBoardCore();
        }, { passive: false });

        let boardMousePanning = false;
        let boardPanLastScreen = null;

        function boardUpdateGrabCursor() {
            if (boardMousePanning) {
                canvas.style.cursor = 'grabbing';
            } else {
                canvas.style.cursor = ps.viewZoom > 1 ? 'grab' : 'default';
            }
        }

        canvas.addEventListener('mousedown', (e) => {
            if (e.button !== 0 || ps.viewZoom <= 1) return;
            boardMousePanning = true;
            boardPanLastScreen = boardScreenPointFromClient(e.clientX, e.clientY);
            boardUpdateGrabCursor();
            e.preventDefault();
        });

        window.addEventListener('mousemove', (e) => {
            if (!boardMousePanning || !boardPanLastScreen) return;
            const p = boardScreenPointFromClient(e.clientX, e.clientY);
            const dx = p.x - boardPanLastScreen.x;
            const dy = p.y - boardPanLastScreen.y;
            ps.viewCenterX -= dx / ps.viewZoom;
            ps.viewCenterY -= dy / ps.viewZoom;
            boardPanLastScreen = p;
            clampBoardView();
            drawBoardCore();
        });

        window.addEventListener('mouseup', () => {
            if (!boardMousePanning) return;
            boardMousePanning = false;
            boardPanLastScreen = null;
            boardUpdateGrabCursor();
        });

        let pinchGesture = false;
        let pinchStartDist = 1;
        let pinchStartZoom = 1;
        let touchPanLastScreen = null;
        let touchDidPan = false;

        function touchDistanceScreen(touches) {
            const a = boardScreenPointFromClient(touches[0].clientX, touches[0].clientY);
            const b = boardScreenPointFromClient(touches[1].clientX, touches[1].clientY);
            return Math.hypot(b.x - a.x, b.y - a.y);
        }

        function touchMidpointScreen(touches) {
            const a = boardScreenPointFromClient(touches[0].clientX, touches[0].clientY);
            const b = boardScreenPointFromClient(touches[1].clientX, touches[1].clientY);
            return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
        }

        canvas.addEventListener('touchstart', (e) => {
            if (e.touches.length >= 2) {
                if (!boardViewZoomAllowed()) return;
                clearLongMarkTouch();
                pinchGesture = true;
                pinchStartDist = Math.max(1e-6, touchDistanceScreen(e.touches));
                pinchStartZoom = ps.viewZoom;
                touchPanLastScreen = null;
            } else if (e.touches.length === 1 && ps.viewZoom > 1) {
                touchPanLastScreen = boardScreenPointFromClient(e.touches[0].clientX, e.touches[0].clientY);
            }
        }, { capture: true, passive: true });

        canvas.addEventListener('touchmove', (e) => {
            if (pinchGesture && e.touches.length >= 2) {
                if (!boardViewZoomAllowed()) {
                    pinchGesture = false;
                    return;
                }
                e.preventDefault();
                const d = touchDistanceScreen(e.touches);
                const z1 = Math.max(1, Math.min(10, pinchStartZoom * (d / pinchStartDist)));
                const mid = touchMidpointScreen(e.touches);
                applyZoomKeepingScreenPoint(mid.x, mid.y, z1);
                drawBoardCore();
                return;
            }
            if (!pinchGesture && e.touches.length === 1 && ps.viewZoom > 1 && touchPanLastScreen) {
                const cur = boardScreenPointFromClient(e.touches[0].clientX, e.touches[0].clientY);
                const dx = cur.x - touchPanLastScreen.x;
                const dy = cur.y - touchPanLastScreen.y;
                if (dx * dx + dy * dy > 9) {
                    touchDidPan = true;
                    e.preventDefault();
                    ps.viewCenterX -= dx / ps.viewZoom;
                    ps.viewCenterY -= dy / ps.viewZoom;
                    touchPanLastScreen = cur;
                    clampBoardView();
                    drawBoardCore();
                }
            }
        }, { passive: false });

        canvas.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            const { x, y } = canvasCoordsFromClient(e.clientX, e.clientY);
            const { row, col } = pickIntersectionAtCanvas(x, y);
            if (ps.editModeEnabled) {
                if (row >= 0 && col >= 0 && ps.board[row][col] !== 0) {
                    const nb = QiSquareWeiqiCanvas.deepCopyBoard(ps.board);
                    nb[row][col] = 0;
                    applyEditChange(nb);
                }
                return;
            }
            applyUserBoardMark(row, col);
        });

        canvas.addEventListener('touchstart', (e) => {
            if (e.touches.length !== 1) return;
            const t = e.touches[0];
            longMarkStart = { x: t.clientX, y: t.clientY };
            longMarkTimer = setTimeout(() => {
                longMarkTimer = null;
                if (!longMarkStart) return;
                const { x, y } = canvasCoordsFromClient(longMarkStart.x, longMarkStart.y);
                const { row, col } = pickIntersectionAtCanvas(x, y);
                applyUserBoardMark(row, col);
                suppressCanvasClickAfterLongMark = true;
                setTimeout(() => { suppressCanvasClickAfterLongMark = false; }, 450);
                longMarkStart = null;
            }, LONG_MARK_MS);
        }, { passive: true });

        canvas.addEventListener('touchmove', (e) => {
            if (!longMarkTimer || !longMarkStart || e.touches.length !== 1) return;
            const t = e.touches[0];
            const dx = t.clientX - longMarkStart.x;
            const dy = t.clientY - longMarkStart.y;
            if (dx * dx + dy * dy > LONG_MARK_MOVE_CANCEL * LONG_MARK_MOVE_CANCEL) {
                clearTimeout(longMarkTimer);
                longMarkTimer = null;
            }
        }, { passive: true });

        function onCanvasTouchEnd(e) {
            clearLongMarkTouch();
            if (e.touches.length < 2) pinchGesture = false;
            if (e.touches.length === 0) {
                if (touchDidPan) {
                    suppressCanvasClickAfterPan = true;
                    setTimeout(() => { suppressCanvasClickAfterPan = false; }, 450);
                }
                touchDidPan = false;
                touchPanLastScreen = null;
            } else if (e.touches.length === 1 && ps.viewZoom > 1) {
                touchPanLastScreen = boardScreenPointFromClient(e.touches[0].clientX, e.touches[0].clientY);
            }
        }
        canvas.addEventListener('touchend', onCanvasTouchEnd);
        canvas.addEventListener('touchcancel', () => {
            clearLongMarkTouch();
            pinchGesture = false;
            touchPanLastScreen = null;
            touchDidPan = false;
        });

        canvas.addEventListener('click', (e) => {
            if (suppressCanvasClickAfterLongMark || suppressCanvasClickAfterPan) {
                e.preventDefault();
                return;
            }
            const { x, y } = canvasCoordsFromClient(e.clientX, e.clientY);
            const { row, col } = pickIntersectionAtCanvas(x, y);

            if (ps.editModeEnabled) {
                if (row >= 0 && col >= 0) {
                    let newVal = 0;
                    switch (ps.editTool) {
                        case 'black': newVal = 1; break;
                        case 'white': newVal = 2; break;
                        default: newVal = 0;
                    }
                    if (ps.board[row][col] === newVal) return;
                    const nb = QiSquareWeiqiCanvas.deepCopyBoard(ps.board);
                    nb[row][col] = newVal;
                    applyEditChange(nb);
                }
                return;
            }

            if (ps.tryPlayMode && ps.replayMode) {
                if (row < 0 || col < 0) {
                    if (mobileTwoStepPlacing()) clearMobileMovePreview();
                    drawBoardCore();
                    return;
                }
                if (ps.board[row][col] !== 0) return;
                if (mobileTwoStepPlacing()) {
                    if (ps.hoverRow === row && ps.hoverCol === col && ps.isHoverValid) {
                        clearMobileMovePreview();
                        tryPlayMove(row, col);
                    } else {
                        ps.hoverRow = row;
                        ps.hoverCol = col;
                        ps.isHoverValid = true;
                        drawBoardCore();
                    }
                    return;
                }
                tryPlayMove(row, col);
                return;
            }
            if (ps.gameOver) return;
            if (!ps.isMyTurn) return;
            if (ps.waitingScoreConfirm) return;

            if (row < 0 || col < 0) {
                if (mobileTwoStepPlacing()) clearMobileMovePreview();
                drawBoardCore();
                return;
            }
            if (ps.board[row][col] !== 0) return;

            if (mobileTwoStepPlacing()) {
                if (ps.hoverRow === row && ps.hoverCol === col && ps.isHoverValid) {
                    clearMobileMovePreview();
                    commitMove(row, col);
                    drawBoardCore();
                } else {
                    ps.hoverRow = row;
                    ps.hoverCol = col;
                    ps.isHoverValid = true;
                    drawBoardCore();
                }
                return;
            }
            commitMove(row, col);
        });

        if (isMouseDevice)
        {
            canvas.addEventListener('mousemove', (e) => {
                if (boardMousePanning) return;
                if (ps.waitingScoreConfirm) {
                    if (ps.isHoverValid) { ps.isHoverValid = false; ps.hoverRow = -1; ps.hoverCol = -1; drawBoardCore(); }
                    return;
                }
                const { x, y } = canvasCoordsFromClient(e.clientX, e.clientY);
                const { row, col } = pickIntersectionAtCanvas(x, y);
                ps.hoverRow = row; ps.hoverCol = col;
                ps.isHoverValid = (row >= 0 && col >= 0 && (ps.editModeEnabled || ps.board[row][col] === 0));
                boardUpdateGrabCursor();
                drawBoardCore();
            });
            canvas.addEventListener('mouseleave', () => {
                if (!ps.waitingScoreConfirm) {
                    ps.isHoverValid = false;
                    ps.hoverRow = -1; ps.hoverCol = -1;
                    if (!boardMousePanning) boardUpdateGrabCursor();
                    drawBoardCore();
                }
            });
        }

        // 数点确认按钮事件
        if (scoreConfirmYes)
        {
            scoreConfirmYes.onclick = () => {
                ps.ws.send(JSON.stringify({ type: 'scoreResponse', accept: true }));
                hideScoreConfirm();
            };
            scoreConfirmNo.onclick = () => {
                ps.iRejected = true;
                ps.ws.send(JSON.stringify({ type: 'scoreResponse', accept: false }));
                hideScoreConfirm();
                if (ps.showEstimateActive) {
                    ps.showEstimateActive = false;
                    clearEstimate();
                }
                ps.waitingScoreConfirm = false;
            };
        }
        connectWebSocket(handleMessage);
        })();
    }
};
