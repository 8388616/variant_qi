window.RoomPlugins = window.RoomPlugins || {};
window.RoomPlugins["match-wuziqi"] = {
    shell: {
        "title": "消除五子棋",
        "rulesHtml": "基本规则同五子棋。<br /><br />落子后，若形成连五，则可以任选一枚对手的棋子移除，同时获得形成连五数量的分数（连六算2分，依次类推），然后消除所有形成的连五；移除完成后由己方继续落子。<br /><br />黑方积22分胜或白方积20分胜。达到制胜分数后，仍须完成本回合内所有消除、移除与继续落子；轮到对方行棋时再判定是否因积分获胜。",
        "defaultKomiText": "无禁手",
        "boardSizeMin": 7,
        "boardSizeMax": 15,
        "defaultBoardSize": 13,
        "minLib": 1,
        "recordDownloadPrefix": "消除五子棋",
        "standardWeiqiMatchTime": true,
        "features": {
            "editBoard": true
        },
        "editTools": [
            { "value": "empty", "label": "空" },
            { "value": "black", "label": "黑子" },
            { "value": "white", "label": "白子" }
        ]
    },
    mount: function (ctx) {
        var gameType = ctx.gameType;
        var roomId = ctx.roomId;
        var roomPassword = ctx.roomPassword || null;
        var config = ctx.config || {};
        var recordDownloadPrefix = config.recordDownloadPrefix != null ? config.recordDownloadPrefix : "消除五子棋";
        var minLib = config.minLib != null ? config.minLib : 1;
        var standardWeiqiMatchTime = config.standardWeiqiMatchTime != null ? config.standardWeiqiMatchTime : true;


        (function () {
const R = () => QiWeiqiSquarePageRuntime;

const MATCH_SCORE_BLACK_WIN = 22;
        const MATCH_SCORE_WHITE_WIN = 20;

        const ps = {
            BOARD_SIZE: 13,
            KOMI: 0,
            PADDING: 0,
            CELL_SIZE: 0,
            numberOfHands: 1,
            currentPlayer: 1,
            mySlot: null,
            gameOver: false,
            winner: null,
            lastMoveMarkers: [],
            showEstimateActive: false,
            cachedLiveBoard: null,
            cachedTerritory: null,
            waitingScoreConfirm: false,
            iRejected: false,
            ws: null,
            isMyTurn: false,
            slots: { black: false, white: false },
            reconnectTimer: null,
            replayMode: false,
            replayBoards: [],
            replayMarkers: [],
            replayStepPlayers: [],
            replayStep: 0,
            replayTotalSteps: 0,
            showMoveNumbers: false,
            moveLog: [],
            moveHistory: [],
            tryPlayMode: false,
            tryPlayBaseStep: 0,
            tryPlayBoards: [],
            tryPlayMarkers: [],
            tryPlayCurrentPlayer: 1,
            tryPlayStep: 0,
            tryPlayTotalSteps: 0,
            liveReplayBoards: [],
            liveReplayMarkers: [],
            liveReplayStepPlayers: [],
            liveViewStep: 0,
            liveFollowLatest: true,
            userBoardMarks: Object.create(null),
            hoverRow: -1,
            hoverCol: -1,
            isHoverValid: false,
            hoverCapture: false,
            blackScore: 0,
            whiteScore: 0,
            pendingRemoval: null,
            recentClearedStones: [],
            importReplaySnaps: [],
            liveFullSnaps: [],
            tryPlayBlackScore: 0,
            tryPlayWhiteScore: 0,
            tryPlayPendingRemoval: null,
            matchStarted: false,
            matchTime: null,
            _syncMovesLen: -1
        };
        (function initMatchGeometry() {
            const g = QiSquareWeiqiCanvas.computePaddingAndCell(ps.BOARD_SIZE);
            ps.PADDING = g.padding;
            ps.CELL_SIZE = g.cellSize;
            ps.board = Array(ps.BOARD_SIZE).fill().map(() => Array(ps.BOARD_SIZE).fill(0));
        })();

        const BOARD_MARK_CHAR_LIST = (() => {
            const a = [];
            a.push('?', '!');
            for (let i = 0; i < 26; i++) a.push(String.fromCharCode(65 + i));
            a.push('△', '▽', '♡', '○', '◇', '□', '☆', '×', '🚩');
            return a;
        })();

        const canvas = document.getElementById('goBoard');
        const ctx = canvas.getContext('2d');
        const turnDisplay = document.getElementById('turnDisplay');
        const colorStatus = document.getElementById('colorStatus');
const scoreTitle = document.getElementById('scoreTitle');
        const scoreBoard = document.getElementById('scoreBoard');
        const leadInfo = document.getElementById('leadInfo');
        const komiInfo = document.getElementById('komiInfo');
        const boardMarkSelect = document.getElementById('boardMarkSelect');

        QiSquareWeiqiCanvas.initBoardMarkSelectDom(boardMarkSelect, BOARD_MARK_CHAR_LIST);
        QiSquareWeiqiCanvas.initBoardMarkFoldDom(
            document.getElementById('boardMarkPanel'),
            document.getElementById('boardMarkFoldBtn'),
            document.getElementById('boardMarkExpandBtn')
        );

        const isMouseDevice = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

        function initBoardArray(size) {
            return QiSquareWeiqiCanvas.initBoardArray(size);
        }

        function deepCopyBoard(src) {
            return QiSquareWeiqiCanvas.deepCopyBoard(src);
        }

        function collectLineCoordsStatic(brd, bs, row, col, dx, dy, colorVal) {
            const seq = [{ row, col }];
            for (let step = 1; step < bs; step++) {
                const nr = row + dx * step, nc = col + dy * step;
                if (nr < 0 || nr >= bs || nc < 0 || nc >= bs || brd[nr][nc] !== colorVal) break;
                seq.push({ row: nr, col: nc });
            }
            for (let step = 1; step < bs; step++) {
                const nr = row - dx * step, nc = col - dy * step;
                if (nr < 0 || nr >= bs || nc < 0 || nc >= bs || brd[nr][nc] !== colorVal) break;
                seq.unshift({ row: nr, col: nc });
            }
            return seq;
        }

        function resolveScoringStatic(brd, bs, row, col, colorVal) {
            const dirs = [[1, 0], [0, 1], [1, 1], [1, -1]];
            let gain = 0;
            const toRemove = new Set();
            for (const [dx, dy] of dirs) {
                const seq = collectLineCoordsStatic(brd, bs, row, col, dx, dy, colorVal);
                if (seq.length >= 5) {
                    gain += (seq.length - 4);
                    for (const p of seq) toRemove.add(`${p.row},${p.col}`);
                }
            }
            if (gain > 0) {
                for (const key of toRemove) {
                    const [r, c] = key.split(',').map(Number);
                    brd[r][c] = 0;
                }
            }
            const removed = [];
            for (const key of toRemove) {
                const [r, c] = key.split(',').map(Number);
                removed.push({ row: r, col: c, color: colorVal });
            }
            return { gain, removed };
        }

        function countStonesStatic(brd, bs, stoneVal) {
            let n = 0;
            for (let r = 0; r < bs; r++)
                for (let c = 0; c < bs; c++)
                    if (brd[r][c] === stoneVal) n++;
            return n;
        }

        /**
         * 棋谱 moves 为字符串数组："B5,5" 仅落子；"B5,5,7,8" 落子后移除对手 (7,8)。
         * 展开为内部 place/remove 步骤供局面推演。
         */
        function expandMatchRecordMoves(moveStrings) {
            const out = [];
            for (const s of moveStrings || []) {
                if (typeof s !== 'string' || s.length < 3) return null;
                const ch = s[0];
                if (ch !== 'B' && ch !== 'W') return null;
                const player = ch === 'B' ? 'black' : 'white';
                const parts = s.substring(1).split(',').map(Number);
                if (parts.length !== 2 && parts.length !== 4) return null;
                if (!parts.every(Number.isFinite)) return null;
                out.push({ type: 'place', player, row: parts[0], col: parts[1] });
                if (parts.length === 4)
                    out.push({ type: 'remove', player, row: parts[2], col: parts[3] });
            }
            return out;
        }

        function buildReplaySnapshotsFromRecordMoves(moveStrings, boardSize) {
            const parsed = expandMatchRecordMoves(moveStrings);
            if (!parsed) return null;
            return buildLiveSnapshotsFromMoveHistory(parsed, boardSize);
        }

        function buildLiveSnapshotsFromMoveHistory(actions, boardSize) {
            const snaps = [];
            let b = initBoardArray(boardSize);
            let cur = 1;
            let bScore = 0;
            let wScore = 0;
            let pr = null;
            let recentCleared = [];
            let recentOwner = null;
            let lastMarkers = [];
            snaps.push({
                board: deepCopyBoard(b),
                lastMoveMarkers: [],
                currentPlayer: 1,
                gameOver: false,
                winner: null,
                blackScore: 0,
                whiteScore: 0,
                pendingRemoval: null,
                recentClearedStones: []
            });
            for (const m of actions || []) {
                const pv = m.player === 'black' ? 1 : 2;
                const opp = pv === 1 ? 2 : 1;
                let go = false;
                let win = null;
                let nextCur = cur;
                let markers = lastMarkers.map(x => ({ ...x }));
                if (m.type === 'remove') {
                    if (!pr || pr.player !== m.player) return null;
                    if (b[m.row][m.col] !== opp) return null;
                    b[m.row][m.col] = 0;
                    pr.remaining -= 1;
                    pr.removed += 1;
                    if (pr.remaining <= 0) {
                        pr = null;
                        nextCur = cur;
                    }
                } else {
                    if (m.player !== (cur === 1 ? 'black' : 'white')) return null;
                    if (pr) return null;
                    if (b[m.row][m.col] !== 0) return null;
                    if (recentCleared.length > 0 && recentOwner && recentOwner !== m.player) {
                        recentCleared = [];
                        recentOwner = null;
                    }
                    b[m.row][m.col] = pv;
                    markers = [{ row: m.row, col: m.col, color: pv }];
                    const scoreResult = resolveScoringStatic(b, boardSize, m.row, m.col, pv);
                    const gain = scoreResult.gain;
                    if (gain > 0) {
                        recentCleared = scoreResult.removed;
                        recentOwner = m.player;
                    } else {
                        recentCleared = [];
                        recentOwner = null;
                    }
                    if (pv === 1) bScore += gain;
                    else wScore += gain;
                    let switched = false;
                    if (gain > 0) {
                        const canRemove = Math.min(1, countStonesStatic(b, boardSize, opp));
                        if (canRemove > 0) {
                            pr = { player: m.player, total: canRemove, remaining: canRemove, removed: 0, hand: m.hand || 0 };
                            nextCur = cur;
                        } else {
                            nextCur = cur === 1 ? 2 : 1;
                            switched = true;
                        }
                    } else {
                        nextCur = cur === 1 ? 2 : 1;
                        switched = true;
                    }
                    if (switched) {
                        if (bScore >= MATCH_SCORE_BLACK_WIN) {
                            go = true;
                            win = 'black';
                        } else if (wScore >= MATCH_SCORE_WHITE_WIN) {
                            go = true;
                            win = 'white';
                        }
                    }
                    if (!go && !pr && R().isWuziqiBoardFull(b, boardSize)) {
                        go = true;
                        win = 'draw';
                    }
                }
                snaps.push({
                    board: deepCopyBoard(b),
                    lastMoveMarkers: markers,
                    currentPlayer: nextCur,
                    gameOver: go,
                    winner: go ? win : null,
                    blackScore: bScore,
                    whiteScore: wScore,
                    pendingRemoval: pr ? { ...pr } : null,
                    recentClearedStones: recentCleared.map(x => ({ ...x }))
                });
                lastMarkers = markers.map(x => ({ ...x }));
                cur = nextCur;
                if (go) break;
            }
            return snaps;
        }


        function updateScoreBoardDom() {
            if (scoreBoard) scoreBoard.innerText = `黑: ${ps.blackScore}/${MATCH_SCORE_BLACK_WIN}　白: ${ps.whiteScore}/${MATCH_SCORE_WHITE_WIN}`;
            if (leadInfo) leadInfo.innerText = '　';
        }

        function isRemovalPhase() {
            return !!ps.pendingRemoval;
        }
        function myStoneVal() {
            return ps.mySlot === 'black' ? 1 : 2;
        }
        function canRemoveAt(row, col) {
            if (!isRemovalPhase()) return false;
            if (!ps.isMyTurn || !ps.mySlot) return false;
            const opp = myStoneVal() === 1 ? 2 : 1;
            const bs = ps.BOARD_SIZE;
            return row >= 0 && col >= 0 && row < bs && col < bs && ps.board[row][col] === opp;
        }

        function applyLiveFullSnap(step) {
            if (!ps.liveFullSnaps.length) {
                ps.board = initBoardArray(ps.BOARD_SIZE);
                ps.lastMoveMarkers = [];
                ps.recentClearedStones = [];
                return;
            }
            const snap = ps.liveFullSnaps[step];
            ps.board = deepCopyBoard(snap.board);
            ps.lastMoveMarkers = (snap.lastMoveMarkers || []).map(m => ({ ...m }));
            ps.currentPlayer = snap.currentPlayer;
            ps.gameOver = !!snap.gameOver;
            ps.winner = snap.winner != null ? snap.winner : null;
            ps.blackScore = snap.blackScore || 0;
            ps.whiteScore = snap.whiteScore || 0;
            ps.pendingRemoval = snap.pendingRemoval ? { ...snap.pendingRemoval } : null;
            ps.recentClearedStones = (snap.recentClearedStones || []).map(s => ({ ...s }));
        }

        const domPage = {
            turnDisplay,
            scoreTitle,
            scoreBoard,
            leadInfo,
            scoreConfirmPanel: null,
            scoreConfirmText: null,
            komiInfo,
            canvas,
            ctx,
            boardMarkSelect,
            colorStatus
        };

        let page = QiWeiqiSquarePageRuntime.create(ps, domPage, {
            enableEditBoard: true,
            recordDownloadPrefix,
            komiInfoText: '无禁手',
            gameType,
            roomId,
            roomPassword,
            isMouseDevice,
            replayGameButtonIds: ['undoBtn', 'resignBtn', 'drawBtn'],
            drawBoard() {
                const d = QiSquareWeiqiCanvas.draw;
                const cs = QiSquareWeiqiCanvas.DEFAULT_CANVAS_SIZE;
                const cellSize = ps.CELL_SIZE;
                d.clear(ctx, cs);
                d.grid(ctx, ps.BOARD_SIZE, ps.PADDING, cellSize, cs);
                d.starPoints(ctx, ps.BOARD_SIZE, ps.PADDING, cellSize);
                d.coordLabels(ctx, ps.BOARD_SIZE, ps.PADDING, cellSize);
                const stoneRadius = cellSize * 0.44;
                const markLenDefault = cellSize * 0.352;
                const lowerLastMoveMarker = ps.showMoveNumbers || ps.showEstimateActive;
                if (lowerLastMoveMarker) {
                    d.lastMoveMarkersLower(ctx, ps.lastMoveMarkers, ps.PADDING, cellSize, stoneRadius);
                }
                d.stonesBlackWhite(ctx, ps.board, ps.BOARD_SIZE, ps.PADDING, cellSize, stoneRadius, ps.showMoveNumbers);
                if (!lowerLastMoveMarker) {
                    d.lastMoveMarkersUpper(ctx, ps.lastMoveMarkers, ps.PADDING, cellSize, markLenDefault);
                }
                function isUserBoardMarkVisibleAt(r, c) {
                    if (ps.showEstimateActive) return false;
                    if (r < 0 || r >= ps.BOARD_SIZE || c < 0 || c >= ps.BOARD_SIZE) return false;
                    if (ps.board[r][c] !== 0) return false;
                    return true;
                }
                d.userBoardMarks(ctx, ps.userBoardMarks, ps.BOARD_SIZE, ps.PADDING, cellSize, isUserBoardMarkVisibleAt);
                if (ps.showMoveNumbers) {
                    const nums = page.computeStoneNumbers();
                    d.moveNumbersOnStones(ctx, nums, ps.board, ps.BOARD_SIZE, ps.PADDING, cellSize);
                }
                d.hoverPreviewStone(ctx, ps.hoverRow, ps.hoverCol, ps.board, ps.PADDING, cellSize, {
                    tryPlayMode: ps.tryPlayMode,
                    tryPlayCurrentPlayer: ps.tryPlayCurrentPlayer,
                    gameOver: ps.gameOver,
                    isMyTurn: ps.isMyTurn,
                    mySlot: ps.mySlot,
                    isHoverValid: ps.isHoverValid,
                    hoverCapture: !!ps.hoverCapture,
                pageState: ps,
                editModeEnabled: !!ps.editModeEnabled,
                editTool: ps.editTool
                });
                if (ps.hoverCapture) {
                    d.hoverCaptureRing(ctx, ps.hoverRow, ps.hoverCol, ps.PADDING, cellSize, stoneRadius, {
                        tryPlayMode: ps.tryPlayMode,
                        gameOver: ps.gameOver,
                        isMyTurn: ps.isMyTurn,
                        isHoverValid: ps.isHoverValid,
                        hoverCapture: !!ps.hoverCapture
                    });
                }
                if (ps.showEstimateActive && ps.cachedLiveBoard && ps.cachedTerritory) {
                    d.estimateOverlay(ctx, ps.board, ps.BOARD_SIZE, ps.PADDING, cellSize, ps.cachedLiveBoard, ps.cachedTerritory);
                }
            },
            syncState(state) {
                page.clearMobileMovePreview();
                const incomingSize = state.boardSize != null ? Number(state.boardSize) : NaN;
                const sizeNum = Number(ps.BOARD_SIZE);
                const rowLen = state.board ? state.board.length : 0;
                const colLen = state.board && state.board[0] ? state.board[0].length : 0;
                const needGeometry =
                    Number.isFinite(incomingSize) &&
                    (incomingSize !== sizeNum || rowLen !== incomingSize || colLen !== incomingSize);
                if (needGeometry) {
                    ps.BOARD_SIZE = incomingSize;
                    ps.board = initBoardArray(ps.BOARD_SIZE);
                    page.updateBoardGeometry();
                    const bsEl = document.getElementById('boardSizeSelect');
                    if (bsEl) bsEl.value = String(ps.BOARD_SIZE);
                }
                ps.moveHistory = state.moveHistory || [];
                ps.moveLog = ps.moveHistory.map(m => ({ row: m.row, col: m.col }));
                const expandedMoves = expandMatchRecordMoves(state.moves || []);
                const stateActions = expandedMoves || [];
                const incomingMLen = Array.isArray(state.moves) ? state.moves.length : 0;
                const prevMLen = ps._syncMovesLen;
                if (incomingMLen !== (prevMLen !== undefined ? prevMLen : -1)
                    || needGeometry
                    || (state.numberOfHands || 1) !== ps.numberOfHands
                    || !!state.gameOver !== !!ps.gameOver
                    || state.currentPlayer !== ps.currentPlayer) {
                    page.clearMobileMovePreview();
                }
                ps.numberOfHands = state.numberOfHands != null ? state.numberOfHands : 1;
                ps.blackScore = state.blackScore || 0;
                ps.whiteScore = state.whiteScore || 0;
                ps.pendingRemoval = state.pendingRemoval || null;
                ps.recentClearedStones = (state.recentClearedStones || []).map(s => ({ ...s }));
                if (state.matchTime !== undefined) ps.matchTime = state.matchTime;
                if (state.matchStarted !== undefined) ps.matchStarted = !!state.matchStarted;
                if (state.slots) ps.slots = state.slots;

                if (!ps.replayMode) {
                    const prevTotal = Math.max(0, ps.liveFullSnaps.length - 1);
                    const wasAtEnd = ps.liveFollowLatest || ps.liveViewStep >= prevTotal;
                    const rebuiltLive = buildLiveSnapshotsFromMoveHistory(stateActions, ps.BOARD_SIZE);
                    ps.liveFullSnaps = Array.isArray(rebuiltLive) ? rebuiltLive : [];
                    ps.liveReplayBoards = ps.liveFullSnaps.map(s => s.board);
                    ps.liveReplayMarkers = ps.liveFullSnaps.map(s => (s.lastMoveMarkers || []).map(m => ({ ...m })));
                    ps.liveReplayStepPlayers = ps.liveFullSnaps.map((_, i) => (i === 0 ? 0 : 1));
                    const newTotal = Math.max(0, ps.liveFullSnaps.length - 1);
                    if (newTotal === 0) {
                        ps.liveViewStep = 0;
                        ps.liveFollowLatest = true;
                    } else if (wasAtEnd) {
                        ps.liveViewStep = newTotal;
                        ps.liveFollowLatest = true;
                    } else {
                        ps.liveViewStep = Math.min(ps.liveViewStep, newTotal);
                        if (ps.liveViewStep === newTotal) ps.liveFollowLatest = true;
                    }
                    if (!ps.tryPlayMode) {
                        applyLiveFullSnap(ps.liveViewStep);
                        if (ps.liveViewStep === newTotal) {
                            ps.board = state.board;
                            ps.lastMoveMarkers = state.lastMoveMarkers || [];
                            ps.currentPlayer = state.currentPlayer;
                            ps.gameOver = state.gameOver || false;
                            ps.winner = state.winner || null;
                            ps.blackScore = state.blackScore || 0;
                            ps.whiteScore = state.whiteScore || 0;
                            ps.pendingRemoval = state.pendingRemoval || null;
                            ps.recentClearedStones = (state.recentClearedStones || []).map(s => ({ ...s }));
                        }
                        page.updateLiveReplayPanelUI();
                    }
                } else if (!ps.tryPlayMode) {
                    ps.board = state.board;
                    ps.currentPlayer = state.currentPlayer;
                    ps.gameOver = state.gameOver || false;
                    ps.winner = state.winner || null;
                    ps.lastMoveMarkers = state.lastMoveMarkers || [];
                    ps.blackScore = state.blackScore || 0;
                    ps.whiteScore = state.whiteScore || 0;
                    ps.pendingRemoval = state.pendingRemoval || null;
                    ps.recentClearedStones = (state.recentClearedStones || []).map(s => ({ ...s }));
                }

                const hasAnyStone = ps.board.some(row => row.some(v => v !== 0));
                const hasPlayer = ps.slots.black || ps.slots.white;
                const sizeSelect = document.getElementById('boardSizeSelect');
                if (sizeSelect && !hasAnyStone && !hasPlayer && !ps.gameOver && ps.mySlot === null && !ps.replayMode)
                    sizeSelect.style.display = 'inline-block';
                else if (sizeSelect) sizeSelect.style.display = 'none';

                ps._syncMovesLen = incomingMLen;
                page.updateTurn();
                page.updateReplayUI();
            },
            enterReplayMode(data) {
                const bs = data.boardSize != null ? Number(data.boardSize) : ps.BOARD_SIZE;
                if (!Number.isFinite(bs) || bs < 7 || bs > 15) return;
                if (!Array.isArray(data.moves)) return;
                const snapshots = buildReplaySnapshotsFromRecordMoves(data.moves, bs);
                if (!snapshots || snapshots.length === 0) return;
                if (bs !== ps.BOARD_SIZE) {
                    ps.BOARD_SIZE = bs;
                    ps.board = initBoardArray(ps.BOARD_SIZE);
                    page.updateBoardGeometry();
                    const bsEl = document.getElementById('boardSizeSelect');
                    if (bsEl) bsEl.value = String(ps.BOARD_SIZE);
                }
                ps.importReplaySnaps = snapshots;
                ps.replayBoards = snapshots.map(s => s.board);
                ps.replayMarkers = snapshots.map(s => (s.lastMoveMarkers || []).map(m => ({ ...m })));
                ps.replayStepPlayers = snapshots.map((_, i) => (i === 0 ? 0 : (i % 2 === 1 ? 1 : 2)));
                ps.replayTotalSteps = ps.replayBoards.length - 1;
                ps.replayMode = true;
                const slider = document.getElementById('replaySlider');
                slider.max = ps.replayTotalSteps;
                page.setReplayStep(ps.replayTotalSteps);
                page.updateReplayUI();
            },
            exitReplayMode() {
                page.clearMobileMovePreview();
                ps.tryPlayMode = false;
                ps.tryPlayBoards = [];
                ps.tryPlayMarkers = [];
                ps.tryPlayStep = 0;
                ps.tryPlayTotalSteps = 0;
                ps.tryPlayScoreStack = [];
                ps.replayMode = false;
                ps.replayBoards = [];
                ps.replayMarkers = [];
                ps.replayStepPlayers = [];
                ps.replayStep = 0;
                ps.replayTotalSteps = 0;
                ps.importReplaySnaps = [];
                page.updateReplayUI();
            },
            setReplayStep(step) {
                page.clearMobileMovePreview();
                if (step < 0) step = 0;
                if (step > ps.replayTotalSteps) step = ps.replayTotalSteps;
                ps.replayStep = step;
                const snap = ps.importReplaySnaps[step];
                ps.board = deepCopyBoard(snap.board);
                ps.lastMoveMarkers = (snap.lastMoveMarkers || []).map(m => ({ ...m }));
                ps.gameOver = !!snap.gameOver;
                ps.winner = snap.winner != null ? snap.winner : null;
                ps.blackScore = snap.blackScore || 0;
                ps.whiteScore = snap.whiteScore || 0;
                ps.pendingRemoval = snap.pendingRemoval ? { ...snap.pendingRemoval } : null;
                ps.recentClearedStones = (snap.recentClearedStones || []).map(s => ({ ...s }));
                document.getElementById('replaySlider').value = step;
                document.getElementById('replayStepDisplay').innerText = `${step} / ${ps.replayTotalSteps}`;
                if (step === 0) turnDisplay.innerText = '初始局面';
                else turnDisplay.innerText = `打谱 ${step} / ${ps.replayTotalSteps}`;
                ps.isMyTurn = false;
                page.updateTurn();
            },
            updateReplayUI() {
                const hideIds = ['undoBtn', 'resignBtn', 'drawBtn'];
                const replayPanel = document.getElementById('replayPanel');
                const tryPlayBtn = document.getElementById('tryPlayBtn');
                const isPlayer = !!ps.mySlot;
                const started = !!(ps.matchStarted || ps.matchStartedOnce || (ps.matchTime && ps.matchTime.settings));
                const showMatchButtons = isPlayer && started && !ps.replayMode;
                hideIds.forEach(id => { const el = document.getElementById(id); if (el) el.style.display = showMatchButtons ? '' : 'none'; });
                replayPanel.style.display = '';
                tryPlayBtn.style.display = showMatchButtons ? 'none' : '';
                tryPlayBtn.innerText = ps.tryPlayMode ? '试下结束' : '试下';
            },
            enterTryPlay() {
                page.clearMobileMovePreview();
                ps.tryPlayMode = true;
                ps.tryPlayBaseStep = ps.replayStep;
                ps.tryPlayBoards = [deepCopyBoard(ps.board)];
                ps.tryPlayMarkers = [ps.lastMoveMarkers.map(m => ({ ...m }))];
                const snap = ps.importReplaySnaps[ps.replayStep];
                ps.tryPlayCurrentPlayer = snap.currentPlayer != null ? snap.currentPlayer : 1;
                ps.tryPlayBlackScore = snap.blackScore || 0;
                ps.tryPlayWhiteScore = snap.whiteScore || 0;
                ps.tryPlayPendingRemoval = snap.pendingRemoval ? { ...snap.pendingRemoval } : null;
                ps.tryPlayScoreStack = [{
                    b: ps.tryPlayBlackScore,
                    w: ps.tryPlayWhiteScore,
                    pr: ps.tryPlayPendingRemoval ? { ...ps.tryPlayPendingRemoval } : null,
                    go: !!snap.gameOver,
                    win: snap.winner != null ? snap.winner : null
                }];
                ps.gameOver = !!snap.gameOver;
                ps.winner = snap.winner != null ? snap.winner : null;
                ps.tryPlayStep = 0;
                ps.tryPlayTotalSteps = 0;
                const slider = document.getElementById('replaySlider');
                slider.min = 0;
                slider.max = 0;
                slider.value = 0;
                page.updateReplayUI();
                page.updateTurn();
            },
            exitTryPlay() {
                page.clearMobileMovePreview();
                ps.tryPlayMode = false;
                ps.tryPlayBoards = [];
                ps.tryPlayMarkers = [];
                ps.tryPlayStep = 0;
                ps.tryPlayTotalSteps = 0;
                ps.tryPlayScoreStack = [];
                const slider = document.getElementById('replaySlider');
                slider.min = 0;
                slider.max = ps.replayTotalSteps;
                page.setReplayStep(ps.tryPlayBaseStep);
                page.updateReplayUI();
            },
            tryPlayMove(row, col) {
                if (ps.board[row][col] !== 0) return false;
                const playerVal = ps.tryPlayCurrentPlayer;
                const b = deepCopyBoard(ps.board);
                b[row][col] = playerVal;
                const res = resolveScoringStatic(b, ps.BOARD_SIZE, row, col, playerVal);
                if (playerVal === 1) ps.tryPlayBlackScore += res.gain;
                else ps.tryPlayWhiteScore += res.gain;
                if (ps.tryPlayStep < ps.tryPlayTotalSteps) {
                    ps.tryPlayBoards.length = ps.tryPlayStep + 1;
                    ps.tryPlayMarkers.length = ps.tryPlayStep + 1;
                    ps.tryPlayScoreStack.length = ps.tryPlayStep + 1;
                }
                ps.board = b;
                ps.lastMoveMarkers = [{ row, col, color: playerVal }];
                ps.tryPlayCurrentPlayer = 3 - playerVal;
                ps.gameOver = false;
                ps.winner = null;
                if (ps.tryPlayBlackScore >= MATCH_SCORE_BLACK_WIN) {
                    ps.gameOver = true;
                    ps.winner = 'black';
                } else if (ps.tryPlayWhiteScore >= MATCH_SCORE_WHITE_WIN) {
                    ps.gameOver = true;
                    ps.winner = 'white';
                }
                ps.tryPlayBoards.push(deepCopyBoard(ps.board));
                ps.tryPlayMarkers.push(ps.lastMoveMarkers.map(m => ({ ...m })));
                ps.tryPlayScoreStack.push({
                    b: ps.tryPlayBlackScore,
                    w: ps.tryPlayWhiteScore,
                    pr: ps.tryPlayPendingRemoval ? { ...ps.tryPlayPendingRemoval } : null,
                    go: ps.gameOver,
                    win: ps.winner
                });
                ps.tryPlayTotalSteps = ps.tryPlayBoards.length - 1;
                ps.tryPlayStep = ps.tryPlayTotalSteps;
                const slider = document.getElementById('replaySlider');
                slider.max = ps.tryPlayTotalSteps;
                slider.value = ps.tryPlayStep;
                page.updateTurn();
                return true;
            },
            setTryPlayStep(step) {
                page.clearMobileMovePreview();
                if (step < 0) step = 0;
                if (step > ps.tryPlayTotalSteps) step = ps.tryPlayTotalSteps;
                ps.tryPlayStep = step;
                ps.board = deepCopyBoard(ps.tryPlayBoards[step]);
                ps.lastMoveMarkers = ps.tryPlayMarkers[step].map(m => ({ ...m }));
                const meta = ps.tryPlayScoreStack[step];
                ps.tryPlayBlackScore = meta.b;
                ps.tryPlayWhiteScore = meta.w;
                ps.tryPlayPendingRemoval = meta.pr ? { ...meta.pr } : null;
                ps.gameOver = !!meta.go;
                ps.winner = meta.win != null ? meta.win : null;
                const basePlayer = ps.tryPlayBaseStep === 0 ? 1 : (ps.importReplaySnaps[ps.tryPlayBaseStep].currentPlayer === 1 ? 2 : 1);
                ps.tryPlayCurrentPlayer = step % 2 === 0 ? basePlayer : (3 - basePlayer);
                document.getElementById('replaySlider').value = step;
                page.updateTurn();
            },
            updateTryPlayDisplay() {
                if (ps.tryPlayMode) {
                    document.getElementById('replayStepDisplay').innerText = `试下 ${ps.tryPlayStep} / ${ps.tryPlayTotalSteps}`;
                    const emoji = ps.tryPlayCurrentPlayer === 1 ? '⚫' : '⚪';
                    turnDisplay.innerText = `${emoji} 试下 (${ps.tryPlayBlackScore}/${MATCH_SCORE_BLACK_WIN} · ${ps.tryPlayWhiteScore}/${MATCH_SCORE_WHITE_WIN})`;
                }
            }
        });

        ps.tryPlayScoreStack = [];

        const _matchUpdateTurn = function () {
            updateScoreBoardDom();
            if (ps.replayMode && ps.tryPlayMode) {
                page.updateTryPlayDisplay();
                ps.isMyTurn = !ps.gameOver;
                page.drawBoard();
                return;
            }
            if (ps.replayMode) {
                page.drawBoard();
                return;
            }
            if (ps.matchStartedOnce === undefined) ps.matchStartedOnce = false;
            if (ps.matchStarted) ps.matchStartedOnce = true;
            const bothSelected = !!(ps.slots && ps.slots.black && ps.slots.white);
            const matchReady = !!(ps.matchTime && ps.matchTime.settings);
            if (bothSelected && matchReady) ps.matchStartedOnce = true;
            const hasStoneOnBoard = ps.board && ps.board.some(row => row.some(v => v === 1 || v === 2));
            if ((ps.numberOfHands || 1) > 1 || hasStoneOnBoard) ps.matchStartedOnce = true;
            const liveTotal = ps.liveFullSnaps.length > 0 ? ps.liveFullSnaps.length - 1 : 0;
            const browsingLive = ps.liveFullSnaps.length > 0 && ps.liveViewStep < liveTotal;
            if (browsingLive) {
                const snap = ps.liveFullSnaps[ps.liveViewStep];
                let n = 0;
                const sz = snap.board.length;
                for (let r = 0; r < sz; r++)
                    for (let c = 0; c < sz; c++)
                        if (snap.board[r][c] !== 0) n++;
                if (n === 0) {
                    turnDisplay.innerText = '初始局面';
                } else {
                    const emoji = (n % 2 === 1) ? '⚫' : '⚪';
                    turnDisplay.innerText = `${emoji} 第${n}手`;
                }
                ps.isMyTurn = false;
                page.drawBoard();
                return;
            }
            if (ps.gameOver) {
                turnDisplay.innerText = '对局结束';
                if (ps.winner === 'black') scoreTitle.innerText = '黑胜';
                else if (ps.winner === 'white') scoreTitle.innerText = '白胜';
                else if (ps.winner === 'draw') scoreTitle.innerText = '和棋';
                else scoreTitle.innerText = '　';
                ps.isMyTurn = false;
                page.drawBoard();
                return;
            }
            if (!ps.matchStarted) {
                turnDisplay.innerText = QiWeiqiSquarePageRuntime.waitingSeatTurnText(slots, mySlot);
                ps.isMyTurn = false;
                page.drawBoard();
                return;
            }
            if (isRemovalPhase()) {
                const colorEmoji = ps.pendingRemoval.player === 'black' ? '⚫' : '⚪';
                turnDisplay.innerText = `${colorEmoji} 移除中`;
            } else if (ps.moveHistory.length === 0) {
                turnDisplay.innerText = '初始局面';
            } else {
                const last = ps.moveHistory[ps.moveHistory.length - 1];
                const emoji = last.player === 'black' ? '⚫' : '⚪';
                turnDisplay.innerText = `${emoji} 第${ps.moveHistory.length}手`;
            }
            const atLiveEdge = ps.liveFullSnaps.length === 0 || ps.liveViewStep >= ps.liveFullSnaps.length - 1;
            ps.isMyTurn = atLiveEdge && (ps.mySlot !== null)
                && ((ps.mySlot === 'black' && ps.currentPlayer === 1) || (ps.mySlot === 'white' && ps.currentPlayer === 2));
            updateScoreBoardDom();
            page.drawBoard();
        };
        page.updateTurn = _matchUpdateTurn;

        page.setLiveViewStep = function (step) {
            page.clearMobileMovePreview();
            if (ps.replayMode) return;
            const total = Math.max(0, ps.liveFullSnaps.length - 1);
            if (step < 0) step = 0;
            if (step > total) step = total;
            ps.liveViewStep = step;
            ps.liveFollowLatest = step >= total;
            applyLiveFullSnap(ps.liveViewStep);
            page.updateLiveReplayPanelUI();
            page.updateTurn();
        };

        function commitMove(row, col) {
            if (ps.gameOver) return false;
            if (!ps.isMyTurn) return false;
            if (isRemovalPhase()) return false;
            if (ps.board[row][col] !== 0) return false;
            ps.ws.send(JSON.stringify({ type: 'move', row, col }));
            return true;
        }
        function commitRemove(row, col) {
            if (ps.gameOver) return false;
            if (!ps.isMyTurn) return false;
            if (!canRemoveAt(row, col)) return false;
            ps.ws.send(JSON.stringify({ type: 'removeOpponent', row, col }));
            return true;
        }

        const {
            mobileTwoStepPlacing,
            clearMobileMovePreview,
            drawBoard,
            updateTurn,
            downloadRecord,
            enterReplayMode,
            exitReplayMode,
            setReplayStep,
            updateReplayUI,
            enterTryPlay,
            exitTryPlay,
            tryPlayMove,
            setTryPlayStep,
            updateTryPlayDisplay,
            setLiveViewStep,
            connectWebSocket,
            initBoardArray: pageInitBoard,
            updateBoardGeometry,
            syncState,
            getClosestIntersection,
            canvasCoordsFromClient,
            applyUserBoardMark
        } = page;

        const _weiqiBindings = QiBoardRoomClient.createWeiqiMessageBindings({
            onNewGameStarted() {
                if (page && page.clearEditModeUi) page.clearEditModeUi();
            },
            roomId,
            gameType,
            standardWeiqiMatchTime,
            boardSeatOverlay: true,
            pageState: ps,
            drawBoard,
            exitTryPlay,
            enterTryPlay,
            setTryPlayStep,
            setReplayStep,
            setLiveViewStep,
            getWs: () => ps.ws,
            getBoardSize: () => ps.BOARD_SIZE,
            setBoardSize: (n) => { ps.BOARD_SIZE = n; },
            getKomi: () => ps.KOMI,
            setKomi: (n) => { ps.KOMI = n; },
            getBoard: () => ps.board,
            setBoard: (b) => { ps.board = b; },
            getSlots: () => ps.slots,
            setSlots: (s) => { ps.slots = s; },
            getMySlot: () => ps.mySlot,
            setMySlot: (s) => { ps.mySlot = s; },
            getGameOver: () => ps.gameOver,
            setGameOver: (v) => { ps.gameOver = v; },
            getWinner: () => ps.winner,
            setWinner: (w) => { ps.winner = w; },
            getReplayMode: () => ps.replayMode,
            getShowEstimateActive: () => ps.showEstimateActive,
            setShowEstimateActive: (v) => { ps.showEstimateActive = v; },
            getWaitingScoreConfirm: () => ps.waitingScoreConfirm,
            setWaitingScoreConfirm: (v) => { ps.waitingScoreConfirm = v; },
            getIRejected: () => ps.iRejected,
            setIRejected: (v) => { ps.iRejected = v; },
            colorStatus,
            scoreTitle,
            turnDisplay,
syncState: page.syncState,
            updateBoardGeometry,
            initBoardArray: pageInitBoard,
            exitReplayMode,
            clearEstimate: () => {},
            hideScoreConfirm: () => {},
            showEstimate: () => {},
            clearMobileMovePreview,
            downloadRecord,
            enterReplayMode,
            updateTurn,
            showScoreConfirm: () => {},
            isMouseDevice,
            onBoardSizeChanged(msg) {
                if (msg.boardSize == null) return;
                const n = Number(msg.boardSize);
                if (Number.isFinite(n) && n !== Number(ps.BOARD_SIZE)) {
                    ps.BOARD_SIZE = n;
                    ps.board = pageInitBoard(n);
                    updateBoardGeometry();
                }
                const sel = document.getElementById('boardSizeSelect');
                if (sel) sel.value = String(msg.boardSize);
                drawBoard();
            }
        });
        const _weiqiHandleMessage = _weiqiBindings.handleMessage;
        function handleMessage(msg) {
            if (msg.type === 'broadcast' && msg.action === 'remove') {
                const wasOver = ps.gameOver;
                page.syncState(msg);
                if (msg.gameOver && !wasOver) {
                    if (msg.winner === 'black') qiAlert('黑胜。');
                    else if (msg.winner === 'white') qiAlert('白胜。');
                    else if (msg.winner === 'draw') qiAlert('和棋。');
                }
                _weiqiBindings.updateRadioStyles();
                return;
            }
            _weiqiHandleMessage(msg);
        }
        const updateRadioStyles = _weiqiBindings.updateRadioStyles;

        let suppressCanvasClickAfterLongMark = false;

        canvas.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            const { x, y } = canvasCoordsFromClient(e.clientX, e.clientY);
            const { row, col } = getClosestIntersection(x, y);
            if (isRemovalPhase()) return;
            applyUserBoardMark(row, col);
        });

        const LONG_MARK_MS = 500;
        const LONG_MARK_MOVE_CANCEL = 14;
        let longMarkTimer = null;
        let longMarkStart = null;

        canvas.addEventListener('touchstart', (e) => {
            if (e.touches.length !== 1) return;
            const t = e.touches[0];
            longMarkStart = { x: t.clientX, y: t.clientY };
            longMarkTimer = setTimeout(() => {
                longMarkTimer = null;
                if (!longMarkStart) return;
                const { x, y } = canvasCoordsFromClient(longMarkStart.x, longMarkStart.y);
                const { row, col } = getClosestIntersection(x, y);
                if (!isRemovalPhase()) applyUserBoardMark(row, col);
                suppressCanvasClickAfterLongMark = true;
                setTimeout(() => { suppressCanvasClickAfterLongMark = false; }, 450);
                longMarkStart = null;
            }, LONG_MARK_MS);
        }, { passive: true });

        canvas.addEventListener('touchmove', (e) => {
            if (!longMarkTimer || !longMarkStart || e.touches.length !== 1) return;
            const t = e.touches[0];
            const dx = t.clientX - longMarkStart.x;
            const dy = t.clientY - longMarkStart.y;
            if (dx * dx + dy * dy > LONG_MARK_MOVE_CANCEL * LONG_MARK_MOVE_CANCEL) {
                clearTimeout(longMarkTimer);
                longMarkTimer = null;
            }
        }, { passive: true });

        function clearLongMarkTouch() {
            if (longMarkTimer) {
                clearTimeout(longMarkTimer);
                longMarkTimer = null;
            }
            longMarkStart = null;
        }
        canvas.addEventListener('touchend', clearLongMarkTouch);
        canvas.addEventListener('touchcancel', clearLongMarkTouch);

        canvas.addEventListener('click', (e) => {
            if (suppressCanvasClickAfterLongMark) {
                e.preventDefault();
                return;
            }
            const rect = canvas.getBoundingClientRect();
            const scale = 600 / rect.width;
            const x = (e.clientX - rect.left) * scale;
            const y = (e.clientY - rect.top) * scale;
            const { row, col } = getClosestIntersection(x, y);
            const m2 = mobileTwoStepPlacing();
            if (ps.tryPlayMode && ps.replayMode) {
                if (row < 0 || col < 0) {
                    if (m2) { clearMobileMovePreview(); drawBoard(); }
                    return;
                }
                if (ps.board[row][col] !== 0) return;
                if (m2) {
                    if (ps.hoverRow === row && ps.hoverCol === col && ps.isHoverValid) {
                        clearMobileMovePreview();
                        tryPlayMove(row, col);
                    } else {
                        ps.hoverRow = row;
                        ps.hoverCol = col;
                        ps.isHoverValid = true;
                        drawBoard();
                    }
                    return;
                }
                tryPlayMove(row, col);
                return;
            }
            const ltLive = ps.liveFullSnaps.length > 0 ? ps.liveFullSnaps.length - 1 : 0;
            if (!ps.replayMode && ps.liveFullSnaps.length && ps.liveViewStep < ltLive) return;
            if (ps.gameOver) return;
            if (!ps.isMyTurn) return;
            if (row < 0 || col < 0) {
                if (m2) { clearMobileMovePreview(); drawBoard(); }
                return;
            }
            if (!isRemovalPhase() && ps.board[row][col] !== 0) return;
            if (m2) {
                const cap = isRemovalPhase() && canRemoveAt(row, col);
                if (ps.hoverRow === row && ps.hoverCol === col && ps.isHoverValid && !!ps.hoverCapture === cap) {
                    clearMobileMovePreview();
                    if (isRemovalPhase()) commitRemove(row, col);
                    else commitMove(row, col);
                    drawBoard();
                } else {
                    if (isRemovalPhase() && !canRemoveAt(row, col)) return;
                    if (!isRemovalPhase() && ps.board[row][col] !== 0) return;
                    ps.hoverRow = row;
                    ps.hoverCol = col;
                    ps.isHoverValid = true;
                    ps.hoverCapture = cap;
                    drawBoard();
                }
                return;
            }
            if (isRemovalPhase()) commitRemove(row, col);
            else commitMove(row, col);
        });

        if (isMouseDevice) {
            canvas.addEventListener('mousemove', (e) => {
                const rect = canvas.getBoundingClientRect();
                const scale = 600 / rect.width;
                const x = (e.clientX - rect.left) * scale;
                const y = (e.clientY - rect.top) * scale;
                const { row, col } = getClosestIntersection(x, y);
                ps.hoverRow = row;
                ps.hoverCol = col;
                ps.hoverCapture = false;
                if (row >= 0 && col >= 0) {
                    if (isRemovalPhase()) {
                        const ok = canRemoveAt(row, col);
                        ps.isHoverValid = ok;
                        ps.hoverCapture = ok;
                    } else {
                        ps.isHoverValid = ps.board[row][col] === 0;
                    }
                } else {
                    ps.isHoverValid = false;
                }
                drawBoard();
            });
            canvas.addEventListener('mouseleave', () => {
                ps.isHoverValid = false;
                ps.hoverCapture = false;
                ps.hoverRow = -1;
                ps.hoverCol = -1;
                drawBoard();
            });
        }
        connectWebSocket(handleMessage);
        })();
    }
};
