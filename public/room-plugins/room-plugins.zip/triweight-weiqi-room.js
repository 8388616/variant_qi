window.RoomPlugins = window.RoomPlugins || {};
window.RoomPlugins["triweight-weiqi"] = {
    shell: {
        "title": "三权重围棋",
        "rulesHtml": "基本规则同围棋。<br /><br />每个点随机赋予1~3的权重。<br /><br />请在格中落子。<br />",
        "defaultKomiText": "黑贴白6.25点",
        "boardSizeMin": 7,
        "boardSizeMax": 21,
        "defaultBoardSize": 19,
        "minLib": 1,
        "recordDownloadPrefix": "三权重围棋",
        "standardWeiqiMatchTime": true,
        "features": {
            "editBoard": true
        },
        "editTools": [
            { "value": "empty", "label": "空" },
            { "value": "black", "label": "黑子" },
            { "value": "white", "label": "白子" }
        ]
    },
    mount: function (ctx) {
        var gameType = ctx.gameType;
        var roomId = ctx.roomId;
        var roomPassword = ctx.roomPassword || null;
        var config = ctx.config || {};
        var recordDownloadPrefix = config.recordDownloadPrefix != null ? config.recordDownloadPrefix : "三权重围棋";
        var minLib = config.minLib != null ? config.minLib : 1;
        var standardWeiqiMatchTime = config.standardWeiqiMatchTime != null ? config.standardWeiqiMatchTime : true;


        (function () {
const C = QiSquareWeiqiCanvas;

        const ps = {
            BOARD_SIZE: 19,
            KOMI: 6.25,
            PADDING: 0,
            CELL_SIZE: 0,
            board: [],
            weights: [],
            numberOfHands: 1,
            currentPlayer: 1,
            mySlot: null,
            gameOver: false,
            winner: null,
            lastMoveMarkers: [],
            showEstimateActive: false,
            cachedLiveBoard: null,
            cachedTerritory: null,
            waitingScoreConfirm: false,
            iRejected: false,
            ws: null,
            isMyTurn: false,
            slots: { black: false, white: false },
            reconnectTimer: null,
            replayMode: false,
            replayBoards: [],
            replayMarkers: [],
            replayStepPlayers: [],
            replayStep: 0,
            replayTotalSteps: 0,
            showMoveNumbers: false,
            moveLog: [],
            tryPlayMode: false,
            tryPlayBaseStep: 0,
            tryPlayBoards: [],
            tryPlayMarkers: [],
            tryPlayCurrentPlayer: 1,
            tryPlayStep: 0,
            tryPlayTotalSteps: 0,
            liveReplayBoards: [],
            liveReplayMarkers: [],
            liveReplayStepPlayers: [],
            liveViewStep: 0,
            liveFollowLatest: true,
            userBoardMarks: Object.create(null),
            hoverRow: -1,
            hoverCol: -1,
            isHoverValid: false
        };
        (function initSquareGeometry() {
            const n = ps.BOARD_SIZE;
            const padding = 63 - 2 * n;
            const cellSize = (600 - 2 * padding) / n;
            ps.PADDING = padding;
            ps.CELL_SIZE = cellSize;
            ps.board = C.initBoardArray(n);
            ps.weights = C.initBoardArray(n);
        })();

const BOARD_MARK_CHAR_LIST = (() => {
            const a = [];
            a.push('?', '!');
            for (let i = 0; i < 26; i++) a.push(String.fromCharCode(65 + i));
            a.push('△', '▽', '♡', '○', '◇', '□', '☆', '×', '🚩');
            return a;
        })();

        const canvas = document.getElementById('goBoard');
        const ctx = canvas.getContext('2d');
        const turnDisplay = document.getElementById('turnDisplay');
        const colorStatus = document.getElementById('colorStatus');
const scoreTitle = document.getElementById('scoreTitle');
        const scoreBoard = document.getElementById('scoreBoard');
        const leadInfo = document.getElementById('leadInfo');
        const scoreConfirmPanel = document.getElementById('scoreConfirmPanel');
        const scoreConfirmText = document.getElementById('scoreConfirmText');
        const scoreConfirmYes = document.getElementById('scoreConfirmYes');
        const scoreConfirmNo = document.getElementById('scoreConfirmNo');
        const komiInfo = document.getElementById('komiInfo');
        const boardMarkSelect = document.getElementById('boardMarkSelect');

        C.initBoardMarkSelectDom(boardMarkSelect, BOARD_MARK_CHAR_LIST);
        C.initBoardMarkFoldDom(
            document.getElementById('boardMarkPanel'),
            document.getElementById('boardMarkFoldBtn'),
            document.getElementById('boardMarkExpandBtn')
        );

        const isMouseDevice = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

        function normalizeReplayInitialPayload(initialPosition) {
            if (!initialPosition) return [];
            if (Array.isArray(initialPosition)) return initialPosition;
            if (typeof initialPosition !== 'object') return [];
            const out = [];
            for (const pos of initialPosition.black || []) {
                if (Array.isArray(pos) && pos.length === 2) out.push(`B${pos[0]},${pos[1]}`);
            }
            for (const pos of initialPosition.white || []) {
                if (Array.isArray(pos) && pos.length === 2) out.push(`W${pos[0]},${pos[1]}`);
            }
            return out;
        }

        const weightColorMap = { 1: '#deb887', 2: '#ce7857', 3: '#ae3827' };

        function normalizeWeightMatrix(rawWeights, boardSize) {
            const normalized = C.initBoardArray(boardSize);
            if (!Array.isArray(rawWeights)) return normalized;
            for (let r = 0; r < boardSize; r++) {
                if (!Array.isArray(rawWeights[r])) continue;
                for (let c = 0; c < boardSize; c++) {
                    const value = rawWeights[r][c];
                    if (Number.isFinite(value)) normalized[r][c] = value;
                }
            }
            return normalized;
        }

        function safeWeightAt(weights, r, c) {
            const row = Array.isArray(weights) ? weights[r] : null;
            const value = Array.isArray(row) ? row[c] : 0;
            return Number.isFinite(value) ? value : 0;
        }

        function triWeightedComputeScore(liveBoard, territory) {
            const n = ps.BOARD_SIZE;
            let blackStones = 0, whiteStones = 0, blackTerritory = 0, whiteTerritory = 0, publicTerritory = 0;
            for (let r = 0; r < n; r++) {
                for (let c = 0; c < n; c++) {
                    const weight = safeWeightAt(ps.weights, r, c);
                    if (liveBoard[r][c] === 1) blackStones += weight;
                    else if (liveBoard[r][c] === 2) whiteStones += weight;
                    else if (liveBoard[r][c] === 0) {
                        if (territory[r][c] === 1) blackTerritory += weight;
                        else if (territory[r][c] === 2) whiteTerritory += weight;
                        else if (territory[r][c] === 3) publicTerritory += weight;
                    }
                }
            }
            const blackTotal = blackStones + blackTerritory + publicTerritory / 2;
            const whiteTotal = whiteStones + whiteTerritory + publicTerritory / 2;
            return { blackTotal, whiteTotal };
        }

        function drawBoardTriweight() {
            const boardSize = ps.BOARD_SIZE;
            const PADDING = ps.PADDING;
            const CELL_SIZE = ps.CELL_SIZE;
            const board = ps.board;
            const weights = ps.weights;
            function isUserBoardMarkVisibleAt(r, c) {
                if (ps.showEstimateActive) return false;
                if (r < 0 || r >= boardSize || c < 0 || c >= boardSize) return false;
                if (board[r][c] !== 0) return false;
                return true;
            }
            function computeStoneNumbers() {
                const nums = Array(boardSize).fill().map(() => Array(boardSize).fill(0));
                if (ps.replayMode && ps.tryPlayMode) {
                    for (let i = 1; i <= ps.tryPlayStep; i++) {
                        const markers = ps.tryPlayMarkers[i];
                        if (markers && markers.length > 0) {
                            const m = markers[0];
                            if (m.row < boardSize && m.col < boardSize && board[m.row][m.col] !== 0)
                                nums[m.row][m.col] = i;
                        }
                    }
                } else if (ps.replayMode) {
                    for (let i = 1; i <= ps.replayStep; i++) {
                        const markers = ps.replayMarkers[i];
                        if (markers && markers.length > 0) {
                            const m = markers[0];
                            if (m.row < boardSize && m.col < boardSize && board[m.row][m.col] !== 0)
                                nums[m.row][m.col] = i;
                        }
                    }
                } else if (ps.liveReplayBoards.length && ps.liveViewStep < ps.liveReplayBoards.length - 1) {
                    for (let i = 1; i <= ps.liveViewStep; i++) {
                        const markers = ps.liveReplayMarkers[i];
                        if (markers && markers.length > 0) {
                            const m = markers[0];
                            if (m.row < boardSize && m.col < boardSize && board[m.row][m.col] !== 0)
                                nums[m.row][m.col] = i;
                        }
                    }
                } else {
                    for (let i = 0; i < ps.moveLog.length; i++) {
                        const m = ps.moveLog[i];
                        if (m && m.row < boardSize && m.col < boardSize && board[m.row][m.col] !== 0)
                            nums[m.row][m.col] = i + 1;
                    }
                }
                return nums;
            }

            ctx.clearRect(0, 0, 600, 600);
            for (let r = 0; r < boardSize; r++) {
                for (let c = 0; c < boardSize; c++) {
                    const w = safeWeightAt(weights, r, c);
                    if (w >= 2 && w <= 3) {
                        ctx.fillStyle = weightColorMap[w];
                        ctx.fillRect(PADDING + c * CELL_SIZE, PADDING + r * CELL_SIZE, CELL_SIZE, CELL_SIZE);
                    }
                }
            }
            ctx.lineWidth = 1.5;
            ctx.strokeStyle = '#3a281c';
            for (let i = 0; i <= boardSize; i++) {
                ctx.beginPath();
                ctx.moveTo(PADDING + i * CELL_SIZE, PADDING);
                ctx.lineTo(PADDING + i * CELL_SIZE, 600 - PADDING);
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(PADDING, PADDING + i * CELL_SIZE);
                ctx.lineTo(600 - PADDING, PADDING + i * CELL_SIZE);
                ctx.stroke();
            }

            ctx.font = `bold ${17 - 0.2 * boardSize}px Arial`;
            ctx.fillStyle = '#3a281c';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            for (let c = 0; c < boardSize; c++) {
                const letter = String.fromCharCode(65 + c);
                const x = PADDING + c * CELL_SIZE + CELL_SIZE / 2;
                const y = 0.6 * PADDING;
                ctx.fillText(letter, x, y);
            }
            for (let r = 0; r < boardSize; r++) {
                const num = (r + 1).toString();
                const x = 0.6 * PADDING;
                const y = PADDING + r * CELL_SIZE + CELL_SIZE / 2;
                ctx.fillText(num, x, y);
            }

            const stoneRadius = CELL_SIZE * 0.38;
            const markLenDefault = CELL_SIZE * 0.25;
            const lowerLastMoveMarker = ps.showMoveNumbers || ps.showEstimateActive;
            if (lowerLastMoveMarker) {
                for (let { row, col, color } of ps.lastMoveMarkers) {
                    const x = PADDING + col * CELL_SIZE + CELL_SIZE / 2;
                    const y = PADDING + row * CELL_SIZE + CELL_SIZE / 2;
                    ctx.beginPath();
                    ctx.moveTo(x + stoneRadius, y + stoneRadius);
                    ctx.lineTo(x, y + stoneRadius);
                    ctx.lineTo(x + stoneRadius, y);
                    ctx.closePath();
                    ctx.fillStyle = color === 1 ? '#fff' : '#222';
                    ctx.fill();
                }
            }

            for (let r = 0; r < boardSize; r++) {
                for (let c = 0; c < boardSize; c++) {
                    const val = board[r][c];
                    if (val === 0) continue;
                    const x = PADDING + c * CELL_SIZE + CELL_SIZE / 2;
                    const y = PADDING + r * CELL_SIZE + CELL_SIZE / 2;
                    const radius = stoneRadius;
                    ctx.save();
                    ctx.shadowBlur = 6;
                    ctx.shadowColor = 'rgba(0,0,0,0.5)';
                    ctx.shadowOffsetY = 2;
                    const grad = ctx.createRadialGradient(x - 3, y - 3, radius * 0.2, x, y, radius * 1.2);
                    if (val === 1) {
                        grad.addColorStop(0, '#444');
                        grad.addColorStop(0.6, '#222');
                        grad.addColorStop(1, '#111');
                    } else {
                        grad.addColorStop(0, '#fff');
                        grad.addColorStop(0.5, '#eee');
                        grad.addColorStop(1, '#aaa');
                    }
                    ctx.beginPath();
                    ctx.arc(x, y, radius, 0, 2 * Math.PI);
                    ctx.fillStyle = grad;
                    ctx.fill();
                    ctx.restore();
                    ctx.beginPath();
                    ctx.arc(x - 3, y - 3, radius * 0.15, 0, 2 * Math.PI);
                    ctx.fillStyle = val === 1 ? '#444' : '#fff';
                    ctx.fill();
                }
            }
            if (!lowerLastMoveMarker) {
                const markLen = markLenDefault;
                for (let { row, col, color } of ps.lastMoveMarkers) {
                    const x = PADDING + col * CELL_SIZE + CELL_SIZE / 2;
                    const y = PADDING + row * CELL_SIZE + CELL_SIZE / 2;
                    ctx.beginPath();
                    ctx.moveTo(x, y);
                    ctx.lineTo(x + markLen, y);
                    ctx.lineTo(x, y + markLen);
                    ctx.closePath();
                    ctx.fillStyle = color === 1 ? '#fff' : '#222';
                    ctx.fill();
                }
            }
            if (ps.showMoveNumbers) {
                const nums = computeStoneNumbers();
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                for (let r = 0; r < boardSize; r++) {
                    for (let c = 0; c < boardSize; c++) {
                        if (nums[r][c] > 0 && board[r][c] !== 0) {
                            const sx = PADDING + c * CELL_SIZE + CELL_SIZE / 2;
                            const sy = PADDING + r * CELL_SIZE + CELL_SIZE / 2;
                            const numStr = nums[r][c].toString();
                            const fontSize = Math.max(9, Math.floor(CELL_SIZE * (numStr.length >= 3 ? 0.308 : 0.396)));
                            ctx.font = `bold ${fontSize}px Arial`;
                            ctx.fillStyle = board[r][c] === 1 ? '#fff' : '#000';
                            ctx.fillText(numStr, sx, sy + 1);
                        }
                    }
                }
            }
            const canHover = ps.tryPlayMode || (!ps.gameOver && ps.isMyTurn);
            if (canHover && ps.isHoverValid && ps.hoverRow >= 0 && ps.hoverCol >= 0 && board[ps.hoverRow][ps.hoverCol] === 0) {
                ctx.globalAlpha = 0.45;
                const x = PADDING + ps.hoverCol * CELL_SIZE + CELL_SIZE / 2;
                const y = PADDING + ps.hoverRow * CELL_SIZE + CELL_SIZE / 2;
                ctx.beginPath();
                ctx.arc(x, y, CELL_SIZE * 0.38, 0, 2 * Math.PI);
                const hoverColor = ps.tryPlayMode ? (ps.tryPlayCurrentPlayer === 1 ? '#222' : '#ddd') : (ps.mySlot === 'black' ? '#222' : '#ddd');
                ctx.fillStyle = hoverColor;
                ctx.fill();
                ctx.globalAlpha = 1.0;
            }
            for (const key of Object.keys(ps.userBoardMarks)) {
                const [r, c] = key.split(',').map(Number);
                if (r < 0 || r >= boardSize || c < 0 || c >= boardSize) continue;
                if (!isUserBoardMarkVisibleAt(r, c)) continue;
                const ch = ps.userBoardMarks[key];
                const x = PADDING + c * CELL_SIZE + CELL_SIZE / 2;
                const y = PADDING + r * CELL_SIZE + CELL_SIZE / 2;
                const fontPx = CELL_SIZE * (ch === '🚩' ? 0.6 : 0.66);
                ctx.font = `bold ${fontPx}px "Segoe UI", "Apple Color Emoji", "Segoe UI Emoji", sans-serif`;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillStyle = '#3a281c';
                ctx.fillText(ch, x, y + 1);
            }
            if (ps.showEstimateActive && ps.cachedLiveBoard && ps.cachedTerritory) {
                const dotRadius = CELL_SIZE * 0.16;
                for (let r = 0; r < boardSize; r++) {
                    for (let c = 0; c < boardSize; c++) {
                        const x = PADDING + c * CELL_SIZE + CELL_SIZE / 2;
                        const y = PADDING + r * CELL_SIZE + CELL_SIZE / 2;
                        if (board[r][c] !== 0 && ps.cachedLiveBoard[r][c] === 0) {
                            ctx.fillStyle = board[r][c] === 1 ? '#fff' : '#222';
                            ctx.fillRect(x - dotRadius, y - dotRadius, dotRadius * 2, dotRadius * 2);
                        } else if (board[r][c] === 0 && ps.cachedTerritory[r][c] === 1) {
                            ctx.fillStyle = '#222';
                            ctx.fillRect(x - dotRadius, y - dotRadius, dotRadius * 2, dotRadius * 2);
                        } else if (board[r][c] === 0 && ps.cachedTerritory[r][c] === 2) {
                            ctx.fillStyle = '#f0f0f0';
                            ctx.fillRect(x - dotRadius, y - dotRadius, dotRadius * 2, dotRadius * 2);
                        }
                    }
                }
            }
        }

        const domPage = {
            turnDisplay,
            scoreTitle,
            scoreBoard,
            leadInfo,
            scoreConfirmPanel,
            scoreConfirmText,
            komiInfo,
            canvas,
            ctx,
            boardMarkSelect,
            colorStatus
        };

        const page = QiWeiqiSquarePageRuntime.create(ps, domPage, {
            enableEditBoard: true,
            recordDownloadPrefix,
            minLib,
            maxWeakLiberties: 2,
            gameType,
            roomId,
            roomPassword,
            isMouseDevice,
            drawBoard: drawBoardTriweight,
            komiInfoText: () => '黑贴白6.25点'});

        function applyTriweightSyncExtras(state) {
            const n = ps.BOARD_SIZE;
            ps.weights = normalizeWeightMatrix(state.weights || ps.weights, n);
            ps.KOMI = 6.25;
        }

        page.updateBoardGeometry = function triSquareCellGeometry() {
            const n = ps.BOARD_SIZE;
            const padding = 63 - 2 * n;
            ps.PADDING = padding;
            ps.CELL_SIZE = (600 - 2 * padding) / n;
            page.drawBoard();
            if (komiInfo) komiInfo.innerText = '黑贴白6.25点';
        };

        const _triSyncState = page.syncState;
        page.syncState = function triSyncState(state) {
            const incomingSize = Number.isInteger(state.boardSize) ? state.boardSize : ps.BOARD_SIZE;
            ps.weights = normalizeWeightMatrix(state.weights || ps.weights, incomingSize);
            _triSyncState(state);
            applyTriweightSyncExtras(state);
            const n = ps.BOARD_SIZE;
            ps.PADDING = 63 - 2 * n;
            ps.CELL_SIZE = (600 - 2 * ps.PADDING) / n;
            page.drawBoard();
        };

        page.showEstimate = function triShowEstimate() {
            if (!ps.showEstimateActive) {
                page.clearEstimate();
                return;
            }
            if (ps.ws && ps.ws.readyState === WebSocket.OPEN && !ps.replayMode && !ps.tryPlayMode) {
                ps.ws.send(JSON.stringify({ type: 'estimate' }));
                return;
            }
            const r = C().computeWeiqiEstimateCaches(
                ps.board, page.removeDeadAndDying, page.assignTerritoryWithRange, triWeightedComputeScore, ps.KOMI
            );
            ps.cachedLiveBoard = r.cachedLiveBoard;
            ps.cachedTerritory = r.cachedTerritory;
            C().fillWeiqiEstimatePanel(scoreTitle, scoreBoard, leadInfo, r.blackTotal, r.whiteTotal, r.lead);
            page.drawBoard();
        };

        const _triEnterReplay = page.enterReplayMode;
        page.enterReplayMode = function triEnterReplay(data) {
            if (data.weights && data.weights.length === ps.BOARD_SIZE)
                ps.weights = data.weights.map(row => row.slice());
            if (data.initialPosition && typeof data.initialPosition === 'object' && !Array.isArray(data.initialPosition))
                data.initialPosition = normalizeReplayInitialPayload(data.initialPosition);
            _triEnterReplay(data);
        };

        const {
            mobileTwoStepPlacing,
            clearMobileMovePreview,
            drawBoard,
            updateTurn,
            showEstimate,
            clearEstimate,
            downloadRecord,
            showScoreConfirm,
            hideScoreConfirm,
            enterReplayMode,
            exitReplayMode,
            setReplayStep,
            updateReplayUI,
            enterTryPlay,
            exitTryPlay,
            tryPlayMove,
            setTryPlayStep,
            updateTryPlayDisplay,
            rebuildLiveReplayFromMoveCoords,
            applyLiveViewBoard,
            updateLiveReplayPanelUI,
            setLiveViewStep,
            connectWebSocket,
            initBoardArray,
            updateBoardGeometry,
            syncState,
            commitMove,
            canvasCoordsFromClient,
            applyUserBoardMark
        } = page;

        function updateEstimate(msg) {
            ps.cachedLiveBoard = msg.liveBoard;
            ps.cachedTerritory = msg.territory;
            scoreTitle.innerText = '形势判断';
            scoreBoard.innerText = `黑: ${msg.blackTotal.toFixed(0)}　白: ${msg.whiteTotal.toFixed(0)}`;
            leadInfo.innerText = `黑${msg.lead >= 0 ? '+' : ''}${msg.lead.toFixed(1)}点`;
            drawBoard();
        }

        function getClosestCell(x, y) {
            let minDist = Infinity, bestR = -1, bestC = -1;
            for (let r = 0; r < ps.BOARD_SIZE; r++) {
                for (let c = 0; c < ps.BOARD_SIZE; c++) {
                    const cx = ps.PADDING + c * ps.CELL_SIZE + ps.CELL_SIZE / 2;
                    const cy = ps.PADDING + r * ps.CELL_SIZE + ps.CELL_SIZE / 2;
                    const d = Math.hypot(x - cx, y - cy);
                    if (d < minDist) { minDist = d; bestR = r; bestC = c; }
                }
            }
            return { row: bestR, col: bestC };
        }

        const _weiqiBindings = QiBoardRoomClient.createWeiqiMessageBindings({
            roomId,
            gameType,
            pageState: ps,
            drawBoard,
            exitTryPlay,
            enterTryPlay,
            setTryPlayStep,
            setReplayStep,
            setLiveViewStep,
            getWs: () => ps.ws,
            getBoardSize: () => ps.BOARD_SIZE,
            setBoardSize: (n) => { ps.BOARD_SIZE = n; },
            getKomi: () => ps.KOMI,
            setKomi: (n) => { ps.KOMI = n; },
            getBoard: () => ps.board,
            setBoard: (b) => { ps.board = b; },
            getSlots: () => ps.slots,
            setSlots: (s) => { ps.slots = s; },
            getMySlot: () => ps.mySlot,
            setMySlot: (s) => { ps.mySlot = s; },
            getGameOver: () => ps.gameOver,
            setGameOver: (v) => { ps.gameOver = v; },
            getWinner: () => ps.winner,
            setWinner: (w) => { ps.winner = w; },
            getReplayMode: () => ps.replayMode,
            getShowEstimateActive: () => ps.showEstimateActive,
            setShowEstimateActive: (v) => { ps.showEstimateActive = v; },
            getWaitingScoreConfirm: () => ps.waitingScoreConfirm,
            setWaitingScoreConfirm: (v) => { ps.waitingScoreConfirm = v; },
            getIRejected: () => ps.iRejected,
            setIRejected: (v) => { ps.iRejected = v; },
            colorStatus,
            scoreTitle,
            turnDisplay,
syncState,
            updateBoardGeometry,
            initBoardArray,
            exitReplayMode,
            clearEstimate,
            hideScoreConfirm,
            showEstimate,
            clearMobileMovePreview,
            downloadRecord,
            enterReplayMode,
            updateTurn,
            updateReplayUI,
            showScoreConfirm,
            isMouseDevice,
            onNewGameStarted: () => { colorStatus.innerText = '未选择阵营'; },
            standardWeiqiMatchTime,
            boardSeatOverlay: true
        });

        function handleMessage(msg) {
            if (msg.type === 'estimateResult') {
                updateEstimate(msg);
                return;
            }
            _weiqiBindings.handleMessage(msg);
        }

        let suppressCanvasClickAfterLongMark = false;

        canvas.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            const { x, y } = canvasCoordsFromClient(e.clientX, e.clientY);
            const { row, col } = getClosestCell(x, y);
            applyUserBoardMark(row, col);
        });

        const LONG_MARK_MS = 500;
        const LONG_MARK_MOVE_CANCEL = 14;
        let longMarkTimer = null;
        let longMarkStart = null;

        canvas.addEventListener('touchstart', (e) => {
            if (e.touches.length !== 1) return;
            const t = e.touches[0];
            longMarkStart = { x: t.clientX, y: t.clientY };
            longMarkTimer = setTimeout(() => {
                longMarkTimer = null;
                if (!longMarkStart) return;
                const { x, y } = canvasCoordsFromClient(longMarkStart.x, longMarkStart.y);
                const { row, col } = getClosestCell(x, y);
                applyUserBoardMark(row, col);
                suppressCanvasClickAfterLongMark = true;
                setTimeout(() => { suppressCanvasClickAfterLongMark = false; }, 450);
                longMarkStart = null;
            }, LONG_MARK_MS);
        }, { passive: true });

        canvas.addEventListener('touchmove', (e) => {
            if (!longMarkTimer || !longMarkStart || e.touches.length !== 1) return;
            const t = e.touches[0];
            const dx = t.clientX - longMarkStart.x;
            const dy = t.clientY - longMarkStart.y;
            if (dx * dx + dy * dy > LONG_MARK_MOVE_CANCEL * LONG_MARK_MOVE_CANCEL) {
                clearTimeout(longMarkTimer);
                longMarkTimer = null;
            }
        }, { passive: true });

        function clearLongMarkTouch() {
            if (longMarkTimer) {
                clearTimeout(longMarkTimer);
                longMarkTimer = null;
            }
            longMarkStart = null;
        }
        canvas.addEventListener('touchend', clearLongMarkTouch);
        canvas.addEventListener('touchcancel', clearLongMarkTouch);

        canvas.addEventListener('click', (e) => {
            if (suppressCanvasClickAfterLongMark) {
                e.preventDefault();
                return;
            }
            const rect = canvas.getBoundingClientRect();
            const scale = 600 / rect.width;
            const x = (e.clientX - rect.left) * scale;
            const y = (e.clientY - rect.top) * scale;
            const { row, col } = getClosestCell(x, y);

            if (ps.tryPlayMode && ps.replayMode) {
                if (row < 0 || col < 0) {
                    if (mobileTwoStepPlacing()) clearMobileMovePreview();
                    drawBoard();
                    return;
                }
                if (ps.board[row][col] !== 0) return;
                if (mobileTwoStepPlacing()) {
                    if (ps.hoverRow === row && ps.hoverCol === col && ps.isHoverValid) {
                        clearMobileMovePreview();
                        tryPlayMove(row, col);
                    } else {
                        ps.hoverRow = row;
                        ps.hoverCol = col;
                        ps.isHoverValid = true;
                        drawBoard();
                    }
                    return;
                }
                tryPlayMove(row, col);
                return;
            }
            if (ps.gameOver) return;
            if (!ps.isMyTurn) return;
            if (ps.waitingScoreConfirm) return;

            if (row < 0 || col < 0) {
                if (mobileTwoStepPlacing()) clearMobileMovePreview();
                drawBoard();
                return;
            }
            if (ps.board[row][col] !== 0) return;

            if (mobileTwoStepPlacing()) {
                if (ps.hoverRow === row && ps.hoverCol === col && ps.isHoverValid) {
                    clearMobileMovePreview();
                    commitMove(row, col);
                    drawBoard();
                } else {
                    ps.hoverRow = row;
                    ps.hoverCol = col;
                    ps.isHoverValid = true;
                    drawBoard();
                }
                return;
            }
            commitMove(row, col);
        });

        if (isMouseDevice) {
            canvas.addEventListener('mousemove', (e) => {
                if (ps.waitingScoreConfirm) {
                    if (ps.isHoverValid) { ps.isHoverValid = false; ps.hoverRow = -1; ps.hoverCol = -1; drawBoard(); }
                    return;
                }
                const rect = canvas.getBoundingClientRect();
                const scale = 600 / rect.width;
                const x = (e.clientX - rect.left) * scale;
                const y = (e.clientY - rect.top) * scale;
                const { row, col } = getClosestCell(x, y);
                ps.hoverRow = row; ps.hoverCol = col;
                ps.isHoverValid = (row >= 0 && col >= 0 && ps.board[row][col] === 0);
                drawBoard();
            });
            canvas.addEventListener('mouseleave', () => {
                if (!ps.waitingScoreConfirm) {
                    ps.isHoverValid = false;
                    ps.hoverRow = -1; ps.hoverCol = -1;
                    drawBoard();
                }
            });
        }

        if (scoreConfirmYes) {
            scoreConfirmYes.onclick = () => {
                ps.ws.send(JSON.stringify({ type: 'scoreResponse', accept: true }));
                hideScoreConfirm();
            };
            scoreConfirmNo.onclick = () => {
                ps.iRejected = true;
                ps.ws.send(JSON.stringify({ type: 'scoreResponse', accept: false }));
                hideScoreConfirm();
                if (ps.showEstimateActive) {
                    ps.showEstimateActive = false;
                    clearEstimate();
                }
                ps.waitingScoreConfirm = false;
            };
        }
        connectWebSocket(handleMessage);
        })();
    }
};
