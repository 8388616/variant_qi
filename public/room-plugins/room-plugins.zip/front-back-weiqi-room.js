window.RoomPlugins = window.RoomPlugins || {};
window.RoomPlugins["front-back-weiqi"] = {
    shell: {
        "title": "正反面围棋",
        "rulesHtml": "基本规则同围棋。<br /><br />双方依次在正面和反面落子。<br /><br />在某一面落子时，另一面同位置变为雷。雷不可落子、不可被提，但提供气；在雷上落子无效，但会清除该雷，清除后可正常落子。<br /><br />双方连续四步虚着终局，点数按两面点数之和计，无贴目。<br />",
        "defaultKomiText": "无贴目",
        "boardSizeMin": 5,
        "boardSizeMax": 19,
        "defaultBoardSize": 15,
        "minLib": 1,
        "recordDownloadPrefix": "正反面围棋",
        "standardWeiqiMatchTime": true,
        "features": {
            "editBoard": true,
            "dualBoards": true
        },
        "editTools": [
            {
                "value": "empty",
                "label": "空"
            },
            {
                "value": "black",
                "label": "黑子"
            },
            {
                "value": "white",
                "label": "白子"
            }
        ]
    },
    mount: function (ctx) {
        var gameType = ctx.gameType;
        var roomId = ctx.roomId;
        var roomPassword = ctx.roomPassword || null;
        var config = ctx.config || {};
        var recordDownloadPrefix = config.recordDownloadPrefix != null ? config.recordDownloadPrefix : "正反面围棋";
        var minLib = config.minLib != null ? config.minLib : 1;
        var standardWeiqiMatchTime = config.standardWeiqiMatchTime != null ? config.standardWeiqiMatchTime : true;


        (function () {
let BOARD_SIZE = 15;
        const CANVAS_PX = 450;
        let PADDING = 0;
        let CELL_SIZE = 0;
        const C = () => QiSquareWeiqiCanvas;
        const R = () => QiWeiqiSquarePageRuntime;
        function refreshGeometryFromQi() {
            const g = C().computePaddingAndCell(BOARD_SIZE, CANVAS_PX);
            PADDING = g.padding;
            CELL_SIZE = g.cellSize;
        }
        refreshGeometryFromQi();

let boardA = initBoard(BOARD_SIZE);
        let boardB = initBoard(BOARD_SIZE);
        let minesA = [];
        let minesB = [];
        let nextMoveNumber = 1;
        let expectedBoard = 'A';
        let expectedSlot = 'black';
        let lastMoveMarkers = [];
        let moveCoords = [];
        let passCounter = 0;
        let cachedLiveA = null, cachedTerrA = null;
        let cachedLiveB = null, cachedTerrB = null;
        /** createWeiqiMessageBindings 使用的 pageState（与标准围棋页 ps 字段对齐） */
        const ps = {
            mySlot: null,
            slots: { black: false, white: false },
            ws: null,
            showEstimateActive: false,
            isMyTurn: false,
            iRejected: false,
            replayMode: false,
            tryPlayMode: false,
            showMoveNumbers: false,
            tryPlayStep: 0,
            replayStep: 0,
            liveViewStep: 0,
            liveFollowLatest: true,
            replayTotalSteps: 0,
            tryPlayBaseReplayStep: 0,
            tryPlayTotalSteps: 0,
            waitingScoreConfirm: false,
            gameOver: false,
            winner: null,
            _lastScoreBlack: null,
            _lastScoreWhite: null
        };
        let reconnectTimer = null;
        let updateRecordButtonsBound = () => {};
        let updateRadioStylesBound = () => {};
        /** 每步完整局面，供 live 复盘 / import 打谱 / 试下 */
        let liveReplaySnaps = [];
        let replaySnaps = [];
        let tryPlaySnaps = [];
        let tryPlayMoveList = [];

        const canvasA = document.getElementById('boardA');
        const canvasB = document.getElementById('boardB');
        const ctxA = canvasA.getContext('2d');
        const ctxB = canvasB.getContext('2d');
        const turnDisplay = document.getElementById('turnDisplay');
        const colorStatus = document.getElementById('colorStatus');
const scoreTitle = document.getElementById('scoreTitle');
        const scoreBoard = document.getElementById('scoreBoard');
        const leadInfo = document.getElementById('leadInfo');
        const scoreConfirmPanel = document.getElementById('scoreConfirmPanel');
        const scoreConfirmText = document.getElementById('scoreConfirmText');
        const scoreConfirmYes = document.getElementById('scoreConfirmYes');
        const scoreConfirmNo = document.getElementById('scoreConfirmNo');
        const boardMarkSelect = document.getElementById('boardMarkSelect');

        /** 本地标记，键 "A|r,c" / "B|r,c"（仅本机；两面共用一套选项） */
        let userBoardMarks = Object.create(null);
        const BOARD_MARK_CHAR_LIST = (() => {
            const a = [];
            a.push('?', '!');
            for (let i = 0; i < 26; i++) a.push(String.fromCharCode(65 + i));
            a.push('△', '▽', '♡', '○', '◇', '□', '☆', '×', '🚩');
            return a;
        })();

        QiSquareWeiqiCanvas.initBoardMarkSelectDom(boardMarkSelect, BOARD_MARK_CHAR_LIST);
        QiSquareWeiqiCanvas.initBoardMarkFoldDom(
            document.getElementById('boardMarkPanel'),
            document.getElementById('boardMarkFoldBtn'),
            document.getElementById('boardMarkExpandBtn')
        );

        let hoverA = { row: -1, col: -1, ok: false };
        let hoverB = { row: -1, col: -1, ok: false };
        const isMouseDevice = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

        function mobileTwoStepPlacing() {
            return !isMouseDevice && BOARD_SIZE > 9;
        }
        function clearMobileMovePreview() {
            hoverA.row = -1; hoverA.col = -1; hoverA.ok = false;
            hoverB.row = -1; hoverB.col = -1; hoverB.ok = false;
        }

        function initBoard(n) {
            return Array(n).fill().map(() => Array(n).fill(0));
        }

        function deepCopyBoard(b) { return b.map(row => row.slice()); }

        /** 与方格围棋 bindings 的 getBoard 一致：用于导入/导出按钮显隐（任一面有子即视为有子） */
        function getMergedBoardForBindings() {
            const n = BOARD_SIZE;
            const out = initBoard(n);
            for (let r = 0; r < n; r++) {
                for (let c = 0; c < n; c++) {
                    out[r][c] = boardA[r][c] !== 0 ? boardA[r][c] : (boardB[r][c] !== 0 ? boardB[r][c] : 0);
                }
            }
            return out;
        }

        function unwrapGameStatePayload(x) {
            if (!x) return x;
            const b = x.board;
            if (b && typeof b === 'object' && !Array.isArray(b) && (b.boardA != null || b.boardB != null || b.boardSize != null))
                return b;
            return x;
        }

        function isMine(mines, r, c) {
            return mines.some(p => p.row === r && p.col === c);
        }

        function updateBoardGeometry() {
            refreshGeometryFromQi();
            drawAllBoards();
        }

        function isUserBoardMarkVisibleAt(which, r, c) {
            if (ps.showEstimateActive) return false;
            if (r < 0 || r >= BOARD_SIZE || c < 0 || c >= BOARD_SIZE) return false;
            const board = which === 'A' ? boardA : boardB;
            const mines = which === 'A' ? minesA : minesB;
            if (board[r][c] !== 0) return false;
            if (isMine(mines, r, c)) return false;
            return true;
        }

        function getClosestIntersection(x, y) {
            return C().getClosestIntersection(x, y, BOARD_SIZE, PADDING, CELL_SIZE);
        }

        /**
         * 与标准围棋类似：序号按全局手数（含虚着、清雷），仅落子记在交叉点上；提子后该点无子则无数。
         */
        function getMoveCoordsForNumbering() {
            if (ps.tryPlayMode && ps.replayMode) {
                return moveCoords.slice(0, ps.tryPlayBaseReplayStep).concat(
                    tryPlayMoveList.slice(0, ps.tryPlayStep).map(m => ({ ...m }))
                );
            }
            if (ps.replayMode) return moveCoords.slice(0, ps.replayStep);
            const total = getLiveReplayTotal();
            if (liveReplaySnaps.length && ps.liveViewStep < total) return moveCoords.slice(0, ps.liveViewStep);
            return moveCoords;
        }

        function computeStoneNumbersForBoard(which) {
            const nums = Array(BOARD_SIZE).fill().map(() => Array(BOARD_SIZE).fill(0));
            const boardRef = which === 'A' ? boardA : boardB;
            let ply = 0;
            for (const m of getMoveCoordsForNumbering()) {
                ply++;
                if (m.type === 'move' && m.board === which) {
                    nums[m.row][m.col] = ply;
                }
            }
            for (let r = 0; r < BOARD_SIZE; r++) {
                for (let c = 0; c < BOARD_SIZE; c++) {
                    if (boardRef[r][c] === 0) nums[r][c] = 0;
                }
            }
            return nums;
        }

        function drawBoardLayer(ctx, board, mines, which) {
            C().draw.clear(ctx, CANVAS_PX);
            const wood = which === 'A'
                ? ['#eec897', '#deb887']
                : ['#dba675', '#cb9665'];
            const bg = ctx.createLinearGradient(0.5 * CANVAS_PX, 0, 0.5 * CANVAS_PX, CANVAS_PX);
            bg.addColorStop(0, wood[0]);
            bg.addColorStop(1, wood[1]);
            ctx.fillStyle = bg;
            ctx.fillRect(0, 0, CANVAS_PX, CANVAS_PX);
            C().draw.grid(ctx, BOARD_SIZE, PADDING, CELL_SIZE, CANVAS_PX);
            C().draw.starPoints(ctx, BOARD_SIZE, PADDING, CELL_SIZE, C().getStarPoints(BOARD_SIZE));

            const stoneRadius = CELL_SIZE * 0.44;
            const markLenDefault = CELL_SIZE * 0.352;
            const lowerLastMoveMarker = ps.showMoveNumbers || ps.showEstimateActive;
            const markersHere = lastMoveMarkers.filter(m => (m.board === 'A' && ctx === ctxA) || (m.board === 'B' && ctx === ctxB));
            if (lowerLastMoveMarker) {
                C().draw.lastMoveMarkersLower(ctx, markersHere, PADDING, CELL_SIZE, stoneRadius);
            }

            C().draw.stonesBlackWhite(ctx, board, BOARD_SIZE, PADDING, CELL_SIZE, stoneRadius, ps.showMoveNumbers);

            for (const p of mines) {
                R().drawMine(p.row, p.col, ctx, PADDING, CELL_SIZE);
            }

            if (ps.showMoveNumbers) {
                const nums = computeStoneNumbersForBoard(which);
                C().draw.moveNumbersOnStones(ctx, nums, board, BOARD_SIZE, PADDING, CELL_SIZE);
            }

            if (!lowerLastMoveMarker) {
                C().draw.lastMoveMarkersUpper(ctx, markersHere, PADDING, CELL_SIZE, markLenDefault);
            }
            const markPrefix = which + '|';
            const markBg = which === 'A' ? '#deb887' : '#cb9665';
            for (const key of Object.keys(userBoardMarks)) {
                if (!key.startsWith(markPrefix)) continue;
                const [r, c] = key.slice(markPrefix.length).split(',').map(Number);
                if (!isUserBoardMarkVisibleAt(which, r, c)) continue;
                const ch = userBoardMarks[key];
                const x = PADDING + c * CELL_SIZE;
                const y = PADDING + r * CELL_SIZE;
                const markBgR = CELL_SIZE * 0.3;
                ctx.beginPath();
                ctx.arc(x, y, markBgR, 0, 2 * Math.PI);
                ctx.fillStyle = markBg;
                ctx.fill();
                const fontPx = CELL_SIZE * (ch === '🚩' ? 0.6 : 0.66);
                ctx.font = `bold ${fontPx}px "Segoe UI", "Apple Color Emoji", "Segoe UI Emoji", sans-serif`;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillStyle = '#3a281c';
                ctx.fillText(ch, x, y + 1);
            }
        }

        function drawHover(ctx, board, mines, which, hover) {
            if (ps.showEstimateActive || ps.gameOver || !ps.mySlot || isLiveBrowsingHistory() || ps.replayMode || ps.tryPlayMode || !isMyTurn() || !hover.ok || hover.row < 0) return;
            if (expectedBoard !== which) return;
            const r = hover.row, c = hover.col;
            if (board[r][c] !== 0) return;
            if (isMine(mines, r, c)) {
                const cx = PADDING + c * CELL_SIZE;
                const cy = PADDING + r * CELL_SIZE;
                R().stoneDanger.drawRing(ctx, cx, cy, CELL_SIZE * 0.44, '#d62828', CELL_SIZE * 0.055);
                return;
            }
            ctx.globalAlpha = 0.45;
            ctx.beginPath();
            ctx.arc(PADDING + c * CELL_SIZE, PADDING + r * CELL_SIZE, CELL_SIZE * 0.44, 0, 2 * Math.PI);
            ctx.fillStyle = ps.mySlot === 'black' ? '#222' : '#ddd';
            ctx.fill();
            ctx.globalAlpha = 1;
        }

        /** 与洞围棋洞类似：BFS 不穿雷、雷不作起点；数点用 computeScoreWithHoles 排除雷点目数 */
        function assignTerritoryBlockingMines(liveBoard, mines) {
            const territory = Array(BOARD_SIZE).fill().map(() => Array(BOARD_SIZE).fill(0));
            const n = BOARD_SIZE;
            for (let r = 0; r < n; r++) {
                for (let c = 0; c < n; c++) {
                    if (liveBoard[r][c] !== 0) continue;
                    if (isMine(mines, r, c)) continue;
                    const maxDist = (r <= 1 || r >= n - 2 || c <= 1 || c >= n - 2) ? 5 : 4;
                    let blackMin = Infinity, whiteMin = Infinity;
                    const dist = Array(n).fill().map(() => Array(n).fill(Infinity));
                    dist[r][c] = 0;
                    const queue = [[r, c]];
                    let front = 0;
                    const dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
                    while (front < queue.length) {
                        const [cr, cc] = queue[front++];
                        const d = dist[cr][cc];
                        if (d > maxDist) continue;
                        if (liveBoard[cr][cc] === 1 && d < blackMin) blackMin = d;
                        if (liveBoard[cr][cc] === 2 && d < whiteMin) whiteMin = d;
                        for (const [dr, dc] of dirs) {
                            const nr = cr + dr, nc = cc + dc;
                            if (nr < 0 || nr >= n || nc < 0 || nc >= n) continue;
                            if (isMine(mines, nr, nc)) continue;
                            if (dist[nr][nc] !== Infinity) continue;
                            dist[nr][nc] = d + 1;
                            queue.push([nr, nc]);
                        }
                    }
                    if (blackMin <= maxDist && whiteMin <= maxDist) {
                        if (blackMin < whiteMin) territory[r][c] = 1;
                        else if (whiteMin < blackMin) territory[r][c] = 2;
                        else territory[r][c] = 3;
                    } else if (blackMin <= maxDist) territory[r][c] = 1;
                    else if (whiteMin <= maxDist) territory[r][c] = 2;
                    else territory[r][c] = 3;
                }
            }
            return territory;
        }

        function drawAllBoards() {
            drawBoardLayer(ctxA, boardA, minesA, 'A');
            drawBoardLayer(ctxB, boardB, minesB, 'B');
            if (ps.showEstimateActive) {
                C().draw.estimateOverlay(ctxA, boardA, BOARD_SIZE, PADDING, CELL_SIZE, cachedLiveA, cachedTerrA);
                C().draw.estimateOverlay(ctxB, boardB, BOARD_SIZE, PADDING, CELL_SIZE, cachedLiveB, cachedTerrB);
            }
            drawHover(ctxA, boardA, minesA, 'A', hoverA);
            drawHover(ctxB, boardB, minesB, 'B', hoverB);
        }

        function removeDeadAndDyingScore(board) {
            return R().removeDeadAndDying(board, BOARD_SIZE, b => C().deepCopyBoard(b), 2);
        }

        function showEstimate() {
            if (!ps.showEstimateActive) { clearEstimate(); return; }
            cachedLiveA = removeDeadAndDyingScore(boardA);
            cachedTerrA = assignTerritoryBlockingMines(cachedLiveA, minesA);
            cachedLiveB = removeDeadAndDyingScore(boardB);
            cachedTerrB = assignTerritoryBlockingMines(cachedLiveB, minesB);
            const a = R().computeScoreWithHoles(cachedLiveA, cachedTerrA, BOARD_SIZE, (r, c) => isMine(minesA, r, c));
            const b = R().computeScoreWithHoles(cachedLiveB, cachedTerrB, BOARD_SIZE, (r, c) => isMine(minesB, r, c));
            const blackTotal = a.blackTotal + b.blackTotal;
            const whiteTotal = a.whiteTotal + b.whiteTotal;
            const lead = blackTotal - whiteTotal;
            scoreTitle.innerText = '形势判断';
            scoreBoard.innerText = `黑: ${blackTotal.toFixed(1)}　白: ${whiteTotal.toFixed(1)}`;
            leadInfo.innerText = `黑${lead >= 0 ? '+' : ''}${lead.toFixed(1)}点`;
            drawAllBoards();
        }

        function clearEstimate() {
            cachedLiveA = cachedTerrA = cachedLiveB = cachedTerrB = null;
            scoreTitle.innerText = '　';
            scoreBoard.innerText = '　';
            leadInfo.innerText = '　';
            drawAllBoards();
        }

        function isMyTurn() {
            if (ps.gameOver || !ps.mySlot) return false;
            return ps.mySlot === expectedSlot;
        }

        function slotEmoji(slot) {
            return slot === 'black' ? '⚫' : '⚪';
        }

        /** 与 front-back-weiqi.js 中 expectedSlot() 一致：第 n 手应由谁下 */
        function expectedSlotForMoveNumber(n) {
            const m = ((n % 4) + 4) % 4;
            return (m === 0 || m === 1) ? 'black' : 'white';
        }

        function expectedBoardForMoveNumber(n) {
            const m = ((n % 4) + 4) % 4;
            return (m === 1 || m === 2) ? 'A' : 'B';
        }

        function copyMineList(src) {
            return src.map(p => ({ row: p.row, col: p.col }));
        }

        function cloneSnap(s) {
            return {
                boardA: deepCopyBoard(s.boardA),
                boardB: deepCopyBoard(s.boardB),
                minesA: copyMineList(s.minesA),
                minesB: copyMineList(s.minesB),
                lastMoveMarkers: (s.lastMoveMarkers || []).map(m => ({ ...m })),
                nextMoveNumber: s.nextMoveNumber,
                passCounter: s.passCounter != null ? s.passCounter : 0
            };
        }

        function snapStateString(boardA, boardB, minesA, minesB) {
            const ba = boardA.map(row => row.join(',')).join(';');
            const bb = boardB.map(row => row.join(',')).join(';');
            const ma = minesA.map(p => `${p.row},${p.col}`).sort().join('|');
            const mb = minesB.map(p => `${p.row},${p.col}`).sort().join('|');
            return `${ba}#${bb}#${ma}#${mb}`;
        }

        /**
         * 从手顺重建局面序列（与 front-back-weiqi.js 一致：含劫、清雷、对面生雷）。
         * @returns {Array<{boardA:number[][],boardB:number[][],minesA,minesB,lastMoveMarkers,nextMoveNumber:number,passCounter:number}>}
         */
        function buildFrontBackReplaySnapshots(coords, n) {
            let boardA = initBoard(n);
            let boardB = initBoard(n);
            let minesA = [];
            let minesB = [];
            let nextMoveNumber = 1;
            let passCounter = 0;
            const posSet = new Set();
            posSet.add(snapStateString(boardA, boardB, minesA, minesB));

            function countGroupLibertiesSim(board, row, col) {
                const color = board[row][col];
                if (color === 0) return 0;
                const visited = Array(n).fill().map(() => Array(n).fill(false));
                const queue = [[row, col]];
                visited[row][col] = true;
                const liberties = new Set();
                const dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
                while (queue.length) {
                    const [r, c] = queue.shift();
                    for (const [dr, dc] of dirs) {
                        const nr = r + dr, nc = c + dc;
                        if (nr < 0 || nr >= n || nc < 0 || nc >= n) continue;
                        if (board[nr][nc] === 0) liberties.add(nr + ',' + nc);
                        else if (board[nr][nc] === color && !visited[nr][nc]) {
                            visited[nr][nc] = true;
                            queue.push([nr, nc]);
                        }
                    }
                }
                return liberties.size;
            }

            function removeGroupSim(board, row, col, color) {
                const queue = [[row, col]];
                board[row][col] = 0;
                const dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
                while (queue.length) {
                    const [r, c] = queue.shift();
                    for (const [dr, dc] of dirs) {
                        const nr = r + dr, nc = c + dc;
                        if (nr >= 0 && nr < n && nc >= 0 && nc < n && board[nr][nc] === color) {
                            board[nr][nc] = 0;
                            queue.push([nr, nc]);
                        }
                    }
                }
            }

            function tryPlaceStoneSim(board, mines, row, col, playerVal) {
                if (board[row][col] !== 0) return null;
                if (isMine(mines, row, col)) return null;
                const nb = deepCopyBoard(board);
                nb[row][col] = playerVal;
                const enemyColor = 3 - playerVal;
                const dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
                const checkedEnemy = new Set();
                for (const [dr, dc] of dirs) {
                    const nr = row + dr, nc = col + dc;
                    if (nr >= 0 && nr < n && nc >= 0 && nc < n && nb[nr][nc] === enemyColor) {
                        const key = `${nr},${nc}`;
                        if (!checkedEnemy.has(key)) {
                            checkedEnemy.add(key);
                            if (countGroupLibertiesSim(nb, nr, nc) < 1) removeGroupSim(nb, nr, nc, enemyColor);
                        }
                    }
                }
                if (countGroupLibertiesSim(nb, row, col) < 1) removeGroupSim(nb, row, col, playerVal);
                return nb;
            }

            function tryClearMineSim(which, row, col) {
                const minesPlayed = which === 'A' ? minesA : minesB;
                if (!isMine(minesPlayed, row, col)) return null;
                const newMinesPlayed = copyMineList(minesPlayed).filter(p => !(p.row === row && p.col === col));
                const newMinesA = which === 'A' ? newMinesPlayed : copyMineList(minesA);
                const newMinesB = which === 'B' ? newMinesPlayed : copyMineList(minesB);
                const newBoardA = deepCopyBoard(boardA);
                const newBoardB = deepCopyBoard(boardB);
                const nextStr = snapStateString(newBoardA, newBoardB, newMinesA, newMinesB);
                if (posSet.has(nextStr)) return null;
                return { newBoardA, newBoardB, newMinesA, newMinesB, nextStr };
            }

            function tryApplyStoneSim(which, row, col, playerVal) {
                const minesOnPlayed = which === 'A' ? minesA : minesB;
                if (isMine(minesOnPlayed, row, col)) {
                    const cleared = tryClearMineSim(which, row, col);
                    if (!cleared) return null;
                    minesA.length = 0; minesA.push(...cleared.newMinesA);
                    minesB.length = 0; minesB.push(...cleared.newMinesB);
                    posSet.add(cleared.nextStr);
                    return { markers: [{ board: which, row, col, color: playerVal }] };
                }
                const board = which === 'A' ? boardA : boardB;
                const newBoard = tryPlaceStoneSim(board, minesOnPlayed, row, col, playerVal);
                if (!newBoard) return null;
                const newMinesPlayed = copyMineList(minesOnPlayed);
                const newMinesOther = copyMineList(which === 'A' ? minesB : minesA);
                const boardOther = which === 'A' ? boardB : boardA;
                if (boardOther[row][col] === 0 && !isMine(newMinesOther, row, col)) newMinesOther.push({ row, col });
                const newBoardA = which === 'A' ? newBoard : deepCopyBoard(boardA);
                const newBoardB = which === 'B' ? newBoard : deepCopyBoard(boardB);
                const newMinesA = which === 'A' ? newMinesPlayed : newMinesOther;
                const newMinesB = which === 'B' ? newMinesPlayed : newMinesOther;
                const nextStr = snapStateString(newBoardA, newBoardB, newMinesA, newMinesB);
                if (posSet.has(nextStr)) return null;
                boardA = newBoardA;
                boardB = newBoardB;
                minesA = newMinesA;
                minesB = newMinesB;
                posSet.add(nextStr);
                return { markers: [{ board: which, row, col, color: playerVal }] };
            }

            const snaps = [cloneSnap({
                boardA, boardB,
                minesA: copyMineList(minesA), minesB: copyMineList(minesB),
                lastMoveMarkers: [], nextMoveNumber: 1, passCounter: 0
            })];

            const list = coords || [];
            for (let i = 0; i < list.length; i++) {
                const mv = list[i];
                const expS = expectedSlotForMoveNumber(nextMoveNumber);
                const expB = expectedBoardForMoveNumber(nextMoveNumber);
                if (mv.player !== expS) break;

                if (mv.type === 'pass') {
                    passCounter++;
                    nextMoveNumber++;
                    snaps.push(cloneSnap({
                        boardA: deepCopyBoard(boardA), boardB: deepCopyBoard(boardB),
                        minesA: copyMineList(minesA), minesB: copyMineList(minesB),
                        lastMoveMarkers: [], nextMoveNumber, passCounter
                    }));
                    continue;
                }
                if (mv.type !== 'move' && mv.type !== 'clearMine') break;
                if (mv.board !== expB) break;

                const playerVal = mv.player === 'black' ? 1 : 2;
                if (mv.type === 'clearMine') {
                    const cleared = tryClearMineSim(mv.board, mv.row, mv.col);
                    if (!cleared) break;
                    minesA = cleared.newMinesA;
                    minesB = cleared.newMinesB;
                    posSet.add(cleared.nextStr);
                    nextMoveNumber++;
                    passCounter = 0;
                    snaps.push(cloneSnap({
                        boardA: deepCopyBoard(boardA), boardB: deepCopyBoard(boardB),
                        minesA: copyMineList(minesA), minesB: copyMineList(minesB),
                        lastMoveMarkers: [{ board: mv.board, row: mv.row, col: mv.col, color: playerVal }],
                        nextMoveNumber, passCounter
                    }));
                    continue;
                }
                const applied = tryApplyStoneSim(mv.board, mv.row, mv.col, playerVal);
                if (!applied) break;
                nextMoveNumber++;
                passCounter = 0;
                snaps.push(cloneSnap({
                    boardA: deepCopyBoard(boardA), boardB: deepCopyBoard(boardB),
                    minesA: copyMineList(minesA), minesB: copyMineList(minesB),
                    lastMoveMarkers: applied.markers,
                    nextMoveNumber, passCounter
                }));
            }
            return snaps;
        }

        function applySnapToGlobals(snap) {
            if (!snap) return;
            boardA = deepCopyBoard(snap.boardA);
            boardB = deepCopyBoard(snap.boardB);
            minesA = copyMineList(snap.minesA);
            minesB = copyMineList(snap.minesB);
            lastMoveMarkers = (snap.lastMoveMarkers || []).map(m => ({ ...m }));
            nextMoveNumber = snap.nextMoveNumber;
            passCounter = snap.passCounter != null ? snap.passCounter : 0;
            expectedSlot = expectedSlotForMoveNumber(nextMoveNumber);
            expectedBoard = expectedBoardForMoveNumber(nextMoveNumber);
        }

        function rebuildLiveReplayFromMoveCoords() {
            liveReplaySnaps = buildFrontBackReplaySnapshots(moveCoords, BOARD_SIZE);
        }

        function getLiveReplayTotal() {
            return Math.max(0, liveReplaySnaps.length - 1);
        }

        function isLiveBrowsingHistory() {
            if (ps.replayMode || ps.tryPlayMode) return false;
            const t = getLiveReplayTotal();
            return liveReplaySnaps.length > 0 && ps.liveViewStep < t;
        }

        function updateLiveReplayPanelUI() {
            if (ps.replayMode) return;
            const total = getLiveReplayTotal();
            const slider = document.getElementById('replaySlider');
            if (!slider) return;
            slider.min = 0;
            slider.max = total;
            slider.value = ps.liveViewStep;
            const el = document.getElementById('replayStepDisplay');
            if (el) el.innerText = `${ps.liveViewStep} / ${total}`;
        }

        function setLiveViewStep(step) {
            if (ps.replayMode) return;
            clearMobileMovePreview();
            const total = getLiveReplayTotal();
            let s = step;
            if (s < 0) s = 0;
            if (s > total) s = total;
            ps.liveViewStep = s;
            ps.liveFollowLatest = s >= total;
            if (liveReplaySnaps.length) applySnapToGlobals(liveReplaySnaps[s]);
            updateLiveReplayPanelUI();
            ps.isMyTurn = !isLiveBrowsingHistory() && !ps.tryPlayMode && isMyTurn();
            if (ps.showEstimateActive) showEstimate();
            else updateTurn();
        }

        function updateReplayUI() {
            const replayPanel = document.getElementById('replayPanel');
            const gameButtonIds = ['passBtn', 'undoBtn', 'resignBtn', 'drawBtn', 'endReqBtn'];
            const tryPlayBtn = document.getElementById('tryPlayBtn');
            const isPlayer = !!ps.mySlot;
            const started = !!(ps.matchStarted || (ps.matchTime && ps.matchTime.settings));
            const showMatchButtons = isPlayer && started && !ps.replayMode;
            for (const id of gameButtonIds) {
                const el = document.getElementById(id);
                if (el) el.style.display = showMatchButtons ? '' : 'none';
            }
            if (replayPanel) replayPanel.style.display = '';
            if (tryPlayBtn) {
                tryPlayBtn.style.display = showMatchButtons ? 'none' : '';
                tryPlayBtn.innerText = ps.tryPlayMode ? '试下结束' : '试下';
            }
        }

        function setReplayStep(step) {
            if (!ps.replayMode) return;
            clearMobileMovePreview();
            let s = step;
            if (s < 0) s = 0;
            if (s > ps.replayTotalSteps) s = ps.replayTotalSteps;
            ps.replayStep = s;
            if (replaySnaps.length) applySnapToGlobals(replaySnaps[s]);
            const slider = document.getElementById('replaySlider');
            if (slider) slider.value = s;
            const el = document.getElementById('replayStepDisplay');
            if (el) el.innerText = `${s} / ${ps.replayTotalSteps}`;
            ps.isMyTurn = false;
            if (ps.tryPlayMode) {
                tryPlaySnaps = [cloneSnap(replaySnaps[s])];
                tryPlayMoveList = [];
                ps.tryPlayStep = 0;
                ps.tryPlayTotalSteps = 0;
                if (slider) { slider.min = 0; slider.max = 0; slider.value = 0; }
                updateTryPlayDisplay();
            }
            if (ps.showEstimateActive) showEstimate();
            else updateTurn();
        }

        function enterReplayMode(data) {
            const moves = (data && data.moves) ? data.moves : [];
            replaySnaps = buildFrontBackReplaySnapshots(moves, BOARD_SIZE);
            ps.replayTotalSteps = Math.max(0, replaySnaps.length - 1);
            ps.replayMode = true;
            ps.tryPlayMode = false;
            tryPlaySnaps = [];
            tryPlayMoveList = [];
            const slider = document.getElementById('replaySlider');
            if (slider) {
                slider.min = 0;
                slider.max = ps.replayTotalSteps;
            }
            setReplayStep(ps.replayTotalSteps);
            updateReplayUI();
        }

        function exitReplayMode() {
            clearMobileMovePreview();
            ps.tryPlayMode = false;
            tryPlaySnaps = [];
            tryPlayMoveList = [];
            ps.replayMode = false;
            replaySnaps = [];
            ps.replayStep = 0;
            ps.replayTotalSteps = 0;
            rebuildLiveReplayFromMoveCoords();
            const total = getLiveReplayTotal();
            ps.liveViewStep = total;
            ps.liveFollowLatest = true;
            if (liveReplaySnaps.length) applySnapToGlobals(liveReplaySnaps[total]);
            updateLiveReplayPanelUI();
            updateReplayUI();
            ps.isMyTurn = isMyTurn();
            if (ps.showEstimateActive) showEstimate();
            else updateTurn();
        }

        function updateTryPlayDisplay() {
            const stepDisplay = document.getElementById('replayStepDisplay');
            if (ps.tryPlayMode && stepDisplay) {
                stepDisplay.innerText = `试下 ${ps.tryPlayStep} / ${ps.tryPlayTotalSteps}`;
                const snap = tryPlaySnaps[ps.tryPlayStep];
                const mn = snap ? snap.nextMoveNumber : 1;
                const emoji = expectedSlotForMoveNumber(mn) === 'black' ? '⚫' : '⚪';
                turnDisplay.innerText = `${emoji} 试下`;
            }
        }

        function enterTryPlay() {
            if (!ps.replayMode) return;
            clearMobileMovePreview();
            ps.tryPlayMode = true;
            ps.tryPlayBaseReplayStep = ps.replayStep;
            tryPlaySnaps = [cloneSnap(replaySnaps[ps.replayStep])];
            tryPlayMoveList = [];
            ps.tryPlayStep = 0;
            ps.tryPlayTotalSteps = 0;
            const slider = document.getElementById('replaySlider');
            if (slider) {
                slider.min = 0;
                slider.max = 0;
                slider.value = 0;
            }
            applySnapToGlobals(tryPlaySnaps[0]);
            updateTryPlayDisplay();
            updateReplayUI();
            drawAllBoards();
        }

        function exitTryPlay() {
            clearMobileMovePreview();
            ps.tryPlayMode = false;
            tryPlaySnaps = [];
            tryPlayMoveList = [];
            const slider = document.getElementById('replaySlider');
            if (slider) {
                slider.min = 0;
                slider.max = ps.replayTotalSteps;
            }
            setReplayStep(ps.tryPlayBaseReplayStep);
            updateReplayUI();
        }

        function setTryPlayStep(step) {
            if (!ps.tryPlayMode) return;
            clearMobileMovePreview();
            let s = step;
            if (s < 0) s = 0;
            if (s > ps.tryPlayTotalSteps) s = ps.tryPlayTotalSteps;
            ps.tryPlayStep = s;
            if (tryPlaySnaps[s]) applySnapToGlobals(tryPlaySnaps[s]);
            const slider = document.getElementById('replaySlider');
            if (slider) slider.value = s;
            updateTryPlayDisplay();
            if (ps.showEstimateActive) showEstimate();
            else drawAllBoards();
        }

        /**
         * 在试下局面（tryPlaySnaps 末尾）上走一步；成功则追加快照。
         */
        function tryPlayApplyMove(which, row, col) {
            if (!tryPlaySnaps.length) return false;
            const cur = cloneSnap(tryPlaySnaps[tryPlaySnaps.length - 1]);
            const mn = cur.nextMoveNumber;
            if (which !== expectedBoardForMoveNumber(mn)) return false;
            const playerVal = expectedSlotForMoveNumber(mn) === 'black' ? 1 : 2;
            const minesPlayedBefore = which === 'A' ? cur.minesA : cur.minesB;
            const wasMineBefore = isMine(minesPlayedBefore, row, col);

            let boardA = deepCopyBoard(cur.boardA);
            let boardB = deepCopyBoard(cur.boardB);
            let minesA = copyMineList(cur.minesA);
            let minesB = copyMineList(cur.minesB);
            const posSet = new Set();
            posSet.add(snapStateString(boardA, boardB, minesA, minesB));

            const n = BOARD_SIZE;
            function countGroupLibertiesTp(board, r0, c0) {
                const color = board[r0][c0];
                if (color === 0) return 0;
                const visited = Array(n).fill().map(() => Array(n).fill(false));
                const queue = [[r0, c0]];
                visited[r0][c0] = true;
                const liberties = new Set();
                const dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
                while (queue.length) {
                    const [r, c] = queue.shift();
                    for (const [dr, dc] of dirs) {
                        const nr = r + dr, nc = c + dc;
                        if (nr < 0 || nr >= n || nc < 0 || nc >= n) continue;
                        if (board[nr][nc] === 0) liberties.add(nr + ',' + nc);
                        else if (board[nr][nc] === color && !visited[nr][nc]) {
                            visited[nr][nc] = true;
                            queue.push([nr, nc]);
                        }
                    }
                }
                return liberties.size;
            }
            function removeGroupTp(board, r0, c0, color) {
                const queue = [[r0, c0]];
                board[r0][c0] = 0;
                const dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
                while (queue.length) {
                    const [r, c] = queue.shift();
                    for (const [dr, dc] of dirs) {
                        const nr = r + dr, nc = c + dc;
                        if (nr >= 0 && nr < n && nc >= 0 && nc < n && board[nr][nc] === color) {
                            board[nr][nc] = 0;
                            queue.push([nr, nc]);
                        }
                    }
                }
            }
            function tryPlaceStoneTp(board, mines, r, c, pv) {
                if (board[r][c] !== 0) return null;
                if (isMine(mines, r, c)) return null;
                const nb = deepCopyBoard(board);
                nb[r][c] = pv;
                const enemyColor = 3 - pv;
                const dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
                const checkedEnemy = new Set();
                for (const [dr, dc] of dirs) {
                    const nr = r + dr, nc = c + dc;
                    if (nr >= 0 && nr < n && nc >= 0 && nc < n && nb[nr][nc] === enemyColor) {
                        const key = `${nr},${nc}`;
                        if (!checkedEnemy.has(key)) {
                            checkedEnemy.add(key);
                            if (countGroupLibertiesTp(nb, nr, nc) < 1) removeGroupTp(nb, nr, nc, enemyColor);
                        }
                    }
                }
                if (countGroupLibertiesTp(nb, r, c) < 1) removeGroupTp(nb, r, c, pv);
                return nb;
            }

            function tryOne() {
                const minesOnPlayed = which === 'A' ? minesA : minesB;
                if (isMine(minesOnPlayed, row, col)) {
                    const newMinesPlayed = copyMineList(minesOnPlayed).filter(p => !(p.row === row && p.col === col));
                    const newMinesA = which === 'A' ? newMinesPlayed : copyMineList(minesA);
                    const newMinesB = which === 'B' ? newMinesPlayed : copyMineList(minesB);
                    const nextStr = snapStateString(boardA, boardB, newMinesA, newMinesB);
                    if (posSet.has(nextStr)) return null;
                    minesA = newMinesA;
                    minesB = newMinesB;
                    posSet.add(nextStr);
                    return { markers: [{ board: which, row, col, color: playerVal }], nextMN: mn + 1, pc: 0 };
                }
                const board = which === 'A' ? boardA : boardB;
                const nb = tryPlaceStoneTp(board, minesOnPlayed, row, col, playerVal);
                if (!nb) return null;
                const newMinesPlayed = copyMineList(minesOnPlayed);
                const newMinesOther = copyMineList(which === 'A' ? minesB : minesA);
                const boardOther = which === 'A' ? boardB : boardA;
                if (boardOther[row][col] === 0 && !isMine(newMinesOther, row, col)) newMinesOther.push({ row, col });
                const newBoardA = which === 'A' ? nb : deepCopyBoard(boardA);
                const newBoardB = which === 'B' ? nb : deepCopyBoard(boardB);
                const newMinesA = which === 'A' ? newMinesPlayed : newMinesOther;
                const newMinesB = which === 'B' ? newMinesPlayed : newMinesOther;
                const nextStr = snapStateString(newBoardA, newBoardB, newMinesA, newMinesB);
                if (posSet.has(nextStr)) return null;
                boardA = newBoardA;
                boardB = newBoardB;
                minesA = newMinesA;
                minesB = newMinesB;
                posSet.add(nextStr);
                return { markers: [{ board: which, row, col, color: playerVal }], nextMN: mn + 1, pc: 0 };
            }

            const res = tryOne();
            if (!res) return false;
            const nextSnap = {
                boardA, boardB, minesA, minesB,
                lastMoveMarkers: res.markers,
                nextMoveNumber: res.nextMN,
                passCounter: res.pc
            };
            if (ps.tryPlayStep < ps.tryPlayTotalSteps) {
                tryPlaySnaps.length = ps.tryPlayStep + 1;
                tryPlayMoveList.length = ps.tryPlayStep;
            }
            tryPlaySnaps.push(cloneSnap(nextSnap));
            tryPlayMoveList.push({
                type: wasMineBefore ? 'clearMine' : 'move',
                board: which, row, col,
                player: expectedSlotForMoveNumber(mn)
            });
            ps.tryPlayTotalSteps = tryPlaySnaps.length - 1;
            ps.tryPlayStep = ps.tryPlayTotalSteps;
            applySnapToGlobals(nextSnap);
            const slider = document.getElementById('replaySlider');
            if (slider) {
                slider.max = ps.tryPlayTotalSteps;
                slider.value = ps.tryPlayStep;
            }
            updateTryPlayDisplay();
            if (ps.showEstimateActive) showEstimate();
            else drawAllBoards();
            return true;
        }

        function updateTurn() {
            if (ps.waitingScoreConfirm) return;
            if (ps.gameOver) {
                turnDisplay.innerText = '对局结束';
                drawAllBoards();
                return;
            }
            if (ps.tryPlayMode) {
                updateTryPlayDisplay();
                drawAllBoards();
                return;
            }
            if (ps.replayMode) {
                if (ps.replayStep <= 0) turnDisplay.innerText = '打谱：初始局面';
                else {
                    const m = replaySnaps[ps.replayStep] && replaySnaps[ps.replayStep].lastMoveMarkers && replaySnaps[ps.replayStep].lastMoveMarkers[0];
                    const emoji = m && m.color === 1 ? '⚫' : '⚪';
                    turnDisplay.innerText = `打谱：${emoji}第${ps.replayStep}手`;
                }
                drawAllBoards();
                return;
            }
            const lastN = nextMoveNumber - 1;
            if (lastN < 1) {
                turnDisplay.innerText = `初始局面`;
            } else {
                const lastSlot = expectedSlotForMoveNumber(lastN);
                turnDisplay.innerText = `${slotEmoji(lastSlot)}第${lastN}手`;
            }
            drawAllBoards();
        }

        function syncState(state) {
            const s = unwrapGameStatePayload(state);
            if (!s) return;
            clearMobileMovePreview();
            if (s.boardSize && s.boardSize !== BOARD_SIZE) {
                BOARD_SIZE = s.boardSize;
                boardA = initBoard(BOARD_SIZE);
                boardB = initBoard(BOARD_SIZE);
                minesA = [];
                minesB = [];
                updateBoardGeometry();
                const sel = document.getElementById('boardSizeSelect');
                if (sel) sel.value = BOARD_SIZE;
            }
            moveCoords = s.moveCoords || moveCoords;
            ps.gameOver = !!s.gameOver;
            ps.winner = s.winner;
            if (s.slots) ps.slots = s.slots;

            if (!ps.replayMode) {
                const prevTotal = Math.max(0, liveReplaySnaps.length - 1);
                const wasAtEnd = ps.liveFollowLatest || ps.liveViewStep >= prevTotal;
                rebuildLiveReplayFromMoveCoords();
                const newTotal = Math.max(0, liveReplaySnaps.length - 1);
                if (newTotal === 0) {
                    ps.liveViewStep = 0;
                    ps.liveFollowLatest = true;
                } else if (wasAtEnd) {
                    ps.liveViewStep = newTotal;
                    ps.liveFollowLatest = true;
                } else {
                    ps.liveViewStep = Math.min(ps.liveViewStep, newTotal);
                    if (ps.liveViewStep === newTotal) ps.liveFollowLatest = true;
                }
                if (liveReplaySnaps.length) applySnapToGlobals(liveReplaySnaps[ps.liveViewStep]);
                updateLiveReplayPanelUI();
            } else {
                if (s.boardA) boardA = s.boardA.map(row => row.slice());
                if (s.boardB) boardB = s.boardB.map(row => row.slice());
                minesA = (s.minesA || s.holesA || []).map(p => ({ row: p.row, col: p.col }));
                minesB = (s.minesB || s.holesB || []).map(p => ({ row: p.row, col: p.col }));
                nextMoveNumber = s.nextMoveNumber != null ? s.nextMoveNumber : 1;
                expectedBoard = s.expectedBoard || 'A';
                expectedSlot = s.expectedSlot || 'black';
                passCounter = s.passCounter || 0;
                lastMoveMarkers = (s.lastMoveMarkers || []).map(m => ({ ...m }));
            }

            const hasStone = boardA.some(r => r.some(v => v !== 0)) || boardB.some(r => r.some(v => v !== 0));
            const hasMine = minesA.length > 0 || minesB.length > 0;
            const hasPlayer = ps.slots.black || ps.slots.white;
            const sizeSelect = document.getElementById('boardSizeSelect');
            const liveTotal = getLiveReplayTotal();
            if (!hasStone && !hasMine && !hasPlayer && !ps.gameOver && ps.mySlot === null && ps.liveViewStep === 0 && liveTotal === 0)
                sizeSelect.style.display = 'inline-block';
            else
                sizeSelect.style.display = 'none';

            ps.isMyTurn = !isLiveBrowsingHistory() && !ps.tryPlayMode && isMyTurn();
            updateRecordButtonsBound();
            updateReplayUI();
            if (ps.showEstimateActive) showEstimate();
            else updateTurn();
        }

        function openScoreConfirmPanel(lead, blackTotal, whiteTotal) {
            const wt = winnerText(lead);
            let extra = '';
            if (blackTotal != null && whiteTotal != null)
                extra = `（黑 ${blackTotal.toFixed(1)}　白 ${whiteTotal.toFixed(1)}）`;
            scoreConfirmText.innerText = `${wt}${extra}，是否同意该结果？`;
            scoreConfirmPanel.style.display = 'block';
        }

        function winnerText(lead) {
            if (lead > 0) return `黑胜${Math.abs(lead).toFixed(1)}点`;
            if (lead < 0) return `白胜${Math.abs(lead).toFixed(1)}点`;
            return '和棋';
        }

        function hideScoreConfirm() {
            scoreConfirmPanel.style.display = 'none';
        }

        function downloadRecord(data) {
            const now = new Date();
            const pad = n => n.toString().padStart(2, '0');
            const dateStr = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
            const filename = `正反面围棋_${data.boardSize}路_${dateStr}.json`;
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }

        const weiqiCtx = {
            roomId,
            gameType,
            pageState: ps,
            drawBoard: drawAllBoards,
            exitTryPlay,
            enterTryPlay,
            setTryPlayStep,
            setReplayStep,
            setLiveViewStep,
            getWs: () => ps.ws,
            getBoardSize: () => BOARD_SIZE,
            setBoardSize: (n) => { BOARD_SIZE = n; },
            getKomi: () => 0,
            setKomi: () => {},
            getBoard: getMergedBoardForBindings,
            setBoard: (b) => {
                boardA = deepCopyBoard(b);
                boardB = deepCopyBoard(b);
            },
            getSlots: () => ps.slots,
            setSlots: (s) => { ps.slots = s; },
            getMySlot: () => ps.mySlot,
            setMySlot: (v) => { ps.mySlot = v; },
            getGameOver: () => ps.gameOver,
            setGameOver: (v) => { ps.gameOver = v; },
            getWinner: () => ps.winner,
            setWinner: (w) => { ps.winner = w; },
            getReplayMode: () => ps.replayMode,
            getShowEstimateActive: () => ps.showEstimateActive,
            setShowEstimateActive: (v) => { ps.showEstimateActive = v; },
            getWaitingScoreConfirm: () => ps.waitingScoreConfirm,
            setWaitingScoreConfirm: (v) => { ps.waitingScoreConfirm = v; },
            getIRejected: () => ps.iRejected,
            setIRejected: (v) => { ps.iRejected = v; },
            colorStatus,
            scoreTitle,
            turnDisplay,
syncState,
            updateBoardGeometry,
            initBoardArray: initBoard,
            exitReplayMode,
            enterReplayMode,
            clearEstimate,
            hideScoreConfirm,
            showEstimate,
            clearMobileMovePreview,
            downloadRecord,
            updateTurn,
            updateReplayUI,
            showScoreConfirm: (lead) => {
                openScoreConfirmPanel(lead, ps._lastScoreBlack, ps._lastScoreWhite);
            },
            isMouseDevice,
            onNewGameStarted: () => { userBoardMarks = Object.create(null); },
            onRoomReset: () => { userBoardMarks = Object.create(null); },
            onBoardSizeChanged: (msg) => {
                if (!msg.boardSize) return;
                const sel = document.getElementById('boardSizeSelect');
                if (sel) sel.value = msg.boardSize;
                if (msg.boardSize !== BOARD_SIZE) {
                    BOARD_SIZE = msg.boardSize;
                    boardA = initBoard(BOARD_SIZE);
                    boardB = initBoard(BOARD_SIZE);
                    minesA = [];
                    minesB = [];
                    updateBoardGeometry();
                }
            }
        };
        weiqiCtx.standardWeiqiMatchTime = true;
        weiqiCtx.boardSeatOverlay = true;
        weiqiCtx.seatOverlayDualBoards = true;
        const _weiqiBindings = QiBoardRoomClient.createWeiqiMessageBindings(weiqiCtx);
        updateRecordButtonsBound = _weiqiBindings.updateRecordButtons;
        updateRadioStylesBound = _weiqiBindings.updateRadioStyles;

        function handleMessage(msg) {
            if (msg.type === 'scoreProposal') {
                ps._lastScoreBlack = msg.blackTotal;
                ps._lastScoreWhite = msg.whiteTotal;
            }
            _weiqiBindings.handleMessage(msg);
        }

        function connectWebSocket() {
            if (reconnectTimer) clearTimeout(reconnectTimer);
            const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${location.host}/qi/ws?game=${gameType}&room=${roomId}`;
            ps.ws = new WebSocket(wsUrl);
            ps.ws.onopen = () => ps.ws.send(JSON.stringify({ type: 'join', password: roomPassword, requestedSlot: null }));
            ps.ws.onmessage = (e) => handleMessage(JSON.parse(e.data));
            ps.ws.onclose = (event) => {
                if (typeof window !== 'undefined' && window.__qiRoomLeaving) return;
                if (event.code === 1008 && event.reason && event.reason.includes('房间不存在')) {
                    qiAlert('房间不存在，请返回大厅');
                    window.location.href = '/qi';
                    return;
                }
                colorStatus.innerText = '连接断开，重连中...';
                reconnectTimer = setTimeout(connectWebSocket, 2000);
            };
        }

        function canvasCoordsFromClient(canvas, clientX, clientY) {
            return C().canvasCoordsFromClient(clientX, clientY, canvas, CANVAS_PX);
        }

        function getSelectedBoardMark() {
            if (!boardMarkSelect) return { clear: false, ch: '?' };
            const v = boardMarkSelect.value;
            if (v === '') return { clear: true, ch: '' };
            return { clear: false, ch: v };
        }

        function applyUserBoardMark(which, row, col) {
            if (row < 0 || col < 0) return;
            const board = which === 'A' ? boardA : boardB;
            const mines = which === 'A' ? minesA : minesB;
            if (board[row][col] !== 0 || isMine(mines, row, col)) return;
            const key = which + '|' + row + ',' + col;
            const { clear, ch } = getSelectedBoardMark();
            const existing = userBoardMarks[key];
            if (clear) {
                if (existing !== undefined) {
                    delete userBoardMarks[key];
                    drawAllBoards();
                }
                return;
            }
            if (existing === undefined) {
                userBoardMarks[key] = ch;
            } else if (existing !== ch) {
                userBoardMarks[key] = ch;
            } else {
                delete userBoardMarks[key];
            }
            drawAllBoards();
        }

        let suppressCanvasClickAfterLongMark = false;

        function attachCanvas(canvas, which, hoverRef) {
            canvas.addEventListener('click', (e) => {
                if (suppressCanvasClickAfterLongMark) {
                    e.preventDefault();
                    return;
                }
                if (ps.waitingScoreConfirm) return;
                if (ps.tryPlayMode && ps.replayMode) {
                    const rect = canvas.getBoundingClientRect();
                    const scale = CANVAS_PX / rect.width;
                    const x = (e.clientX - rect.left) * scale;
                    const y = (e.clientY - rect.top) * scale;
                    const { row, col } = getClosestIntersection(x, y);
                    if (row < 0) {
                        if (mobileTwoStepPlacing()) { clearMobileMovePreview(); drawAllBoards(); }
                        return;
                    }
                    if (which !== expectedBoard) {
                        if (mobileTwoStepPlacing()) clearMobileMovePreview();
                        return;
                    }
                    const board = which === 'A' ? boardA : boardB;
                    if (board[row][col] !== 0) {
                        if (mobileTwoStepPlacing()) { clearMobileMovePreview(); drawAllBoards(); }
                        return;
                    }
                    const m2 = mobileTwoStepPlacing();
                    if (m2) {
                        const h = hoverRef;
                        if (h.row === row && h.col === col && h.ok) {
                            clearMobileMovePreview();
                            tryPlayApplyMove(which, row, col);
                        } else {
                            if (which === 'A') { hoverB.row = -1; hoverB.col = -1; hoverB.ok = false; }
                            else { hoverA.row = -1; hoverA.col = -1; hoverA.ok = false; }
                            hoverRef.row = row;
                            hoverRef.col = col;
                            hoverRef.ok = true;
                            drawAllBoards();
                        }
                        return;
                    }
                    tryPlayApplyMove(which, row, col);
                    return;
                }
                if (isLiveBrowsingHistory() || ps.replayMode) return;
                if (ps.gameOver || !ps.mySlot || !isMyTurn()) return;
                const rect = canvas.getBoundingClientRect();
                const scale = CANVAS_PX / rect.width;
                const x = (e.clientX - rect.left) * scale;
                const y = (e.clientY - rect.top) * scale;
                const { row, col } = getClosestIntersection(x, y);
                if (row < 0) {
                    if (mobileTwoStepPlacing()) { clearMobileMovePreview(); drawAllBoards(); }
                    return;
                }
                if (which !== expectedBoard) {
                    if (mobileTwoStepPlacing()) clearMobileMovePreview();
                    return;
                }
                const board = which === 'A' ? boardA : boardB;
                const mines = which === 'A' ? minesA : minesB;
                if (board[row][col] !== 0) {
                    if (mobileTwoStepPlacing()) { clearMobileMovePreview(); drawAllBoards(); }
                    return;
                }
                const m2 = mobileTwoStepPlacing();
                if (m2) {
                    const h = hoverRef;
                    if (h.row === row && h.col === col && h.ok) {
                        clearMobileMovePreview();
                        ps.ws.send(JSON.stringify({ type: 'move', row, col, board: which }));
                        drawAllBoards();
                    } else {
                        if (which === 'A') { hoverB.row = -1; hoverB.col = -1; hoverB.ok = false; }
                        else { hoverA.row = -1; hoverA.col = -1; hoverA.ok = false; }
                        hoverRef.row = row;
                        hoverRef.col = col;
                        hoverRef.ok = true;
                        drawAllBoards();
                    }
                    return;
                }
                ps.ws.send(JSON.stringify({ type: 'move', row, col, board: which }));
            });
            if (isMouseDevice) {
                canvas.addEventListener('mousemove', (e) => {
                    if (ps.waitingScoreConfirm) return;
                    const rect = canvas.getBoundingClientRect();
                    const scale = CANVAS_PX / rect.width;
                    const x = (e.clientX - rect.left) * scale;
                    const y = (e.clientY - rect.top) * scale;
                    const { row, col } = getClosestIntersection(x, y);
                    const board = which === 'A' ? boardA : boardB;
                    const mines = which === 'A' ? minesA : minesB;
                    hoverRef.row = row;
                    hoverRef.col = col;
                    if (ps.tryPlayMode && ps.replayMode) {
                        hoverRef.ok = row >= 0 && which === expectedBoard && board[row][col] === 0;
                    } else {
                        hoverRef.ok = row >= 0 && which === expectedBoard && board[row][col] === 0 && isMyTurn() && !isLiveBrowsingHistory();
                    }
                    if (hoverRef.ok && isMine(mines, row, col) && !(ps.tryPlayMode && ps.replayMode)) hoverRef.ok = false;
                    drawAllBoards();
                });
                canvas.addEventListener('mouseleave', () => {
                    hoverRef.row = -1;
                    hoverRef.ok = false;
                    drawAllBoards();
                });
            }
        }

        attachCanvas(canvasA, 'A', hoverA);
        attachCanvas(canvasB, 'B', hoverB);

        function bindBoardMarkInteraction(canvas, which) {
            canvas.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                const { x, y } = canvasCoordsFromClient(canvas, e.clientX, e.clientY);
                const { row, col } = getClosestIntersection(x, y);
                applyUserBoardMark(which, row, col);
            });
            const LONG_MARK_MS = 500;
            const LONG_MARK_MOVE_CANCEL = 14;
            let longMarkTimer = null;
            let longMarkStart = null;
            canvas.addEventListener('touchstart', (e) => {
                if (e.touches.length !== 1) return;
                const t = e.touches[0];
                longMarkStart = { x: t.clientX, y: t.clientY };
                longMarkTimer = setTimeout(() => {
                    longMarkTimer = null;
                    if (!longMarkStart) return;
                    const { x, y } = canvasCoordsFromClient(canvas, longMarkStart.x, longMarkStart.y);
                    const { row, col } = getClosestIntersection(x, y);
                    applyUserBoardMark(which, row, col);
                    suppressCanvasClickAfterLongMark = true;
                    setTimeout(() => { suppressCanvasClickAfterLongMark = false; }, 450);
                    longMarkStart = null;
                }, LONG_MARK_MS);
            }, { passive: true });
            canvas.addEventListener('touchmove', (e) => {
                if (!longMarkTimer || !longMarkStart || e.touches.length !== 1) return;
                const t = e.touches[0];
                const dx = t.clientX - longMarkStart.x;
                const dy = t.clientY - longMarkStart.y;
                if (dx * dx + dy * dy > LONG_MARK_MOVE_CANCEL * LONG_MARK_MOVE_CANCEL) {
                    clearTimeout(longMarkTimer);
                    longMarkTimer = null;
                }
            }, { passive: true });
            function clearLongMarkTouch() {
                if (longMarkTimer) {
                    clearTimeout(longMarkTimer);
                    longMarkTimer = null;
                }
                longMarkStart = null;
            }
            canvas.addEventListener('touchend', clearLongMarkTouch);
            canvas.addEventListener('touchcancel', clearLongMarkTouch);
        }
        bindBoardMarkInteraction(canvasA, 'A');
        bindBoardMarkInteraction(canvasB, 'B');

        if (scoreConfirmYes) {
            scoreConfirmYes.onclick = () => {
                ps.ws.send(JSON.stringify({ type: 'scoreResponse', accept: true }));
                hideScoreConfirm();
            };
            scoreConfirmNo.onclick = () => {
                ps.iRejected = true;
                ps.ws.send(JSON.stringify({ type: 'scoreResponse', accept: false }));
                hideScoreConfirm();
                if (ps.showEstimateActive) {
                    ps.showEstimateActive = false;
                    clearEstimate();
                }
                ps.waitingScoreConfirm = false;
            };
        }

        const showNumbersCheck = document.getElementById('showNumbersCheck');
        if (showNumbersCheck) {
            showNumbersCheck.addEventListener('change', (e) => {
                ps.showMoveNumbers = e.target.checked;
                drawAllBoards();
            });
        }

        updateBoardGeometry();

        /* board edit UI */
        if (typeof QiWeiqiSquarePageRuntime !== 'undefined' && QiWeiqiSquarePageRuntime.installBoardEditUI && typeof ps !== 'undefined') {
            const _editApi = QiWeiqiSquarePageRuntime.installBoardEditUI({
                ps: ps,
                canvas: document.getElementById('goBoard'),
                mode: 'grid2d',
                pickAtClient(clientX, clientY) {
                    if (typeof canvasCoordsFromClient === 'function' && typeof getClosestIntersection === 'function') {
                        const p = canvasCoordsFromClient(clientX, clientY);
                        return getClosestIntersection(p.x, p.y);
                    }
                    if (typeof pickIntersectionAtCanvas === 'function') {
                        const canvasEl = document.getElementById('goBoard');
                        const rect = canvasEl.getBoundingClientRect();
                        const scale = canvasEl.width / rect.width;
                        return pickIntersectionAtCanvas((clientX - rect.left) * scale, (clientY - rect.top) * scale);
                    }
                    return null;
                },
                drawBoard: typeof drawBoard === 'function' ? drawBoard : function () {},
                getBoard() { return ps.board; },
                setBoard(b) { ps.board = b; },
                emptyBoard() {
                    const n = ps.BOARD_SIZE || ps.boardSize || ps.board.length;
                    return Array(n).fill(null).map(function () { return Array(n).fill(0); });
                }
            });
            if (typeof syncState === 'function') {
                const _sync0 = syncState;
                syncState = function (state) {
                    if (state) {
                        if (state.initialBoard) ps.liveOpeningBoard = state.initialBoard;
                        ps.gameStarted = (state.numberOfHands || 1) > 1;
                    }
                    _sync0(state);
                    _editApi.updateEditModeUI();
                };
            }
        }

        connectWebSocket();
        })();
    }
};
